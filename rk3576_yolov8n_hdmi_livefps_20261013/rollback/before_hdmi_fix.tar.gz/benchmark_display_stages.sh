#!/bin/sh
# Compare the same live feed in adjacent windows, then restore AI HDMI.
sh /root/jpeg_rk/set_video_governor.sh performance
python3 /root/jpeg_rk/jpeg_control.py --rate 60

run_original() {
    taskset -c 0-2,6,7 python3 /root/jpeg_rk/show_jpeg_hdmi.py \
        --connector 188 --decoder software --decode-workers 3 --fps 60 \
        --sink kms --kms-sync-mode auto --output-format RGBx --skip-vsync \
        --temporal-method affine --seconds 45 > "$1" 2>&1
}

run_original /root/road_damage_yolov8n/compare_original_a.log
JPEG_NO_OSD=1 JPEG_AI_INTERVAL=6 JPEG_AI_SECONDS=45 \
    sh /root/jpeg_rk/start_jpeg_hdmi_ai.sh 188 \
    > /root/road_damage_yolov8n/compare_ai_no_status.log 2>&1
JPEG_AI_INTERVAL=6 JPEG_AI_SECONDS=45 \
    sh /root/jpeg_rk/start_jpeg_hdmi_ai.sh 188 \
    > /root/road_damage_yolov8n/compare_ai_full.log 2>&1
run_original /root/road_damage_yolov8n/compare_original_b.log
exec sh /root/jpeg_rk/start_jpeg_hdmi_ai_fallback.sh 188
