#!/bin/sh
JPEG_NO_OSD=1 JPEG_AI_INTERVAL=6 JPEG_AI_SECONDS=45 \
    sh /root/jpeg_rk/start_jpeg_hdmi_ai.sh 188 \
    > /root/road_damage_yolov8n/compare_ai_no_status_fixed.log 2>&1
JPEG_AI_INTERVAL=6 JPEG_AI_SECONDS=45 \
    sh /root/jpeg_rk/start_jpeg_hdmi_ai.sh 188 \
    > /root/road_damage_yolov8n/compare_ai_full_b.log 2>&1
exec sh /root/jpeg_rk/start_jpeg_hdmi_ai_fallback.sh 188
