#!/bin/sh
set -u

run_trial() {
    interval=$1
    video_log="/root/road_damage_yolov8n/plane_interval_${interval}.log"
    plane_log="/root/road_damage_yolov8n/plane_interval_${interval}_status.log"
    JPEG_NO_OSD=1 JPEG_AI_INTERVAL="$interval" JPEG_AI_SECONDS=40 \
        sh /root/jpeg_rk/start_jpeg_hdmi_ai.sh 188 > "$video_log" 2>&1 &
    viewer_pid=$!
    sleep 3
    /root/jpeg_rk/rk_hdmi_status_plane 35 > "$plane_log" 2>&1 &
    plane_pid=$!
    wait "$viewer_pid"
    kill "$plane_pid" 2>/dev/null || true
    wait "$plane_pid" 2>/dev/null || true
    sleep 2
}

for interval in 6 3 2 1; do
    run_trial "$interval"
done

exec sh /root/jpeg_rk/start_jpeg_hdmi_ai_fallback.sh 188
