#!/bin/sh
# Controlled live test; restore the normal viewer after every trial.
for interval in 6 3 1; do
    JPEG_AI_INTERVAL="$interval" JPEG_AI_SECONDS=35 \
        sh /root/jpeg_rk/start_jpeg_hdmi_ai.sh 188 \
        > "/root/road_damage_yolov8n/ai_interval_${interval}.log" 2>&1
    sleep 2
done
exec sh /root/jpeg_rk/start_jpeg_hdmi_ai_fallback.sh 188
