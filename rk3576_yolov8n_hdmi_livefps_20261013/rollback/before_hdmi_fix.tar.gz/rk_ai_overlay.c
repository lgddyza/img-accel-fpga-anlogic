/* In-place RGBx YOLO overlay, after the existing temporal and status OSD stages. */
#include <gst/base/gstbasetransform.h>
#include <gst/video/video.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>

#define PACKAGE "rkaioverlay"
#define BOX_PATH "/run/road_ai_boxes.bin"
#define BOX_MAGIC 0x52414942u
#define MAX_BOXES 64
#define MAX_AGE_US 500000

typedef struct {
    float x1, y1, x2, y2, score;
    uint32_t cls;
} AiBox;

typedef struct {
    uint32_t magic, seq;
    uint64_t updated_us;
    uint32_t count, reserved;
    AiBox boxes[MAX_BOXES];
} AiSnapshot;

_Static_assert(sizeof(AiSnapshot) == 1560, "overlay ABI size mismatch");

typedef struct {
    GstBaseTransform parent;
    GstVideoInfo info;
    int fd;
    const AiSnapshot *shared;
    uint64_t frames, frames_with_boxes, total_boxes;
    uint64_t total_us, max_us;
    uint64_t map_us, draw_us, unmap_us;
    gint64 last_log_us;
} GstRkAiOverlay;

typedef struct { GstBaseTransformClass parent_class; } GstRkAiOverlayClass;
G_DEFINE_TYPE(GstRkAiOverlay, gst_rk_ai_overlay, GST_TYPE_BASE_TRANSFORM)

static GstStaticPadTemplate sink_template = GST_STATIC_PAD_TEMPLATE(
    "sink", GST_PAD_SINK, GST_PAD_ALWAYS,
    GST_STATIC_CAPS("video/x-raw,format=(string)RGBx"));
static GstStaticPadTemplate src_template = GST_STATIC_PAD_TEMPLATE(
    "src", GST_PAD_SRC, GST_PAD_ALWAYS,
    GST_STATIC_CAPS("video/x-raw,format=(string)RGBx"));

static gboolean set_caps(GstBaseTransform *base, GstCaps *in, GstCaps *out) {
    (void)out;
    return gst_video_info_from_caps(&((GstRkAiOverlay *)base)->info, in);
}

static void fill_rect(uint8_t *data, int stride, int width, int height,
                      int x1, int y1, int x2, int y2,
                      uint8_t r, uint8_t g, uint8_t b) {
    if(x1 < 0) x1 = 0;
    if(y1 < 0) y1 = 0;
    if(x2 > width) x2 = width;
    if(y2 > height) y2 = height;
    if(x1 >= x2 || y1 >= y2) return;
    for(int y = y1; y < y2; ++y) {
        uint8_t *pixel = data + y * stride + x1 * 4;
        for(int x = x1; x < x2; ++x, pixel += 4) {
            pixel[0] = r; pixel[1] = g; pixel[2] = b; pixel[3] = 255;
        }
    }
}

static void glyph(char c, uint8_t rows[7]) {
    static const uint8_t digits[10][7] = {
        {14,17,19,21,25,17,14}, {4,12,4,4,4,4,14},
        {14,17,1,2,4,8,31}, {30,1,1,14,1,1,30},
        {2,6,10,18,31,2,2}, {31,16,16,30,1,1,30},
        {14,16,16,30,17,17,14}, {31,1,2,4,8,8,8},
        {14,17,17,14,17,17,14}, {14,17,17,15,1,1,14}
    };
    if(c >= '0' && c <= '9') {
        memcpy(rows, digits[c - '0'], 7);
        return;
    }
    static const uint8_t letter_c[7] = {14,17,16,16,16,17,14};
    static const uint8_t dot[7] = {0,0,0,0,0,4,4};
    static const uint8_t colon[7] = {0,4,4,0,4,4,0};
    switch(c) {
    case 'C': memcpy(rows, letter_c, 7); return;
    case '.': memcpy(rows, dot, 7); return;
    case ':': memcpy(rows, colon, 7); return;
    default: memset(rows, 0, 7); return;
    }
}

static void draw_label(uint8_t *data, int stride, int width, int height,
                       int x, int y, const char *label) {
    const int scale = 2;
    for(const char *p = label; *p; ++p, x += 6 * scale) {
        uint8_t rows[7];
        glyph(*p, rows);
        for(int gy = 0; gy < 7; ++gy)
            for(int gx = 0; gx < 5; ++gx)
                if(rows[gy] & (1u << (4 - gx)))
                    fill_rect(data, stride, width, height,
                              x + gx * scale, y + gy * scale,
                              x + (gx + 1) * scale, y + (gy + 1) * scale,
                              255, 255, 255);
    }
}

static gboolean read_snapshot(GstRkAiOverlay *self, AiSnapshot *snapshot,
                              gint64 now_us) {
    if(!self->shared) return FALSE;
    uint32_t before = __atomic_load_n(&self->shared->seq, __ATOMIC_ACQUIRE);
    if(before & 1u) return FALSE;
    memcpy(snapshot, self->shared, sizeof(*snapshot));
    __atomic_thread_fence(__ATOMIC_ACQUIRE);
    uint32_t after = __atomic_load_n(&self->shared->seq, __ATOMIC_ACQUIRE);
    if(before != after || (after & 1u) || snapshot->magic != BOX_MAGIC ||
       snapshot->count > MAX_BOXES || snapshot->updated_us > (uint64_t)now_us ||
       (uint64_t)now_us - snapshot->updated_us > MAX_AGE_US)
        return FALSE;
    return TRUE;
}

static GstFlowReturn transform_ip(GstBaseTransform *base, GstBuffer *buffer) {
    GstRkAiOverlay *self = (GstRkAiOverlay *)base;
    gint64 now_us = g_get_monotonic_time();
    AiSnapshot snapshot;
    gboolean valid = read_snapshot(self, &snapshot, now_us);
    self->frames++;
    if(valid && snapshot.count) {
        GstVideoFrame frame;
        gint64 map_started = g_get_monotonic_time();
        if(!gst_video_frame_map(&frame, &self->info, buffer, GST_MAP_READWRITE))
            return GST_FLOW_ERROR;
        gint64 draw_started = g_get_monotonic_time();
        uint8_t *data = GST_VIDEO_FRAME_PLANE_DATA(&frame, 0);
        int stride = GST_VIDEO_FRAME_PLANE_STRIDE(&frame, 0);
        int width = GST_VIDEO_FRAME_WIDTH(&frame);
        int height = GST_VIDEO_FRAME_HEIGHT(&frame);
        for(uint32_t i = 0; i < snapshot.count; ++i) {
            const AiBox *box = &snapshot.boxes[i];
            if(!isfinite(box->x1) || !isfinite(box->y1) ||
               !isfinite(box->x2) || !isfinite(box->y2) ||
               !isfinite(box->score) || box->score < 0 || box->score > 1 ||
               box->x1 < -width || box->x2 > width * 2 ||
               box->y1 < -height || box->y2 > height * 2)
                continue;
            int x1 = (int)box->x1, y1 = (int)box->y1;
            int x2 = (int)box->x2, y2 = (int)box->y2;
            if(x1 >= x2 || y1 >= y2) continue;
            /* Thin amber outlines keep the source image visible. */
            fill_rect(data, stride, width, height, x1, y1, x2 + 1, y1 + 2, 255, 150, 0);
            fill_rect(data, stride, width, height, x1, y2 - 1, x2 + 1, y2 + 1, 255, 150, 0);
            fill_rect(data, stride, width, height, x1, y1, x1 + 2, y2 + 1, 255, 150, 0);
            fill_rect(data, stride, width, height, x2 - 1, y1, x2 + 1, y2 + 1, 255, 150, 0);
            char label[24];
            snprintf(label, sizeof(label), "C%u:%.2f", box->cls, box->score);
            int label_width = (int)strlen(label) * 12 + 8;
            int lx = x1 < 0 ? 0 : x1;
            if(lx + label_width > width) lx = width - label_width;
            if(lx < 0) lx = 0;
            int ly = y1 >= 22 ? y1 - 22 : y1 + 3;
            if(ly + 18 > height) ly = height - 18;
            fill_rect(data, stride, width, height,
                      lx, ly, lx + label_width, ly + 18, 65, 35, 8);
            draw_label(data, stride, width, height, lx + 4, ly + 2, label);
        }
        gint64 unmap_started = g_get_monotonic_time();
        gst_video_frame_unmap(&frame);
        gint64 unmap_finished = g_get_monotonic_time();
        self->map_us += (uint64_t)(draw_started - map_started);
        self->draw_us += (uint64_t)(unmap_started - draw_started);
        self->unmap_us += (uint64_t)(unmap_finished - unmap_started);
        self->frames_with_boxes++;
        self->total_boxes += snapshot.count;
    }
    uint64_t elapsed_us = (uint64_t)(g_get_monotonic_time() - now_us);
    self->total_us += elapsed_us;
    if(elapsed_us > self->max_us) self->max_us = elapsed_us;
    if(now_us - self->last_log_us >= 5 * G_USEC_PER_SEC) {
        g_print("AI overlay frames=%lu with_boxes=%lu boxes=%lu latest=%u avg_us=%.1f max_us=%lu map=%.1f draw=%.1f unmap=%.1f\n",
                (unsigned long)self->frames, (unsigned long)self->frames_with_boxes,
                (unsigned long)self->total_boxes, valid ? snapshot.count : 0,
                (double)self->total_us / self->frames, (unsigned long)self->max_us,
                (double)self->map_us / (self->frames_with_boxes ? self->frames_with_boxes : 1),
                (double)self->draw_us / (self->frames_with_boxes ? self->frames_with_boxes : 1),
                (double)self->unmap_us / (self->frames_with_boxes ? self->frames_with_boxes : 1));
        self->last_log_us = now_us;
    }
    return GST_FLOW_OK;
}

static void gst_rk_ai_overlay_finalize(GObject *object) {
    GstRkAiOverlay *self = (GstRkAiOverlay *)object;
    if(self->shared) munmap((void *)self->shared, sizeof(AiSnapshot));
    if(self->fd >= 0) close(self->fd);
    G_OBJECT_CLASS(gst_rk_ai_overlay_parent_class)->finalize(object);
}

static void gst_rk_ai_overlay_class_init(GstRkAiOverlayClass *klass) {
    GObjectClass *object_class = G_OBJECT_CLASS(klass);
    GstElementClass *element = GST_ELEMENT_CLASS(klass);
    GstBaseTransformClass *transform = GST_BASE_TRANSFORM_CLASS(klass);
    gst_element_class_set_static_metadata(element, "RK AI box overlay",
        "Filter/Effect/Video", "Async YOLO boxes on RGBx HDMI video", "Codex");
    gst_element_class_add_static_pad_template(element, &sink_template);
    gst_element_class_add_static_pad_template(element, &src_template);
    transform->set_caps = set_caps;
    transform->transform_ip = transform_ip;
    object_class->finalize = gst_rk_ai_overlay_finalize;
}

static void gst_rk_ai_overlay_init(GstRkAiOverlay *self) {
    self->fd = open(BOX_PATH, O_RDONLY);
    self->shared = self->fd >= 0 ? mmap(NULL, sizeof(AiSnapshot), PROT_READ,
                                         MAP_SHARED, self->fd, 0) : MAP_FAILED;
    if(self->shared == MAP_FAILED) self->shared = NULL;
    self->last_log_us = g_get_monotonic_time();
    gst_base_transform_set_in_place(GST_BASE_TRANSFORM(self), TRUE);
}

static gboolean plugin_init(GstPlugin *plugin) {
    return gst_element_register(plugin, "rkaioverlay", GST_RANK_NONE,
                                gst_rk_ai_overlay_get_type());
}

GST_PLUGIN_DEFINE(GST_VERSION_MAJOR, GST_VERSION_MINOR, rkaioverlay,
                  "RK YOLO box overlay", plugin_init, "1.0",
                  "LGPL", "rkaioverlay", "local")
