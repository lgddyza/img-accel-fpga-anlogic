#!/bin/sh
JPEG_AI_INTERVAL=4 JPEG_AI_SECONDS=45 \
    sh /root/jpeg_rk/start_jpeg_hdmi_ai.sh 188 \
    > /root/road_damage_yolov8n/ai_interval_4.log 2>&1
exec sh /root/jpeg_rk/start_jpeg_hdmi_ai_fallback.sh 188
