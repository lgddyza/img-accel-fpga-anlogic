#!/bin/sh
JPEG_AI_INTERVAL=12 JPEG_AI_SECONDS=50 \
    sh /root/jpeg_rk/start_jpeg_hdmi_ai.sh 188 \
    > /root/road_damage_yolov8n/ai_interval_12_adjacent.log 2>&1
exec sh /root/jpeg_rk/start_jpeg_hdmi_ai_fallback.sh 188
