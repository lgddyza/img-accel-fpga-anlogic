#!/bin/sh
JPEG_AI_INTERVAL=3 JPEG_AI_SECONDS=40 \
    sh /root/jpeg_rk/start_jpeg_hdmi_ai.sh 188 \
    > /root/road_damage_yolov8n/ai_interval_3_pinned.log 2>&1 &
viewer_launcher=$!
sleep 8
viewer=$(pgrep -f '^python3 /root/jpeg_rk/show_jpeg_hdmi_overlay.py' | head -1)
if [ -n "$viewer" ]; then
    ai_tid=
    for task in /proc/"$viewer"/task/*; do
        tid=${task##*/}
        name=$(cat "$task/comm")
        case "$name" in
            display_queue:s) taskset -pc 7 "$tid" ;;
            pool-python3) ai_tid=$tid ;;
        esac
    done
    if [ -n "$ai_tid" ]; then taskset -pc 6 "$ai_tid"; fi
fi
wait "$viewer_launcher"
exec sh /root/jpeg_rk/start_jpeg_hdmi_ai_fallback.sh 188
