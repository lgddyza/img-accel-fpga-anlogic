/* Small in-place RGBx OSD for the RK HDMI viewer. */
#include <gst/base/gstbasetransform.h>
#include <gst/video/video.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <stdint.h>
#include <sys/mman.h>
#include <unistd.h>
#include <math.h>

#define BAR_PATH "/sys/bus/pci/devices/0000:21:00.0/resource0"
#define CONTROL_ABI 0x4a435431u
#define BOX_PATH "/run/road_ai_boxes.bin"
#define BOX_MAGIC 0x52414942u
#define MAX_BOXES 64
#define MAX_AGE_US 500000

#define PACKAGE "rkfastaiosd"

typedef struct {
    float x1, y1, x2, y2, score;
    uint32_t cls;
} AiBox;
typedef struct {
    uint32_t magic, seq;
    uint64_t updated_us;
    uint32_t count, reserved;
    AiBox boxes[MAX_BOXES];
} AiSnapshot;
_Static_assert(sizeof(AiSnapshot) == 1560, "overlay ABI size mismatch");

typedef struct {
    GstBaseTransform parent;
    GstVideoInfo info;
    gint64 second_start;
    guint frames_this_second;
    double fps;
    void *bar;
    int bar_fd;
    unsigned int quality;
    gboolean quality_valid;
    int boxes_fd;
    const AiSnapshot *boxes_shared;
    uint64_t boxes_frames, boxes_drawn, boxes_draw_us;
} GstRkFastAiOsd;

typedef struct {
    GstBaseTransformClass parent_class;
} GstRkFastAiOsdClass;

G_DEFINE_TYPE(GstRkFastAiOsd, gst_rk_fast_ai_osd, GST_TYPE_BASE_TRANSFORM)

static GstStaticPadTemplate sink_template = GST_STATIC_PAD_TEMPLATE(
    "sink", GST_PAD_SINK, GST_PAD_ALWAYS,
    GST_STATIC_CAPS("video/x-raw,format=(string)RGBx"));
static GstStaticPadTemplate src_template = GST_STATIC_PAD_TEMPLATE(
    "src", GST_PAD_SRC, GST_PAD_ALWAYS,
    GST_STATIC_CAPS("video/x-raw,format=(string)RGBx"));

/* Five columns, seven rows. Only characters used by the status line. */
static void glyph(char c, unsigned char out[7]) {
    static const unsigned char digits[10][7] = {
        {14,17,19,21,25,17,14}, {4,12,4,4,4,4,14},
        {14,17,1,2,4,8,31}, {30,1,1,14,1,1,30},
        {2,6,10,18,31,2,2}, {31,16,16,30,1,1,30},
        {14,16,16,30,17,17,14}, {31,1,2,4,8,8,8},
        {14,17,17,14,17,17,14}, {14,17,17,15,1,1,14}
    };
    if(c >= '0' && c <= '9') {
        memcpy(out, digits[c-'0'], 7);
        return;
    }
    static const unsigned char h[7] = {17,17,17,31,17,17,17};
    static const unsigned char d[7] = {30,17,17,17,17,17,30};
    static const unsigned char m[7] = {17,27,21,21,17,17,17};
    static const unsigned char i[7] = {31,4,4,4,4,4,31};
    static const unsigned char f[7] = {31,16,16,30,16,16,16};
    static const unsigned char p[7] = {30,17,17,30,16,16,16};
    static const unsigned char s[7] = {15,16,16,14,1,1,30};
    static const unsigned char x[7] = {0,17,10,4,10,17,0};
    static const unsigned char colon[7] = {0,4,4,0,4,4,0};
    static const unsigned char point[7] = {0,0,0,0,0,4,4};
    static const unsigned char q[7] = {14,17,17,17,21,18,13};
    static const unsigned char c_letter[7] = {14,17,16,16,16,17,14};
    const unsigned char *rows = NULL;
    switch(c) {
    case 'H': rows=h; break; case 'D': rows=d; break;
    case 'M': rows=m; break; case 'I': rows=i; break;
    case 'F': rows=f; break; case 'P': rows=p; break;
    case 'S': rows=s; break; case 'x': rows=x; break;
    case 'Q': rows=q; break;
    case 'C': rows=c_letter; break;
    case ':': rows=colon; break; case '.': rows=point; break;
    default: memset(out, 0, 7); return;
    }
    memcpy(out, rows, 7);
}

static gboolean read_boxes(GstRkFastAiOsd *self, AiSnapshot *snapshot,
                           gint64 now_us) {
    if(!self->boxes_shared) return FALSE;
    uint32_t before = __atomic_load_n(&self->boxes_shared->seq, __ATOMIC_ACQUIRE);
    if(before & 1u) return FALSE;
    memcpy(snapshot, self->boxes_shared, sizeof(*snapshot));
    __atomic_thread_fence(__ATOMIC_ACQUIRE);
    uint32_t after = __atomic_load_n(&self->boxes_shared->seq, __ATOMIC_ACQUIRE);
    return before == after && !(after & 1u) && snapshot->magic == BOX_MAGIC &&
           snapshot->count <= MAX_BOXES &&
           snapshot->updated_us <= (uint64_t)now_us &&
           (uint64_t)now_us - snapshot->updated_us <= MAX_AGE_US;
}

static void rect(unsigned char *data, int stride, int width, int height,
                 int x1, int y1, int x2, int y2, uint32_t color) {
    if(x1 < 0) x1 = 0;
    if(y1 < 0) y1 = 0;
    if(x2 > width) x2 = width;
    if(y2 > height) y2 = height;
    if(x1 >= x2 || y1 >= y2) return;
    for(int y = y1; y < y2; ++y) {
        uint32_t *row = (uint32_t *)(data + y * stride);
        for(int x = x1; x < x2; ++x) row[x] = color;
    }
}

static void draw_ai_boxes(GstRkFastAiOsd *self, unsigned char *data,
                          int stride, int width, int height,
                          const AiSnapshot *snapshot) {
    const uint32_t amber = 0xff0096ffu; /* RGBx bytes: 255, 150, 0, 255. */
    const uint32_t panel = 0xff082341u;
    const uint32_t white = 0xffffffffu;
    for(uint32_t i = 0; i < snapshot->count; ++i) {
        const AiBox *box = &snapshot->boxes[i];
        if(!isfinite(box->x1) || !isfinite(box->y1) ||
           !isfinite(box->x2) || !isfinite(box->y2) ||
           !isfinite(box->score) || box->score < 0 || box->score > 1 ||
           box->x1 < -width || box->x2 > width * 2 ||
           box->y1 < -height || box->y2 > height * 2)
            continue;
        int x1 = (int)box->x1, y1 = (int)box->y1;
        int x2 = (int)box->x2, y2 = (int)box->y2;
        if(x1 >= x2 || y1 >= y2) continue;
        rect(data, stride, width, height, x1, y1, x2 + 1, y1 + 2, amber);
        rect(data, stride, width, height, x1, y2 - 1, x2 + 1, y2 + 1, amber);
        rect(data, stride, width, height, x1, y1, x1 + 2, y2 + 1, amber);
        rect(data, stride, width, height, x2 - 1, y1, x2 + 1, y2 + 1, amber);
        char label[24];
        snprintf(label, sizeof(label), "C%u:%.2f", box->cls, box->score);
        int label_width = (int)strlen(label) * 12 + 8;
        int lx = x1 < 0 ? 0 : x1;
        if(lx + label_width > width) lx = width - label_width;
        if(lx < 0) lx = 0;
        int ly = y1 >= 22 ? y1 - 22 : y1 + 3;
        if(ly + 18 > height) ly = height - 18;
        rect(data, stride, width, height, lx, ly,
             lx + label_width, ly + 18, panel);
        int tx = lx + 4;
        for(const char *p = label; *p; ++p, tx += 12) {
            unsigned char rows[7];
            glyph(*p, rows);
            for(int gy = 0; gy < 7; ++gy)
                for(int gx = 0; gx < 5; ++gx)
                    if(rows[gy] & (1u << (4 - gx)))
                        rect(data, stride, width, height,
                             tx + gx * 2, ly + 2 + gy * 2,
                             tx + gx * 2 + 2, ly + 4 + gy * 2, white);
        }
        self->boxes_drawn++;
    }
}

static gboolean set_caps(GstBaseTransform *base, GstCaps *in, GstCaps *out) {
    (void)out;
    return gst_video_info_from_caps(&((GstRkFastAiOsd *)base)->info, in);
}

static GstFlowReturn transform_ip(GstBaseTransform *base, GstBuffer *buffer) {
    GstRkFastAiOsd *self = (GstRkFastAiOsd *)base;
    gint64 now = g_get_monotonic_time();
    if(self->second_start == 0) self->second_start = now;
    self->frames_this_second++;
    if(now - self->second_start >= G_USEC_PER_SEC) {
        self->fps = (double)self->frames_this_second * G_USEC_PER_SEC /
                    (double)(now - self->second_start);
        self->frames_this_second = 0;
        self->second_start = now;
        if(self->bar != MAP_FAILED) {
            volatile const uint32_t *regs = (volatile const uint32_t *)self->bar;
            uint32_t applied = regs[0xf8 / 4];
            self->quality_valid = (regs[0xfc / 4] == CONTROL_ABI) &&
                                  ((applied & 0x80u) != 0);
            self->quality = applied & 0x7fu;
        }
        if(self->quality_valid)
            g_print("HDMI 1920x1080 FPS:%.1f QF:%u\n",
                    self->fps, self->quality);
        else
            g_print("HDMI 1920x1080 FPS:%.1f\n", self->fps);
    }

    GstVideoFrame frame;
    if(!gst_video_frame_map(&frame, &self->info, buffer, GST_MAP_READWRITE))
        return GST_FLOW_ERROR;
    unsigned char *data = GST_VIDEO_FRAME_PLANE_DATA(&frame, 0);
    int stride = GST_VIDEO_FRAME_PLANE_STRIDE(&frame, 0);
    int width = GST_VIDEO_FRAME_WIDTH(&frame);
    int height = GST_VIDEO_FRAME_HEIGHT(&frame);
    if(width >= 450 && height >= 60) {
        char label[80];
        if(self->quality_valid)
            snprintf(label, sizeof(label), "HDMI 1920x1080 FPS:%.1f QF:%u",
                     self->fps, self->quality);
        else
            snprintf(label, sizeof(label), "HDMI 1920x1080 FPS:%.1f", self->fps);
        /* Draw a small opaque panel and 2x white bitmap glyphs. */
        for(int y=16; y<48; ++y) {
            unsigned char *row = data + y*stride + 16*4;
            for(int x=16; x<440; ++x, row+=4) {
                row[0]=16; row[1]=40; row[2]=64; row[3]=255;
            }
        }
        int x0=24;
        for(const char *p=label; *p && x0<430; ++p, x0+=12) {
            unsigned char rows[7];
            glyph(*p, rows);
            for(int gy=0; gy<7; ++gy)
                for(int gx=0; gx<5; ++gx)
                    if(rows[gy] & (1u << (4-gx)))
                        for(int sy=0; sy<2; ++sy)
                            for(int sx=0; sx<2; ++sx) {
                                unsigned char *pixel = data + (24+gy*2+sy)*stride +
                                                       (x0+gx*2+sx)*4;
                                pixel[0]=255; pixel[1]=255; pixel[2]=255;
                                pixel[3]=255;
                            }
        }
    }
    AiSnapshot snapshot;
    if(read_boxes(self, &snapshot, now) && snapshot.count) {
        gint64 draw_started = g_get_monotonic_time();
        draw_ai_boxes(self, data, stride, width, height, &snapshot);
        self->boxes_frames++;
        self->boxes_draw_us += g_get_monotonic_time() - draw_started;
    }
    gst_video_frame_unmap(&frame);
    if(self->frames_this_second == 0 && self->boxes_frames)
        g_print("AI combined OSD box_frames=%lu boxes=%lu avg_draw_us=%.1f\n",
                (unsigned long)self->boxes_frames,
                (unsigned long)self->boxes_drawn,
                (double)self->boxes_draw_us / self->boxes_frames);
    return GST_FLOW_OK;
}

static void gst_rk_fast_ai_osd_finalize(GObject *object);

static void gst_rk_fast_ai_osd_class_init(GstRkFastAiOsdClass *klass) {
    GObjectClass *object_class = G_OBJECT_CLASS(klass);
    GstElementClass *element = GST_ELEMENT_CLASS(klass);
    GstBaseTransformClass *transform = GST_BASE_TRANSFORM_CLASS(klass);
    gst_element_class_set_static_metadata(element, "RK fast HDMI OSD",
        "Filter/Effect/Video", "In-place 1080p grayscale status overlay", "Codex");
    gst_element_class_add_static_pad_template(element, &sink_template);
    gst_element_class_add_static_pad_template(element, &src_template);
    transform->set_caps = set_caps;
    transform->transform_ip = transform_ip;
    object_class->finalize = gst_rk_fast_ai_osd_finalize;
}

static void gst_rk_fast_ai_osd_init(GstRkFastAiOsd *self) {
    self->second_start = 0;
    self->frames_this_second = 0;
    self->fps = 0;
    self->bar_fd = open(BAR_PATH, O_RDWR | O_SYNC);
    self->bar = self->bar_fd >= 0 ? mmap(NULL, 4096, PROT_READ | PROT_WRITE,
                                         MAP_SHARED, self->bar_fd, 0) : MAP_FAILED;
    self->quality_valid = FALSE;
    self->boxes_fd = open(BOX_PATH, O_RDONLY);
    self->boxes_shared = self->boxes_fd >= 0 ?
        mmap(NULL, sizeof(AiSnapshot), PROT_READ, MAP_SHARED, self->boxes_fd, 0) :
        MAP_FAILED;
    if(self->boxes_shared == MAP_FAILED) self->boxes_shared = NULL;
    gst_base_transform_set_in_place(GST_BASE_TRANSFORM(self), TRUE);
}

static void gst_rk_fast_ai_osd_finalize(GObject *object) {
    GstRkFastAiOsd *self = (GstRkFastAiOsd *)object;
    if(self->bar != MAP_FAILED) munmap(self->bar, 4096);
    if(self->bar_fd >= 0) close(self->bar_fd);
    if(self->boxes_shared) munmap((void *)self->boxes_shared, sizeof(AiSnapshot));
    if(self->boxes_fd >= 0) close(self->boxes_fd);
    G_OBJECT_CLASS(gst_rk_fast_ai_osd_parent_class)->finalize(object);
}

static gboolean plugin_init(GstPlugin *plugin) {
    return gst_element_register(plugin, "rkfastaiosd", GST_RANK_NONE,
                                gst_rk_fast_ai_osd_get_type());
}

GST_PLUGIN_DEFINE(GST_VERSION_MAJOR, GST_VERSION_MINOR, rkfastaiosd,
                  "Lightweight RK HDMI status overlay", plugin_init, "1.0",
                  "LGPL", "rkfastaiosd", "local")
