"""Fit a small preprocessing gain tree to paired RK results, grouped by source scene."""
import json
import sys
from collections import Counter
from pathlib import Path

import numpy as np
from sklearn.model_selection import GroupKFold
from sklearn.tree import DecisionTreeRegressor, export_text
import run_study as study

ROOT=study.ROOT
OUT=ROOT.parent.parent/'RK_DUAL_SOBEL_20261031/rk/preprocess_tree.py'
records=json.loads((study.DATA/'records.json').read_text(encoding='utf8'))
lookup={(r['image'],r['condition'],r['action']):r for r in records}
features=[];targets=[];groups=[];keys=[]
for row in study.rows_for_study():
    base=study.prior.base_image(row)
    for condition in study.CONDITIONS:
        baseline=lookup[(row['image'],condition,'gray')]
        seed=baseline['seed']
        image=study.degraded(base,condition,seed)
        obs=study.ref.observe(image)
        features.append(obs['features'])
        targets.append([lookup[(row['image'],condition,action)]['utility']-baseline['utility']
                        for action in study.ACTIONS[1:]])
        groups.append(row['group']);keys.append((row['image'],condition))
X=np.asarray(features,dtype=float);Y=np.asarray(targets,dtype=float);groups=np.asarray(groups)
def tree():return DecisionTreeRegressor(max_depth=2,min_samples_leaf=25,random_state=20261031)
def select(pred):
    best=np.argmax(pred,axis=1);gain=pred[np.arange(len(best)),best]
    return np.where(gain>.01,best+1,0)
oof=np.zeros_like(Y)
for train,test in GroupKFold(n_splits=5).split(X,Y,groups):
    model=tree().fit(X[train],Y[train]);oof[test]=model.predict(X[test])
choice=select(oof);gains=np.column_stack((np.zeros(len(Y)),Y))
chosen=gains[np.arange(len(Y)),choice]
model=tree().fit(X,Y);t=model.tree_
payload=dict(version='OBS_TREE_20261031',features=list(study.ref.NAMES),
    actions=list(study.ACTIONS),mode_ids=[0,1,2,3,4,5],gain_floor=.01,
    left=t.children_left.tolist(),right=t.children_right.tolist(),feature=t.feature.tolist(),
    threshold=t.threshold.tolist(),value=t.value[:,:,0].tolist())
report=dict(samples=len(X),groups=len(set(groups)),feature_names=payload['features'],
    model_text=export_text(model,feature_names=payload['features']),
    out_of_fold=dict(mean_utility_gain=float(chosen.mean()),
        fraction_positive=float((chosen>0).mean()),fraction_negative=float((chosen<0).mean()),
        selection_counts=dict(Counter(study.ACTIONS[i] for i in choice))),
    limitations=['exploratory historical test cohort reused for training',
        'utility uses incomplete inherited bounding-box labels',
        '4:3 content padded to 16:9; domain differs from live cameras',
        'out-of-fold results are not an independent external evaluation',
        'tree predicts preprocessing gain only; QF and YOLO use rules'])
study.write(study.DATA/'decision_tree_training.json',report)
study.write(study.DATA/'decision_tree_dataset.json',[dict(image=k[0],condition=k[1],group=str(g),features=x.tolist(),gains=y.tolist()) for k,g,x,y in zip(keys,groups,X,Y)])
OUT.write_text('"""Frozen shallow regression tree trained from paired simulated conditions."""\nTREE = '+repr(payload)+'\n',encoding='utf8')
print(json.dumps(report,ensure_ascii=False,indent=2))
