"""DVC2 control agent. No legacy BAR writes and no implicit DMA ownership."""
import base64
import contextlib
import fcntl
import json
import os
import re
from pathlib import Path
import signal
import sqlite3
import subprocess
import sys
import time

ROOT = Path('/root/dual_vision_host')
RUN = ROOT/'run'
LOG_MOUNT = Path('/mnt/vision_sd')
BAR = Path('/sys/bus/pci/devices/0000:21:00.0/resource0')
PCIE_DRIVER = Path('/sys/bus/platform/drivers/rk-pcie')
PCIE_DEVICE = Path('/sys/bus/platform/devices/2a210000.pcie')
DMA_DEVICES = tuple(Path(f'/dev/ANLOGIC-PCI0_c2h_{channel}') for channel in (1,2,3))
BUILDS = ('0x53545233', '0x53545234', '0x53545235', '0x4f425331', '0x50524631', '0x434c4131', '0x434c4132', '0x434c4133', '0x434c4134', '0x434c4135', '0x434c4136', '0x434c4137', '0x434c4138', '0x434c4139', '0x44514631')
LEGACY_NAMES = {'show_jpeg_hdmi.py', 'show_jpeg_hdmi_overlay.py', 'start_jpeg_hdmi_ai_fallback.sh'}


def load_json(path):
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError):
        return None


def bundle():
    value = Path((ROOT/'bundle.path').read_text().strip())
    if value.parent != ROOT/'releases' or not value.is_dir():
        raise RuntimeError('双路运行文件尚未部署')
    return value


@contextlib.contextmanager
def locked(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a') as file:
        fcntl.flock(file, fcntl.LOCK_EX)
        yield


def processes():
    result = []
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            args = (proc/'cmdline').read_bytes().decode(errors='replace').split('\0')
            names = {Path(a).name for a in args if a.endswith('.py') or a.endswith('.sh')}
            if 'dual_hdmi_bringup.py' not in names and not names.intersection(LEGACY_NAMES):
                continue
            stat = (proc/'stat').read_text().rsplit(')', 1)[1].split()
            if stat[0] != 'Z':
                result.append(dict(pid=int(proc.name), start_ticks=stat[19],
                    kind='dual' if 'dual_hdmi_bringup.py' in names else 'legacy'))
        except (OSError, ValueError, IndexError):
            pass
    return result


def alive(proc):
    try:
        stat = Path(f"/proc/{proc['pid']}/stat").read_text().rsplit(')',1)[1].split()
        return stat[0]!='Z' and stat[19]==proc['start_ticks']
    except (OSError, IndexError):
        return False


def control(arguments=()):
    config = BAR.with_name('config')
    if not config.exists():
        raise RuntimeError('RK已连接，但未识别到FPGA PCIe设备；请确认位流烧录完成，'
                           '停止视频后在设置中点击“重新连接 PCIe”')
    with config.open('rb') as file:
        file.seek(4)
        if not int.from_bytes(file.read(2),'little') & 2:
            raise RuntimeError('PCIe内存访问未启用，请先停止接收并重新连接PCIe')
    with locked(RUN/'bar.lock'):
        def invoke(options):
            result = subprocess.run([sys.executable,str(bundle()/'dual_control.py'),'--bar',str(BAR),*options],
                capture_output=True,text=True,timeout=5)
            if result.returncode:
                raise RuntimeError(result.stderr.strip() or result.stdout.strip() or 'PCIe状态读取失败')
            data = json.loads(result.stdout)
            if (data.get('stream_diagnostics') or {}).get('build') not in BUILDS:
                raise RuntimeError('板上不是受支持的双路DVC2位流')
            return data
        data = invoke(())
        if arguments:
            data = invoke(arguments)
            if any(option in arguments for option in ('--quality','--quality-a','--quality-b','--independent-qf')):
                RUN.mkdir(exist_ok=True)
                marker = RUN/'manual_qf'
                temporary = marker.with_name('manual_qf.tmp')
                temporary.write_text(str(time.monotonic_ns()))
                temporary.replace(marker)
            for camera, option in (('a','--mode-a'),('b','--mode-b')):
                if option in arguments:
                    RUN.mkdir(exist_ok=True)
                    marker = RUN/('manual_mode_'+camera)
                    temporary = marker.with_suffix('.tmp')
                    temporary.write_text(str(time.monotonic_ns()))
                    temporary.replace(marker)
    return data


def resources():
    ticks = [int(x) for x in Path('/proc/stat').read_text().splitlines()[0].split()[1:]]
    memory = {line.split(':')[0]: int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines()}
    temperature = None
    for path in Path('/sys/class/thermal').glob('thermal_zone*/temp'):
        try:
            temperature = max(temperature or 0,int(path.read_text())/1000)
        except (OSError, ValueError):
            pass
    npu_load = None
    try:
        raw = Path('/sys/kernel/debug/rknpu/load').read_text()
        cores = re.findall(r'Core\s*(\d+)\s*:\s*(\d+(?:\.\d+)?)\s*%', raw, re.I)
        if cores:
            npu_load = {str(int(core)):float(value) for core,value in cores if 0<=float(value)<=100}
    except OSError:
        pass
    link = None
    try:
        speed = float((BAR.parent/'current_link_speed').read_text().split()[0])
        width = int((BAR.parent/'current_link_width').read_text().strip())
        if speed>0 and width>0:
            link = dict(speed_gtps=speed, width=width)
    except (OSError, ValueError, IndexError):
        pass
    return dict(cpu_total=sum(ticks[:8]), cpu_idle=ticks[3]+ticks[4],
        memory_total_mb=memory['MemTotal']/1024, memory_available_mb=memory['MemAvailable']/1024,
        temperature=temperature, boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
        npu_load=npu_load, pcie_link=link)


def status():
    found = processes()
    live = load_json(RUN/'live.json')
    now = time.monotonic()
    fresh = bool(live and live.get('running') and 0<=now-live.get('sample_s',0)<=3
                 and any(p['pid']==live['pid'] for p in found))
    hardware, error = None, None
    if fresh:
        cached = live['board']
        word = cached['control']
        hardware = dict(stream_diagnostics=cached['stream_diagnostics'], supported_modes=None,
            requested=word, applied_quality=None, statistics=cached['statistics'],
            store_diagnostics=cached.get('store_diagnostics'), diagnostics=cached['diagnostics'],
            feature_observations=cached.get('feature_observations'))
        # Capability/QF registers are included by the managed receiver.
        hardware.update(cached.get('configuration', {}))
    else:
        try:
            hardware = control()
        except Exception as exc:
            error = str(exc)
    return dict(schema=1, sample_s=now, processes=found, runtime='managed' if fresh else
        ('external' if found else 'stopped'), stale=bool(found and not fresh),
        live=live if fresh else None, hardware=hardware, hardware_error=error, resources=resources(),
        capabilities=dict(yolo=True, qf_shared=True, modes=(hardware or {}).get('supported_modes',0)))


def stop():
    found = processes()
    if any(p['kind']=='legacy' for p in found):
        raise RuntimeError('旧单路查看器正在运行，请从原上位机停止后再接入双路程序')
    for proc in found:
        if alive(proc):
            os.kill(proc['pid'], signal.SIGTERM)
    deadline = time.monotonic()+16
    while any(alive(p) for p in found) and time.monotonic()<deadline:
        time.sleep(.1)
    if any(alive(p) for p in found):
        raise RuntimeError('原接收进程尚未退出，未启动第二个DMA读取者')


def integer(value, name, low, high):
    if type(value) is not int or not low<=value<=high:
        raise ValueError(f'{name}必须为{low}～{high}的整数')
    return value


def recover_pcie():
    if processes():
        raise RuntimeError('请先停止视频再重新连接PCIe')
    if not PCIE_DRIVER.is_dir() or not PCIE_DEVICE.is_dir():
        raise RuntimeError('未找到当前主板的PCIe控制器或驱动')
    link = PCIE_DEVICE/'driver'
    if link.is_symlink():
        if link.resolve()!=PCIE_DRIVER.resolve():
            raise RuntimeError('PCIe平台设备绑定了其他驱动，未执行恢复')
        (PCIE_DRIVER/'unbind').write_text(PCIE_DEVICE.name)
        time.sleep(1)
    # A failed boot-time probe leaves no driver link; bind directly in that case.
    (PCIE_DRIVER/'bind').write_text(PCIE_DEVICE.name)
    deadline = time.monotonic()+15
    while time.monotonic()<deadline:
        if (link.is_symlink() and link.resolve()==PCIE_DRIVER.resolve()
                and BAR.with_name('config').exists()
                and all(path.exists() for path in DMA_DEVICES)):
            control()
            return
        time.sleep(.2)
    raise RuntimeError('PCIe重新建链未完成或DMA设备未就绪；请确认FPGA位流已烧录完成，'
                       '再重试。可查看RK内核日志确认Link Fail原因')


def apply(request):
    if 'osd' in request and type(request['osd']) is not bool:
        raise ValueError('OSD必须为布尔值')
    before = status()['hardware']
    if not before:
        raise RuntimeError('未读取到FPGA状态')
    args = []
    if any(k in request for k in ('quality_a','quality_b','independent_qf')):
        if not before.get('dual_qf_supported'):
            raise ValueError('当前位流不支持双路独立QF')
        if 'independent_qf' in request:
            if type(request['independent_qf']) is not bool: raise ValueError('独立QF开关必须为布尔值')
            args.extend(['--independent-qf',str(int(request['independent_qf']))])
    for name, option, low, high in (('display','--display',0,1),('quality','--quality',1,100),
            ('quality_a','--quality-a',1,100),('quality_b','--quality-b',1,100),
            ('mode_a','--mode-a',0,5),('mode_b','--mode-b',0,5),
            ('gauss_a','--gauss-a',0,4),('gauss_b','--gauss-b',0,4)):
        if name in request:
            value = integer(request[name],name,low,high)
            if name.startswith('mode') and not (before.get('supported_modes') or 0)&(1<<value):
                raise ValueError('当前位流未实现此预处理模式')
            args.extend([option,str(value)])
    if args:
        before = control(args)
    if 'osd' in request:
        RUN.mkdir(exist_ok=True)
        settings = RUN/'display.json'
        temporary = settings.with_suffix('.tmp')
        temporary.write_text(json.dumps(dict(osd=request['osd'])))
        temporary.replace(settings)
    if any(k in request for k in ('yolo_a','yolo_b','yolo_confidence','adaptive_enabled')):
        RUN.mkdir(exist_ok=True)
        settings=RUN/'yolo.json'
        old=load_json(settings) or {'enable_a':False,'enable_b':False,'confidence':0.1}
        for name,key in (('yolo_a','enable_a'),('yolo_b','enable_b')):
            if name in request:
                if type(request[name]) is not bool:raise ValueError(name+'必须为布尔值')
                old[key]=request[name]
        if 'adaptive_enabled' in request:
            if type(request['adaptive_enabled']) is not bool:raise ValueError('自适应开关必须为布尔值')
            old['adaptive_enabled']=request['adaptive_enabled']
        if 'yolo_confidence' in request:
            value=request['yolo_confidence']
            if type(value) not in (int,float) or not 0.01<=value<=1.0:raise ValueError('YOLO置信度须在0.01到1之间')
            old['confidence']=value
        temporary=settings.with_suffix('.tmp')
        temporary.write_text(json.dumps(old));temporary.replace(settings)
    return before


def start(request):
    quality = integer(request.get('quality',85),'QF',1,100)
    display = integer(request.get('display',1),'显示通道',0,1)
    connector = integer(request.get('connector',188),'HDMI连接器',1,4096)
    current = status()
    if current['hardware_error']:
        raise RuntimeError(current['hardware_error'])
    if any(p['kind']=='legacy' for p in current['processes']):
        raise RuntimeError('请先停止旧单路程序')
    if current['runtime']=='managed':
        apply(dict(quality=quality,display=display))
        return
    stop()
    control(['--enable','0','--quality',str(quality),'--display',str(display)])
    RUN.mkdir(exist_ok=True)
    (RUN/'live.json').unlink(missing_ok=True)
    with (RUN/'receiver.log').open('ab',buffering=0) as log:
        proc = subprocess.Popen([sys.executable,'-X','faulthandler','-u',str(bundle()/'dual_hdmi_bringup.py'),
            '--seconds','inf','--save-frames','0','--status-file',str(RUN/'live.json'),
            '--display-settings',str(RUN/'display.json'),
            '--yolo-settings',str(RUN/'yolo.json'),
            '--preview-port','8767','--quiet','--connector',str(connector),'--out',str(RUN)],
            stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    deadline = time.monotonic()+5
    while time.monotonic()<deadline:
        live = load_json(RUN/'live.json')
        if live and live.get('pid')==proc.pid and live.get('running'):
            return
        if proc.poll() is not None:
            raise RuntimeError((RUN/'receiver.log').read_text(errors='replace')[-3000:])
        time.sleep(.1)
    raise RuntimeError('查看器已启动，但状态尚未就绪，请刷新检查')


def dispatch(request):
    action = request.get('action')
    if action in ('sd_list','sd_chunk'):
        if not os.path.ismount(LOG_MOUNT):raise RuntimeError('SD 卡未挂载')
        raw=request.get('path','')
        if not isinstance(raw,str) or '\x00' in raw or len(raw)>1024:raise ValueError('SD 卡路径无效')
        relative=Path(raw)
        if relative.is_absolute() or '..' in relative.parts:raise ValueError('路径必须位于 SD 卡内')
        base=LOG_MOUNT.resolve();target=(base/relative).resolve()
        if not target.is_relative_to(base):raise ValueError('路径超出 SD 卡范围')
        if action=='sd_list':
            if not target.is_dir():raise ValueError('目录不存在')
            entries=[]
            for item in sorted(target.iterdir(),key=lambda p:(not p.is_dir(),p.name.casefold()))[:500]:
                if item.is_symlink():continue
                try:
                    stat=item.stat();entries.append(dict(name=item.name,is_dir=item.is_dir(),size=stat.st_size,mtime=stat.st_mtime))
                except OSError:continue
            fs=os.statvfs(base)
            return dict(path=str(target.relative_to(base)),entries=entries,free=fs.f_bavail*fs.f_frsize,total=fs.f_blocks*fs.f_frsize,limit=500)
        if target.name=='detection_history.sqlite3' and target.parent==base/'dual_vision':
            raise ValueError('日志数据库正在写入，请使用检测日志页面查看或导出')
        if not target.is_file():raise ValueError('文件不存在')
        offset=integer(request.get('offset',0),'偏移',0,2147483647)
        length=integer(request.get('length',49152),'读取长度',1,49152)
        size=target.stat().st_size
        with target.open('rb') as handle:
            handle.seek(offset);data=handle.read(length)
        return dict(data=base64.b64encode(data).decode('ascii'),size=size,offset=offset)
    if action in ('detection_list','detection_detail'):
        if not os.path.ismount(LOG_MOUNT):raise RuntimeError('SD 卡未挂载，无法读取检测日志')
        path=LOG_MOUNT/'dual_vision'/'detection_history.sqlite3'
        if not path.exists():return {'events':[]} if action=='detection_list' else {'missing':True}
        with sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True,timeout=2) as db:
            if action=='detection_list':
                rows=db.execute('SELECT id,data FROM events ORDER BY id DESC LIMIT 40').fetchall()
                events=[]
                for ident,data in rows:
                    event=json.loads(data);boxes=event.get('boxes',[])
                    label_scores={}
                    for b in boxes:label_scores[b['label']]=max(label_scores.get(b['label'],0),b['confidence'])
                    events.append(dict(id=ident,wall_time=event['wall_time'],camera=event['camera'],
                        frame_id=event['frame_id'],mode=event['mode'],quality=event.get('quality'),
                        labels=sorted({b['label'] for b in boxes}),count=len(boxes),
                        label_scores=label_scores,max_confidence=max((b['confidence'] for b in boxes),default=0)))
                return {'events':events}
            ident=integer(request.get('id'),'记录编号',1,2147483647)
            row=db.execute('SELECT data,jpeg FROM events WHERE id=?',(ident,)).fetchone()
            if not row:return {'missing':True}
            return {'id':ident,'event':json.loads(row[0]),'jpeg':base64.b64encode(row[1]).decode('ascii')}
    if action=='status':
        return status()
    if action=='logs':
        path = RUN/'receiver.log'
        if not path.exists():
            return dict(text='暂无运行日志')
        with path.open('rb') as file:
            file.seek(max(0,path.stat().st_size-24000))
            return dict(text=file.read().decode(errors='replace'))
    if action not in ('start','stop','configure','recover'):
        raise ValueError('未知双路控制操作')
    with locked(ROOT/'operation.lock'):
        if action=='start':
            start(request)
        elif action=='stop':
            stop()
            control(['--enable','0'])
        elif action=='configure':
            apply(request)
        elif action=='recover':
            recover_pcie()
    return status()


if __name__=='__main__':
    token = sys.argv[1]
    try:
        response = dict(ok=True,data=dispatch(json.loads(base64.b64decode(sys.argv[2]))))
    except Exception as exc:
        response = dict(ok=False,error=str(exc))
    print('RKRPC_'+token+':'+json.dumps(response,ensure_ascii=True))
