"""Check running release identity, unchanged inference/storage, and SD readback."""
import base64
import hashlib
import json
from pathlib import Path
from PySide6.QtGui import QImage
from transport import SSHTransport, default_key

root = Path(__file__).resolve().parent
dest = root/'verification'/'hdmi_native_20261029'
old = json.loads((dest/'before'/'rk_payload_manifest.json').read_text())
new = json.loads((root/'rk_payload_manifest.json').read_text())
payload = (root/'rk_payload.zip').read_bytes()
assert payload == (root/'dist_hdmi_guard'/'RKDualVisionHost'/'_internal'/'rk_payload.zip').read_bytes()
digest = hashlib.sha256(payload).hexdigest()
unchanged = ('dual_preview.py','dual_yolo.py','detection_log.py',
             'libroad_parallel0.so','libroad_parallel1.so','libgstrkdualdisplay.so')
for name in unchanged:
    assert old[name] == new[name], name
c = SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
try:
    status = c.rpc(dict(action='status'))
    live = status['live']
    assert live['running'] and live['display']['probe_backend']=='native'
    assert live['display']['present_queue_capacity']==4
    assert not live['preview']['error'] and not live['yolo']['error'] and not live['detection_log']['error']
    assert (live['preview']['width'],live['preview']['height']) == (640,360)
    events = c.rpc(dict(action='detection_list'))['events']
    assert 0 < len(events) <= 40
    detail = c.rpc(dict(action='detection_detail',id=events[0]['id']))
    thumbnail = QImage.fromData(base64.b64decode(detail['jpeg']))
    assert not thumbnail.isNull()
    filename = detail['event']['image_file']
    assert Path(filename).name == filename
    image_path = 'dual_vision/detection_images/'+filename
    chunk = c.rpc(dict(action='sd_chunk',path=image_path,length=64))
    with c.client.open_sftp() as sftp:
        with sftp.open('/root/dual_vision_host/bundle.path') as file:
            release = file.read().decode().strip()
        assert release.endswith('/'+digest[:16])
        with sftp.open(f"/proc/{live['pid']}/cmdline") as file:
            assert (release+'/dual_hdmi_bringup.py').encode() in file.read()
        for name in (*unchanged,'libdisplay_probe.so'):
            with sftp.open(release+'/'+name) as file:
                assert hashlib.sha256(file.read()).hexdigest()==new[name],name
        with sftp.open('/mnt/vision_sd/'+image_path) as file:
            data = file.read()
    assert base64.b64decode(chunk['data'])==data[:64]
    image = QImage.fromData(data)
    assert not image.isNull() and (image.width(),image.height())==(1920,1080)
    result = dict(passed=True,release=release,payload_sha256=digest,
        original_components_unchanged=list(unchanged),sd_records=len(events),
        sd_image_size=[image.width(),image.height()],sd_image_bytes=len(data),
        selected=live['selected'],quality=status['hardware']['applied_quality'],
        modes=live['decoded_modes'],yolo_enabled=live['yolo']['enabled'],
        preview_size=[640,360],display_capacity=4)
    (dest/'integrity.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
finally:
    c.close()
