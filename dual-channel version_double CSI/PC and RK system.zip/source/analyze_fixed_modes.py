"""Compare successive HDMI luminance snapshots; differences include camera noise."""
import json
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw

p = Path('verification/live_fixed_20261029/hdmi_1080')
names = ('mode_0', 'mode_1', 'mode_5', 'gray_after')
arrays = {n: np.asarray(Image.open(p/(n+'.pgm')).convert('L'), dtype=np.int16) for n in names}
base = arrays['mode_0']
report = {}
for name in names[1:]:
    diff = np.abs(arrays[name]-base)
    report[name] = dict(mean_absolute=float(diff.mean()),
        over_3_percent=float((diff>3).mean()*100), over_10_percent=float((diff>10).mean()*100),
        p95=float(np.percentile(diff,95)))
    Image.fromarray(np.uint8(np.clip(diff*8,0,255))).save(p/(name+'_diff_x8.png'))
    print(name, report[name])
(p/'metrics.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
regions = (150, 0, 1200, 900)
panel = Image.new('RGB',(1050, 1000),'white')
draw = ImageDraw.Draw(panel)
for i,(name,label) in enumerate((('mode_0','Gray'),('mode_1','Gaussian'),('mode_5','Black-hat'),('gray_after','Gray again'))):
    im=Image.fromarray(np.uint8(arrays[name])).crop(regions).resize((525,450))
    x,y=(i%2)*525,(i//2)*500
    panel.paste(im.convert('RGB'),(x,y+25))
    draw.text((x+10,y+5),label,fill='black')
panel.save(p/'comparison.png')
