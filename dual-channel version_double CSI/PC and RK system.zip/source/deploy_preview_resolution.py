"""Deploy a preview-only payload with a checked inference baseline and rollback."""
import argparse,hashlib,json,shlex,time,zipfile
from pathlib import Path
from transport import SSHTransport,default_key

root=Path(__file__).resolve().parent
folder=root/'verification'/'preview720_20261029'
parser=argparse.ArgumentParser();parser.add_argument('--rollback',action='store_true');args=parser.parse_args()
old=json.loads((folder/'before'/'rk_payload_manifest.json').read_text())
new=json.loads((root/'rk_payload_manifest.json').read_text())
changed=sorted(k for k in set(old)|set(new) if old.get(k)!=new.get(k))
assert changed in ([], ['dual_preview.py']), changed
if not args.rollback and not changed:
    raise SystemExit('No preview candidate: local payload is the restored baseline')
c=SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
def remote(command):
    _,out,err=c.client.exec_command(command,timeout=30)
    text=out.read().decode();error=err.read().decode()
    if out.channel.recv_exit_status():raise RuntimeError(error)
    return text
try:
    before=c.rpc(dict(action='status'));q=before['hardware']['applied_quality'];display=before['live']['selected']
    backup_file=folder/'board_before.json'
    if not backup_file.exists():
        previous=remote('cat /root/dual_vision_host/bundle.path').strip()
        backup_file.write_text(json.dumps(dict(release=previous,quality=q,display=display),indent=2))
    previous=json.loads(backup_file.read_text())['release']
    assert previous.startswith('/root/dual_vision_host/releases/')
    def rollback():
        c.rpc(dict(action='stop'))
        code='from pathlib import Path;Path("/root/dual_vision_host/bundle.path").write_text('+repr(previous)+')'
        remote('python3 -c '+shlex.quote(code))
        c.rpc(dict(action='start',quality=q,display=display))
    if args.rollback:
        rollback();print('Restored '+previous)
    else:
        try:
            c.install();c.rpc(dict(action='stop'));c.rpc(dict(action='start',quality=q,display=display));time.sleep(4)
            current=c.rpc(dict(action='status'));live=current['live']
            assert not live['yolo']['error'] and 'workers_per_camera' not in live['yolo']
            assert not live['preview']['error']
            result=dict(release=remote('cat /root/dual_vision_host/bundle.path').strip(),
                changed_files=changed,width=live['preview']['width'],height=live['preview']['height'])
            (folder/'deployed.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
        except BaseException:rollback();raise
finally:c.close()
