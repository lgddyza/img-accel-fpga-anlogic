"""Build a self-contained PC release and versioned RK payload."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--payload-only',action='store_true')
parser.add_argument('--distpath',type=Path,default=root/'dist')
parser.add_argument('--workpath',type=Path,default=root/'build')
args = parser.parse_args()
files = sorted(p for p in (root/'rk').iterdir() if p.suffix in ('.py','.so','.c'))
manifest = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(root/'rk_payload.zip','w',zipfile.ZIP_DEFLATED) as archive:
    def write(name,data):
        info = zipfile.ZipInfo(name,date_time=(2026,1,1,0,0,0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info,data)
    for path in files:
        write(path.name,path.read_bytes())
    write('MANIFEST.json',json.dumps(manifest,indent=2))
(root/'rk_payload_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
if not args.payload_only:
    subprocess.run([sys.executable,'-m','PyInstaller','--noconfirm','--clean','--onedir',
        '--windowed','--name','RKDualVisionHost','--distpath',str(args.distpath),
        '--workpath',str(args.workpath),'--specpath',str(args.workpath),
        '--add-data',str(root/'board_agent.py')+';.',
        '--add-data',str(root/'rk_payload.zip')+';.',str(root/'app.py')],cwd=root,check=True)
    shadow = args.distpath/'RKDualVisionHost'/'_internal'/'icuuc.dll'
    shadow.unlink(missing_ok=True)
    print(args.distpath/'RKDualVisionHost'/'RKDualVisionHost.exe')
