"""Measure QF=95 with inference temporarily disabled; restore both switches."""
import json,time
from pathlib import Path
from transport import SSHTransport,default_key
from telemetry import redact

c=SSHTransport({'host':'169.254.53.76','key':str(default_key())})
original=None;data=[]
try:
    status=c.rpc({'action':'status'})
    live=status.get('live') or {}
    ai=live.get('yolo') or {}
    if status['hardware']['applied_quality']!=95 or not ai:
        raise RuntimeError('QF95 and a managed YOLO status are required')
    original=(ai['enabled'][:],ai['confidence'])
    c.rpc({'action':'configure','yolo_a':False,'yolo_b':False})
    time.sleep(4)
    a=redact(c.rpc({'action':'status'}));time.sleep(10);b=redact(c.rpc({'action':'status'}))
    x,y=a['live'],b['live'];dt=y['sample_s']-x['sample_s']
    data=[a,b]
    print('disabled',y['yolo']['enabled'],'seconds',dt,
        'complete',[(v-u)/dt for u,v in zip(x['counters']['complete_frames'],y['counters']['complete_frames'])],
        'decoded',[(v-u)/dt for u,v in zip(x['counters']['decoded_frames'],y['counters']['decoded_frames'])],
        'HDMI',(y['display']['rendered']-x['display']['rendered'])/dt,
        'DMA drops',y['counters']['queue_drops']-x['counters']['queue_drops'],flush=True)
finally:
    if original is not None:
        c.rpc({'action':'configure','yolo_a':original[0][0],'yolo_b':original[0][1],'yolo_confidence':original[1]})
        print('YOLO settings restored',original,flush=True)
    c.close()
    Path('verification/qf95_investigation_20261027/yolo_off.json').write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
