"""Controlled live preprocessing comparison; restore all changed controls."""
import base64
import concurrent.futures
import http.client
import json
import statistics
import time
from email.parser import BytesHeaderParser
from pathlib import Path
from PIL import Image, ImageDraw
from io import BytesIO
from transport import SSHTransport, default_key

OUT=Path('verification/road_preprocess_20261031_repeat')
OUT.mkdir(parents=True,exist_ok=True)
c=SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
records=[]
original=None

def capture(camera,preview,name):
    conn=http.client.HTTPConnection('169.254.53.76',preview['port'],timeout=8)
    try:
        conn.request('GET',f'/stream/{camera}',headers={'Authorization':'Bearer '+preview['token']})
        response=conn.getresponse()
        if response.status!=200: raise RuntimeError(f'preview HTTP {response.status}')
        choices=[]
        for _ in range(15):
            line=response.readline()
            while line.strip()!=b'--rkframe':
                if not line: raise RuntimeError('preview closed')
                line=response.readline()
            raw=bytearray()
            while True:
                line=response.readline(32768); raw.extend(line)
                if line==b'\r\n': break
            fields=BytesHeaderParser().parsebytes(bytes(raw))
            jpeg=response.read(int(fields['Content-Length']))
            boxes=json.loads(base64.b64decode(fields.get('X-Yolo','W10=')))
            choices.append((jpeg,boxes,fields.get('X-Source-Frame')))
        chosen=max(choices,key=lambda x:sum(float(b['confidence']) for b in x[1]))
        image,boxes,frame_id=chosen
        (OUT/f'{name}_cam{camera}_input.jpg').write_bytes(image)
        im=Image.open(BytesIO(image)).convert('RGB');draw=ImageDraw.Draw(im)
        for b in boxes:
            x1,y1,x2,y2=(b['x1']*im.width/1920,b['y1']*im.height/1080,
                           b['x2']*im.width/1920,b['y2']*im.height/1080)
            draw.rectangle((x1,y1,x2,y2),outline='red',width=2)
            text=f"{b['label']} {b['confidence']:.2f}"
            bb=draw.textbbox((x1,max(0,y1-13)),text)
            draw.rectangle(bb,fill='red');draw.text((x1,max(0,y1-13)),text,fill='white')
        im.save(OUT/f'{name}_cam{camera}_detected.jpg',quality=95)
        return dict(frame_id=frame_id,boxes=boxes,preview_size=list(im.size),
                    note='YOLO result from the same camera/mode, up to 12 frames older than preview')
    finally: conn.close()

def summarize(samples,camera):
    results=[s['live']['yolo']['results'][camera] for s in samples]
    results=[r for r in results if r and r['mode']==samples[-1]['expected_mode'] and r['age_ms']<=250]
    counts=[len(r['boxes']) for r in results]
    high=[sum(b['confidence']>=0.5 for b in r['boxes']) for r in results]
    maxconf=[max((b['confidence'] for b in r['boxes']),default=0) for r in results]
    labels={}
    for r in results:
        for b in r['boxes']: labels[b['label']]=labels.get(b['label'],0)+1
    target=[700,380,805,630] if camera==0 else [1640,550,1855,615]
    def iou(b):
        x1=max(target[0],b['x1']);y1=max(target[1],b['y1'])
        x2=min(target[2],b['x2']);y2=min(target[3],b['y2'])
        overlap=max(0,x2-x1)*max(0,y2-y1)
        union=(target[2]-target[0])*(target[3]-target[1])+(b['x2']-b['x1'])*(b['y2']-b['y1'])-overlap
        return overlap/union if union>0 else 0
    matches=[[b for b in r['boxes'] if iou(b)>=0.3] for r in results]
    scores=[max((b['confidence'] for b in group),default=0) for group in matches]
    return dict(samples=len(results),mean_boxes=round(statistics.mean(counts),2) if counts else None,
        median_boxes=statistics.median(counts) if counts else None,
        mean_boxes_conf_ge_05=round(statistics.mean(high),2) if high else None,
        mean_max_conf=round(statistics.mean(maxconf),3) if maxconf else None,
        samples_with_detection=sum(v>0 for v in counts),labels=labels,
        target_roi=target,target_iou_threshold=0.3,target_detected=sum(bool(group) for group in matches),
        target_conf_ge_05=sum(v>=0.5 for v in scores),
        target_mean_conf_including_misses=round(statistics.mean(scores),3) if scores else None,
        sample_results=results)

try:
    initial=c.rpc(dict(action='status'))
    if initial['runtime']!='managed' or initial['hardware']['supported_modes']!=0x3f:
        raise RuntimeError('Sobel-capable managed receiver required')
    h=initial['hardware'];l=initial['live'];w=h['requested'];q=h['dual_qf'];g=h['gaussian_strength'];ai=l['yolo']
    original=dict(mode_a=(w>>1)&7,mode_b=(w>>4)&7,quality=(w>>7)&127,
        gauss_a=g&7,gauss_b=(g>>4)&7,quality_a=q&127,quality_b=(q>>8)&127,
        independent_qf=bool(q&(1<<16)),adaptive_enabled=bool(l['adaptive']['enabled']),
        yolo_a=ai['enabled'][0],yolo_b=ai['enabled'][1],yolo_confidence=ai['confidence'])
    c.rpc(dict(action='configure',adaptive_enabled=False,yolo_a=True,yolo_b=True,
        yolo_confidence=0.10,quality=85,independent_qf=False,gauss_a=4,gauss_b=4))
    for name,mode in [('gray',0),('sobel',4),('blackhat',5),('gauss_clahe',3),('clahe',2),('gaussian',1),('gray_repeat',0)]:
        c.rpc(dict(action='configure',mode_a=mode,mode_b=mode))
        time.sleep(4)
        samples=[]
        for _ in range(10):
            s=c.rpc(dict(action='status'))
            if s['runtime']!='managed' or s['live']['decoded_modes']!=[mode,mode]:
                raise RuntimeError(f'{name}: receiver or mode mismatch')
            s['expected_mode']=mode;samples.append(s)
            time.sleep(1)
        x,y=samples[0]['live'],samples[-1]['live'];dt=y['sample_s']-x['sample_s']
        delta=lambda key:[v-u for u,v in zip(x['counters'][key],y['counters'][key])]
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            captures=list(pool.map(lambda cam:capture(cam,y['preview'],name),(0,1)))
        row=dict(mode=name,mode_id=mode,quality=y['decoded_quality'],seconds=dt,
            decoded_fps=[n/dt for n in delta('decoded_frames')],
            hdmi_fps=(y['display']['rendered']-x['display']['rendered'])/dt,
            yolo_fps=y['yolo']['fps'],decode_drops=delta('decode_queue_drops'),
            display_drops=delta('display_queue_drops'),dma_errors=y['counters']['dma_errors'],
            cameras=[summarize(samples,i) for i in (0,1)],captures=captures)
        records.append(row)
        (OUT/'results.json').write_text(json.dumps(records,indent=2,ensure_ascii=False),encoding='utf-8')
        print(json.dumps(dict(mode=name,quality=row['quality'],decoded_fps=row['decoded_fps'],
            hdmi_fps=row['hdmi_fps'],decode_drops=row['decode_drops'],
            targets=[{k:v for k,v in cam.items() if k.startswith('target_')} for cam in row['cameras']]),ensure_ascii=True),flush=True)
finally:
    try:
        if original:
            c.rpc(dict(action='configure',mode_a=original['mode_a'],mode_b=original['mode_b'],
                gauss_a=original['gauss_a'],gauss_b=original['gauss_b'],quality=original['quality']))
            c.rpc(dict(action='configure',quality_a=original['quality_a'],quality_b=original['quality_b'],
                independent_qf=original['independent_qf'],adaptive_enabled=original['adaptive_enabled'],
                yolo_a=original['yolo_a'],yolo_b=original['yolo_b'],yolo_confidence=original['yolo_confidence']))
            print('Restored original controls',flush=True)
    finally:c.close()
