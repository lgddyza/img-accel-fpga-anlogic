"""Deploy the separate bundle and collect a bounded real-board status window."""
import argparse
import json
from pathlib import Path
import time
from transport import SSHTransport,default_key
from telemetry import redact

parser = argparse.ArgumentParser()
parser.add_argument('--start',action='store_true')
parser.add_argument('--seconds',type=int,default=10)
parser.add_argument('--out',type=Path,default=Path('verification/board.json'))
args = parser.parse_args()
transport = SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
records = []
try:
    transport.install()
    initial = transport.rpc(dict(action='status'))
    print('INITIAL',initial['runtime'],initial.get('hardware_error'),flush=True)
    if args.start:
        result = transport.rpc(dict(action='start',quality=85,display=1,connector=188))
        print('START',result['runtime'],flush=True)
    for _ in range(args.seconds):
        value = transport.rpc(dict(action='status'))
        records.append(redact(value))
        live = value.get('live') or {}
        print(json.dumps(dict(runtime=value['runtime'],rates=live.get('rates'),
            counters=live.get('counters'),preview=redact(live.get('preview')))),flush=True)
        time.sleep(1)
finally:
    transport.close()
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(records,indent=2),encoding='utf-8')
