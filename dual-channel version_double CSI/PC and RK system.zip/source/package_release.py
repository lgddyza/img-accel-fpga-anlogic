"""Archive the portable host, editable sources and redacted test evidence."""
import hashlib
import argparse
import json
from pathlib import Path
import shutil
import zipfile

root = Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--name',default='RK_DUAL_VISION_HOST_20261025')
options=parser.parse_args()
if Path(options.name).name!=options.name:
    raise ValueError('Release name must be a directory name')
target = Path('D:/RK_PROJECT_ARCHIVE')/options.name
target.mkdir(exist_ok=False)
shutil.copytree(root/'dist'/'RKDualVisionHost',target/'pc')
source = target/'source'
source.mkdir()
for path in root.iterdir():
    if path.is_file() and path.suffix in ('.py','.txt','.cmd','.md','.json','.zip'):
        shutil.copy2(path,source/path.name)
for folder in ('rk','tests'):
    shutil.copytree(root/folder,source/folder,ignore=shutil.ignore_patterns('__pycache__'))
shutil.copytree(root/'verification',target/'verification')
for name in ('README.md','VERIFICATION.md','HDMI_CHECK_20261025.md','DECODE_FIX_20261026.md','UI_REFRESH_20261026.md','PREVIEW30_20261026.md'):
    shutil.copy2(root/name,target/name)
shutil.copy2(root/'release_launch.cmd',target/'launch.cmd')
original = Path('D:/RK_PROJECT_ARCHIVE/RK_PC_HANDOFF_20261022.zip')
provenance = dict(archive=str(original),files={})
with zipfile.ZipFile(original) as archive:
    for name in ('transport.py','video_preview.py','HANDOFF.md'):
        suffix = 'pc/source/'+name if name!='HANDOFF.md' else 'HANDOFF.md'
        matches = [n for n in archive.namelist() if n==suffix or n.endswith('/'+suffix)]
        if name=='HANDOFF.md':
            matches = sorted(matches,key=len)[:1]
        if len(matches)!=1:
            raise RuntimeError('Ambiguous source member: '+name)
        data = archive.read(matches[0])
        local = Path('D:/RK_PROJECT_ARCHIVE/RK_PC_HANDOFF_20261022')/suffix
        if data!=local.read_bytes():
            raise RuntimeError('Extracted source differs from archive: '+name)
        provenance['files'][suffix]=hashlib.sha256(data).hexdigest()
(target/'ORIGINAL_SOURCE.json').write_text(json.dumps(provenance,indent=2),encoding='utf-8')
manifest = {p.relative_to(target).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(target.rglob('*')) if p.is_file()}
(target/'MANIFEST.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
output = target.with_suffix('.zip')
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(target.rglob('*')):
        if path.is_file():
            archive.write(path,path.relative_to(target).as_posix())
with zipfile.ZipFile(output) as archive:
    for name,digest in manifest.items():
        if hashlib.sha256(archive.read(name)).hexdigest()!=digest:
            raise RuntimeError('Archive verification failed: '+name)
digest = hashlib.sha256(output.read_bytes()).hexdigest()
output.with_suffix('.zip.sha256').write_text(digest+'  '+output.name+'\n',encoding='ascii')
print(json.dumps(dict(folder=str(target),zip=str(output),files=len(manifest),bytes=output.stat().st_size,sha256=digest),indent=2))
