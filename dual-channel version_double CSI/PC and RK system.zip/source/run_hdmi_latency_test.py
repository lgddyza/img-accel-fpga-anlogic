"""Run two 30-second frame-correlated latency windows, then restore production."""
import json
from pathlib import Path
import shlex
import subprocess
import time

from telemetry import redact
from transport import SSHTransport,default_key


local=Path(__file__).resolve().parent/'verification/hdmi_latency_20261026'
remote='/root/dual_vision_host/latency_20261026'
connection=SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
samples=[]
stopped=False
monitor_pid=None
gui=None


def command(value,timeout=30):
    _,out,err=connection.client.exec_command(value,timeout=timeout)
    text=out.read().decode(errors='replace')
    error=err.read().decode(errors='replace')
    if out.channel.recv_exit_status():
        raise RuntimeError(error or text)
    return text


try:
    before=connection.rpc(dict(action='status'))
    assert before['runtime']=='managed','Start from the existing production receiver'
    display=before['live']['selected']
    quality=before['hardware']['applied_quality']
    (local/'before.json').write_text(json.dumps(redact(before),indent=2))
    stable=command('cat /root/dual_vision_host/bundle.path').strip()
    assert stable.startswith('/root/dual_vision_host/releases/')
    command(f'mkdir -p {remote}/runtime && cp -a {shlex.quote(stable)}/. {remote}/runtime/')
    with connection.client.open_sftp() as ftp:
        for path in (local/'runtime').iterdir():
            if path.is_file():
                ftp.put(str(path),remote+'/runtime/'+path.name)
        ftp.put(str(local/'start_board_test.py'),remote+'/start_board_test.py')
    command(f'gcc -std=c11 -O2 -Wall -Wextra -Werror {remote}/runtime/source_frame_monitor.c '
        f'-o {remote}/runtime/source_frame_monitor && gcc -std=c11 -O2 -Wall -Wextra -Werror '
        f'-shared -fPIC {remote}/runtime/ioctl_trace.c -o {remote}/runtime/liblatency_ioctl.so -ldl')
    command(f'python3 -m py_compile {remote}/runtime/dual_hdmi_bringup.py '
        f'{remote}/runtime/display_metrics.py {remote}/runtime/latency_trace.py')
    print('Diagnostic monitor and hooks compiled; production unchanged so far',flush=True)
    connection.rpc(dict(action='stop'))
    stopped=True
    state=json.loads(command(f'python3 {remote}/start_board_test.py'))
    monitor_pid=state['monitor']
    deadline=time.monotonic()+12
    while time.monotonic()<deadline:
        status=connection.rpc(dict(action='status'))
        if status.get('live') and status['live']['pid']==state['receiver']:
            break
        time.sleep(.2)
    else:
        raise RuntimeError(command(f'tail -n 30 {remote}/evidence/receiver.log'))
    gui=subprocess.Popen([r'D:/RK_PROJECT_ARCHIVE/RK_DUAL_VISION_HOST_20261026_PREVIEW30/pc/RKDualVisionHost.exe',
        '--connect','--preview','--verify-seconds','80','--verify-output',str(local/'gui')])
    time.sleep(4)
    windows=[]
    for camera in (0,1):
        connection.rpc(dict(action='configure',display=camera))
        time.sleep(3)
        first=time.monotonic()
        begin=None
        while time.monotonic()-first<31:
            status=connection.rpc(dict(action='status'))
            assert status.get('live') and status['live']['pid']==state['receiver']
            row=redact(status)
            samples.append(row)
            if begin is None:
                begin=row
                print('Measuring camera','AB'[camera],flush=True)
            time.sleep(.9)
        end=samples[-1]
        windows.append(dict(camera=camera,start_s=begin['live']['sample_s'],end_s=end['live']['sample_s']))
        print('Completed camera','AB'[camera],flush=True)
    (local/'windows.json').write_text(json.dumps(windows,indent=2))
    (local/'runtime_samples.json').write_text(json.dumps(samples,indent=2))
finally:
    try:
        if stopped:
            connection.rpc(dict(action='stop'))
        if monitor_pid:
            command('kill -TERM '+str(monitor_pid))
            time.sleep(.3)
        if stopped:
            with connection.client.open_sftp() as ftp:
                for name in ('frame_trace.json','source.csv','ioctl.csv','monitor.log','result.json','receiver.log'):
                    try:
                        ftp.get(remote+'/evidence/'+name,str(local/name))
                    except OSError:
                        pass
            connection.rpc(dict(action='start',quality=quality,display=display))
            restored=connection.rpc(dict(action='status'))
            restored['stable_bundle']=command('cat /root/dual_vision_host/bundle.path').strip()
            assert restored['stable_bundle']==stable,'Production pointer changed'
            (local/'restored.json').write_text(json.dumps(redact(restored),indent=2))
            print('Restored original production bundle, QF and HDMI selection',flush=True)
    finally:
        connection.close()
    if gui is not None:
        try:
            gui.wait(timeout=35)
        except subprocess.TimeoutExpired:
            print('Verification window remains open; close it normally',flush=True)
