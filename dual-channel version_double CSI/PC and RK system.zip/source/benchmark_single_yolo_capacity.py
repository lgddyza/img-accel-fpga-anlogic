"""Measure an optimistic single-camera inference ceiling, preserving settings."""
import json
from pathlib import Path
import time
from telemetry import redact
from transport import SSHTransport, default_key

out=Path('verification/adaptive_qf_20261029')
out.mkdir(parents=True,exist_ok=True)
c=SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
before=c.rpc(dict(action='status'))
yolo=before['live']['yolo']; enabled=yolo['enabled'][:]
quality=before['hardware']['applied_quality']; selected=before['live']['selected']
results=[]
try:
    for camera in (0,1):
        c.rpc(dict(action='configure',yolo_a=camera==0,yolo_b=camera==1))
        time.sleep(5)
        a=c.rpc(dict(action='status'))
        time.sleep(20)
        b=c.rpc(dict(action='status'))
        al,bl=a['live'],b['live']
        dt=bl['sample_s']-al['sample_s']
        dd=bl['display']['sample_s']-al['display']['sample_s']
        results.append(dict(camera=camera, seconds=dt,
            yolo_fps=[(y-x)/dt for x,y in zip(al['yolo']['completed'],bl['yolo']['completed'])],
            decode_fps=[(y-x)/dt for x,y in zip(al['counters']['decoded_frames'],bl['counters']['decoded_frames'])],
            hdmi_fps=(bl['display']['rendered']-al['display']['rendered'])/dd,
            decode_queue_drops=[y-x for x,y in zip(al['counters']['decode_queue_drops'],bl['counters']['decode_queue_drops'])],
            quality=b['hardware']['applied_quality'], selected=bl['selected'],
            error=bl['yolo']['error']))
        print(json.dumps(results[-1]),flush=True)
finally:
    c.rpc(dict(action='configure',yolo_a=enabled[0],yolo_b=enabled[1],yolo_confidence=yolo['confidence']))
    time.sleep(2)
    restored=c.rpc(dict(action='status'))
    assert restored['live']['yolo']['enabled']==enabled
    assert restored['hardware']['applied_quality']==quality and restored['live']['selected']==selected
    (out/'single_yolo_ceiling.json').write_text(json.dumps(dict(results=results,restored=redact(restored)),indent=2))
    c.close()
