"""Replay captured board status to check pages and UI control bindings offline."""
import copy
import json
from pathlib import Path

from PySide6.QtGui import QImage, QFont, QFontDatabase
from PySide6.QtWidgets import QApplication
from app import Window
from telemetry import Rates

root=Path(__file__).resolve().parent
output=root/'verification/ui_refresh/layout'
output.mkdir(parents=True,exist_ok=True)
samples=json.loads((output.parent/'runtime_samples.json').read_text())
application=QApplication([])
if not QFontDatabase.families():
    for name in ('msyh.ttc','msyhbd.ttc','segoeui.ttf'):
        QFontDatabase.addApplicationFont('C:/Windows/Fonts/'+name)
application.setStyle('Fusion')
application.setFont(QFont('Microsoft YaHei UI',10))
window=Window(demo=True)
window.demo=False
window.linked=True
sent=[]
window.worker.submit=lambda action,payload=None: sent.append((action,payload))

def refresh():
    window.rates=Rates()
    window.rates.update(copy.deepcopy(samples[-2]))
    window.update_status(copy.deepcopy(samples[-1]))
    for i,preview in enumerate(window.previews):
        preview.canvas.image=QImage(str(output.parent/f'camera_{i}.png'))
        preview.canvas.update()
    application.processEvents()

try:
    window.show()
    refresh()
    pages=[window.tabs.tabText(i) for i in range(window.tabs.count())]
    assert pages==['实时监控','运行参数','性能状态','链路诊断','运行日志','连接设置']
    assert not window.diagnostics.isVisible()
    assert not window.cpu.isVisible()
    assert all(not value.isVisible() for value in window.metric_values)
    assert all(p.canvas.isVisible() for p in window.previews)
    assert not window.start_button.isEnabled()
    for width,height in ((1360,850),(1000,700),(960,680),(1920,1080)):
        window.resize(width,height)
        refresh()
        for preview in window.previews:
            assert preview.width()>=400
            for control in (preview.canvas,preview.start_button,preview.full_button,preview.info,preview.decode_info):
                assert preview.rect().contains(control.mapTo(preview,control.rect().topLeft()))
                assert preview.rect().contains(control.mapTo(preview,control.rect().bottomRight()))
        window.grab().save(str(output/f'monitor_{width}.png'))
    window.resize(1000,700)
    for index in range(1,window.tabs.count()):
        window.tabs.setCurrentIndex(index)
        refresh()
        window.grab().save(str(output/f'page_{index}.png'))
    window.tabs.setCurrentIndex(0)
    window.display_buttons[0].click()
    assert sent[-1]==('configure',{'display':0})
    window.osd.click()
    assert sent[-1][0]=='configure' and type(sent[-1][1]['osd']) is bool
    window.tabs.setCurrentIndex(1)
    window.quality.setValue(90)
    window.apply_button.click()
    assert sent[-1]==('configure',{'quality':90,'mode_a':0,'mode_b':0})
    assert all(not combo.model().item(1).isEnabled() for combo in window.mode_boxes)
    window.last_received-=10
    window.check_stale()
    assert window.monitor_fps.text()=='HDMI — FPS'
    assert all(label.text()=='—' for label in window.metric_values)
    assert not window.apply_button.isEnabled()
    (output/'result.json').write_text(json.dumps(dict(passed=True,pages=pages,
        viewports=[[1360,850],[1000,700],[960,680],[1920,1080]],
        control_requests=sent,source='offline layout replay of captured live status'),indent=2),encoding='utf-8')
    print('Page separation, four viewport layouts, controls, capability guards and stale state passed')
finally:
    window.close()
