"""MJPEG receiver with a single-frame mailbox and aspect-preserving Qt display."""
from email.parser import BytesHeaderParser
import base64
import json
from collections import deque
import http.client
import math
import threading
import time

from PySide6.QtCore import Qt, QThread, Signal, QTimer
from PySide6.QtGui import QColor, QIcon, QImage, QPainter, QPen
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QDialog, QFileDialog, QStyle


def tool_icon(widget, standard):
    if standard not in (QStyle.StandardPixmap.SP_MediaPlay, QStyle.StandardPixmap.SP_MediaStop,
                        QStyle.StandardPixmap.SP_DialogCloseButton,
                        QStyle.StandardPixmap.SP_TitleBarMaxButton, QStyle.StandardPixmap.SP_TitleBarNormalButton):
        return widget.style().standardIcon(standard)
    pixmap = widget.style().standardIcon(standard).pixmap(18, 18)
    painter = QPainter(pixmap)
    painter.setCompositionMode(QPainter.CompositionMode.CompositionMode_SourceIn)
    painter.fillRect(pixmap.rect(), QColor('#cbd5e1'))
    painter.end()
    return QIcon(pixmap)


class Receiver(QThread):
    failed = Signal(str)

    def __init__(self, host, options):
        super().__init__()
        self.host, self.options = host, options
        self.stopping = threading.Event()
        self.lock = threading.Lock()
        self.latest = None
        self.latest_boxes = None
        self.sequence = 0
        self.received_bytes = 0
        self.connection = None
        self.started_at = time.monotonic()
        self.viewer_pid = options.get('pid')
        self.log_frames = deque(maxlen=32)

    def stop(self):
        self.stopping.set()
        if self.connection and self.connection.sock:
            try:
                self.connection.sock.shutdown(2)
            except OSError:
                pass

    def run(self):
        try:
            self.connection = http.client.HTTPConnection(self.host, self.options['port'], timeout=5)
            self.connection.request('GET', self.options.get('path', '/stream'), headers={'Authorization': 'Bearer '+self.options['token']})
            response = self.connection.getresponse()
            if response.status != 200:
                raise RuntimeError(f'视频连接被拒绝：HTTP {response.status}')
            while not self.stopping.is_set():
                line = response.readline(4096)
                if not line:
                    raise RuntimeError('RK 视频连接已关闭')
                if line.strip() != b'--rkframe':
                    continue
                header = bytearray()
                while True:
                    line = response.readline(32768)
                    if not line:
                        raise RuntimeError('视频帧头不完整')
                    header.extend(line)
                    if len(header) > 32768:
                        raise RuntimeError('视频帧头过长')
                    if line == b'\r\n':
                        break
                fields = BytesHeaderParser().parsebytes(bytes(header))
                size = int(fields['Content-Length'])
                if not 0 < size <= 4_000_000:
                    raise RuntimeError('视频帧长度异常')
                payload = response.read(size)
                if len(payload) != size:
                    raise RuntimeError('视频帧传输中断')
                frame = QImage.fromData(payload, 'JPEG')
                if frame.isNull():
                    raise RuntimeError('视频 JPEG 解码失败')
                with self.lock:
                    self.latest = frame
                    try:
                        self.latest_boxes = json.loads(base64.b64decode(fields['X-Yolo'], validate=True)) if fields.get('X-Yolo') else None
                    except (ValueError, TypeError):
                        self.latest_boxes = None
                    self.sequence += 1
                    self.received_bytes += size
                    try:
                        stamp = float(fields['X-RK-Time'])
                        if math.isfinite(stamp):
                            self.log_frames.append({'jpeg': payload, 'rk_time_s': stamp,
                                'received_monotonic_s': time.monotonic(),
                                'preview_sequence': fields.get('X-Sequence'),
                                'hdmi_frame': fields.get('X-HDMI-Frame'),
                                'source_pts': fields.get('X-Source-PTS'),
                                'source_frame': fields.get('X-Source-Frame'),
                                'camera': fields.get('X-Camera'),
                                'width': frame.width(), 'height': frame.height()})
                    except (TypeError, ValueError):
                        pass
        except Exception as exc:
            if not self.stopping.is_set():
                self.failed.emit(str(exc))
        finally:
            if self.connection:
                self.connection.close()


class Canvas(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.image = None
        self.detections = []
        self.detections_until = 0
        self.message = '暂无视频信号'
        self.setMinimumSize(240, 135)

    def paintEvent(self, _event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor('#0d0f12'))
        if self.image is not None:
            size = self.image.size().scaled(self.size(), Qt.AspectRatioMode.KeepAspectRatio)
            from PySide6.QtCore import QRect
            target = QRect((self.width()-size.width())//2, (self.height()-size.height())//2,
                           size.width(), size.height())
            painter.drawImage(target, self.image)
            if time.monotonic() < self.detections_until:
                painter.setPen(QPen(QColor('white'), 2))
                for box in self.detections:
                    x1=target.x()+int(box['x1']*target.width()/1920)
                    y1=target.y()+int(box['y1']*target.height()/1080)
                    x2=target.x()+int(box['x2']*target.width()/1920)
                    y2=target.y()+int(box['y2']*target.height()/1080)
                    painter.drawRect(x1,y1,max(1,x2-x1),max(1,y2-y1))
                    painter.drawText(x1,max(target.y()+14,y1-3),f"{box['label']} {box['confidence']:.2f}")
        else:
            painter.setPen(QColor('#94a3b8'))
            painter.drawText(self.rect().adjusted(15, 15, -15, -15),
                             Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap, self.message)


class VideoPreview(QWidget):
    requested = Signal()

    def __init__(self, parent=None, camera=0):
        super().__init__(parent)
        self.setObjectName('previewPanel')
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.receiver = None
        self.camera = camera
        self.fullscreen = None
        self.seen = 0
        self.last_count = 0
        self.last_bytes = 0
        self.last_sample = time.monotonic()
        self.last_frame = 0
        self.width, self.height = 640, 360
        self.presented = 0
        self.last_presented = 0
        self.stats = {'fps': None, 'mbps': None, 'frames': 0}

        self.history = []
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(10)
        header = QHBoxLayout()
        title = QLabel('相机 ' + 'AB'[camera])
        title.setObjectName('sectionTitle')
        header.addWidget(title)
        self.output_badge = QLabel('HDMI 输出')
        self.output_badge.setObjectName('outputBadge')
        self.output_badge.hide()
        header.addWidget(self.output_badge)
        header.addStretch()
        self.start_button = self.tool('', QStyle.StandardPixmap.SP_MediaPlay, self.requested.emit)
        self.start_button.setToolTip('开始预览')
        self.stop_button = self.tool('', QStyle.StandardPixmap.SP_MediaStop, self.stop)
        self.stop_button.setToolTip('停止预览')
        self.snapshot_button = self.tool('', QStyle.StandardPixmap.SP_DialogSaveButton, self.snapshot)
        self.snapshot_button.setToolTip('保存当前预览帧')
        self.full_button = self.tool('', QStyle.StandardPixmap.SP_TitleBarMaxButton, self.open_fullscreen)
        self.full_button.setToolTip('全屏预览')
        for button in (self.start_button, self.stop_button, self.snapshot_button, self.full_button):
            button.setObjectName('iconButton')
            button.setFixedSize(32,32)
            header.addWidget(button)
        layout.addLayout(header)
        self.canvas = Canvas()
        layout.addWidget(self.canvas, 1)
        footer = QHBoxLayout()
        self.decode_info = QLabel('解码 — FPS')
        self.decode_info.setObjectName('muted')
        footer.addWidget(self.decode_info)
        footer.addStretch()
        self.info = QLabel('预览 640 × 360')
        self.info.setObjectName('muted')
        footer.addWidget(self.info)
        layout.addLayout(footer)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.setTimerType(Qt.TimerType.PreciseTimer)
        self.timer.start(16)
        self.stop_button.setEnabled(False)
        self.snapshot_button.setEnabled(False)
        self.full_button.setEnabled(False)
        self.start_button.setEnabled(False)

    def set_output_state(self, selected, fps):
        self.decode_info.setText('解码 — FPS' if fps is None else f'解码 {fps:.1f} FPS')
        self.output_badge.setVisible(selected)
        if self.property('hdmi') != selected:
            self.setProperty('hdmi',selected)
            self.style().unpolish(self)
            self.style().polish(self)
            self.update()

    def set_detections(self, result, mode, enabled):
        if self.receiver and self.receiver.latest_boxes is not None:
            return
        valid = enabled and result and result.get('age_ms', 99999) <= 750 and result.get('mode') == mode
        boxes = result.get('boxes', [])[:64] if valid else []
        for canvas in (self.canvas, self.fullscreen.canvas if self.fullscreen else None):
            if canvas:
                canvas.detections = boxes
                canvas.detections_until = time.monotonic()+1.5 if valid else 0
                canvas.update()

    def log_snapshot(self, status):
        receiver = self.receiver
        ai = status.get('ai') or {}
        if (not receiver or receiver.stopping.is_set() or status.get('runtime') != 'ai'
                or receiver.viewer_pid != status.get('viewer_pid')
                or len(ai.get('boxes', [])) <= 6 or not 0 <= ai.get('age_ms', 9999) <= 2000):
            return None
        target = ai.get('updated_us', 0) / 1e6
        now = time.monotonic()
        with receiver.lock:
            candidates = [frame for frame in receiver.log_frames
                          if 0 <= now-frame['received_monotonic_s'] <= 1
                          and abs(frame['rk_time_s']-target) <= .35]
            if not candidates:
                return None
            selected = min(candidates, key=lambda frame: abs(frame['rk_time_s']-target))
            metadata = {key: value for key, value in selected.items() if key != 'jpeg'}
            metadata.update({'match': 'nearest_preview_encode_time',
                             'delta_ms': (selected['rk_time_s']-target)*1000,
                             'viewer_pid': receiver.viewer_pid,
                             'ai_seq': ai.get('seq'), 'ai_updated_us': ai.get('updated_us'),
                             'captured_at': time.strftime('%Y-%m-%dT%H:%M:%S%z')})
            return {'jpeg': selected['jpeg'], 'metadata': metadata}

    def tool(self, text, icon, callback):
        button = QPushButton(text)
        button.setIcon(tool_icon(self, icon))
        button.clicked.connect(callback)
        button.setMinimumHeight(30)
        return button

    def start(self, host, options):
        self.stop()
        self.canvas.image = None
        self.canvas.message = '正在连接 RK 视频…'
        self.canvas.update()
        self.seen = self.last_count = self.last_bytes = 0
        self.presented = self.last_presented = 0
        self.width, self.height = options.get('width',640), options.get('height',360)
        self.last_sample = time.monotonic()
        self.last_frame = self.last_sample
        self.receiver = Receiver(host, options)
        self.receiver.failed.connect(self.failed)
        self.receiver.start()
        self.stop_button.setEnabled(True)
        self.start_button.setEnabled(False)

    def stop(self):
        if self.receiver:
            self.receiver.failed.disconnect(self.failed)
            self.receiver.stop()
            self.receiver.wait(6500)
            self.receiver = None
        self.canvas.image = None
        self.canvas.message = '暂无视频信号'
        self.canvas.update()
        if self.fullscreen:
            self.fullscreen.close()
        self.stop_button.setEnabled(False)
        self.start_button.setEnabled(True)
        self.snapshot_button.setEnabled(False)
        self.full_button.setEnabled(False)
        self.info.setText(f'预览 {self.width} × {self.height}')
        self.stats = {'fps': None, 'mbps': None, 'frames': 0}

    def failed(self, message):
        self.stop()
        self.canvas.message = message
        self.canvas.update()

    def refresh(self):
        if not self.receiver:
            return
        now = time.monotonic()
        with self.receiver.lock:
            count, byte_count, frame, boxes = self.receiver.sequence, self.receiver.received_bytes, self.receiver.latest, self.receiver.latest_boxes
        if count != self.seen and frame is not None:
            self.seen = count
            self.presented += 1
            self.width, self.height = frame.width(), frame.height()
            self.last_frame = now
            self.canvas.image = frame
            if boxes is not None:
                for canvas in (self.canvas, self.fullscreen.canvas if self.fullscreen else None):
                    if canvas:
                        canvas.detections = boxes[:64]
                        canvas.detections_until = now + .25
            self.canvas.update()
            if self.fullscreen:
                self.fullscreen.canvas.image = frame
                self.fullscreen.canvas.update()
            self.snapshot_button.setEnabled(True)
            self.full_button.setEnabled(True)
        if now-self.last_frame > 3:
            self.canvas.image = None
            self.canvas.message = '视频信号已过期'
            self.canvas.update()
            if self.fullscreen:
                self.fullscreen.canvas.image = None
                self.fullscreen.canvas.message = self.canvas.message
                self.fullscreen.canvas.update()
            self.snapshot_button.setEnabled(False)
            self.full_button.setEnabled(False)
        if now-self.last_sample >= 1:
            elapsed = now-self.last_sample
            self.stats = {'fps': (count-self.last_count)/elapsed,
                          'presented_fps': (self.presented-self.last_presented)/elapsed,
                          'mbps': (byte_count-self.last_bytes)*8/elapsed/1e6, 'frames': count,
                          'presented': self.presented, 'width': self.width, 'height': self.height}
            self.history.append(dict(self.stats, pc_time=time.time()))
            self.history = self.history[-20:]
            self.info.setText(f"预览 {self.stats['presented_fps']:.1f} FPS · {self.width} × {self.height}")
            self.info.setToolTip(f"接收 {self.stats['fps']:.1f} FPS · {self.stats['mbps']:.2f} Mbps · {count} 帧")
            self.last_sample, self.last_count, self.last_bytes = now, count, byte_count
            self.last_presented = self.presented

    def snapshot(self):
        if self.canvas.image is None:
            return
        path, _ = QFileDialog.getSaveFileName(self, '保存视频截图',
                    'rk_preview_'+time.strftime('%Y%m%d_%H%M%S')+'.png', 'PNG (*.png)')
        if path and not self.canvas.image.save(path):
            self.info.setText('截图保存失败')

    def open_fullscreen(self):
        if self.fullscreen:
            return
        dialog = QDialog(self)
        dialog.setWindowTitle('RK 实时视频')
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(0, 0, 0, 0)
        dialog.canvas = Canvas()
        dialog.canvas.image = self.canvas.image
        dialog.canvas.detections = self.canvas.detections
        dialog.canvas.detections_until = self.canvas.detections_until
        layout.addWidget(dialog.canvas)
        close = self.tool('退出全屏', QStyle.StandardPixmap.SP_TitleBarNormalButton, dialog.close)
        layout.addWidget(close)
        dialog.finished.connect(lambda _: setattr(self, 'fullscreen', None))
        self.fullscreen = dialog
        dialog.showFullScreen()
