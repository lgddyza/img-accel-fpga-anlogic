"""Build and validate the native display probe in an isolated board directory."""
import json
from pathlib import Path
import shlex
from transport import SSHTransport, default_key

root = Path(__file__).resolve().parent
dest = root/'verification'/'hdmi_native_20261029'
dest.mkdir(parents=True, exist_ok=True)
remote = '/root/dual_vision_host/build_display_probe_20261029'
c = SSHTransport(dict(host='169.254.53.76', key=str(default_key())))

def command(code):
    _, out, err = c.client.exec_command(code, timeout=30)
    output = out.read().decode()+err.read().decode()
    result = out.channel.recv_exit_status()
    if result:
        raise RuntimeError(output)
    return output

try:
    with c.client.open_sftp() as ftp:
        try:
            ftp.mkdir(remote)
        except OSError:
            ftp.stat(remote)
        for name in ('display_probe.c', 'native_display_probe.py', 'verify_display_probe.py'):
            ftp.put(str(root/'rk'/name), remote+'/'+name)
    flags = shlex.split(command('pkg-config --cflags --libs gstreamer-1.0'))
    output = command(shlex.join(['gcc', '-std=c11', '-O2', '-fPIC', '-shared', '-Wall',
        '-Wextra', '-Werror', remote+'/display_probe.c', '-o', remote+'/libdisplay_probe.so', *flags]))
    output += command(shlex.join(['python3', remote+'/verify_display_probe.py']))
    (dest/'native_probe_validation.txt').write_text(output)
    print(output)
    assert json.loads(output.strip())['passed']
    with c.client.open_sftp() as ftp:
        ftp.get(remote+'/libdisplay_probe.so', str(root/'rk'/'libdisplay_probe.so'))
finally:
    c.close()
