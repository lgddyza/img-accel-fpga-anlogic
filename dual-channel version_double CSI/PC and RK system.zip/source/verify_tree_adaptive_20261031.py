"""Install and exercise adaptive tree on an idle RK, restoring prior runtime state."""
import json
import time
from pathlib import Path
from transport import SSHTransport,default_key
from telemetry import redact

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'verification/tree_adaptive_20261031'
OUT.mkdir(parents=True,exist_ok=True)
c=SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
settings_path='/root/dual_vision_host/run/yolo.json'
def save(name,obj):
    (OUT/name).write_text(json.dumps(redact(obj),ensure_ascii=False,indent=2),encoding='utf8')
def status():return c.rpc(dict(action='status'))
def config(**kwargs):return c.rpc(dict(action='configure',**kwargs))
before=status();save('before.json',before)
if before['runtime']!='stopped' or before.get('processes'):
    c.close();raise RuntimeError('RK receiver is active; no runtime interruption performed')
hw=before['hardware'];word=hw['requested'];quality=(word>>7)&127
original=dict(mode_a=(word>>1)&7,mode_b=(word>>4)&7,display=(word>>14)&1,quality=quality)
dual=hw.get('dual_qf');samples=[];started=False
with c.client.open_sftp() as ftp:
    try:
        with ftp.open(settings_path,'rb') as f:old_settings=f.read()
    except IOError:old_settings=None
    try:
        with ftp.open('/root/dual_vision_host/bundle.path','rb') as f:old_bundle=f.read().decode()
    except IOError:old_bundle=None
    try:ftp.get('/root/dual_vision_host/board_agent.py',str(OUT/'board_agent_before.py'))
    except IOError:pass
save('original_state.json',dict(original=original,dual=dual,old_bundle=old_bundle,
                                 old_settings=old_settings.decode() if old_settings else None))
try:
    c.install()
    config(yolo_a=True,yolo_b=True,yolo_confidence=.1,adaptive_enabled=True)
    c.rpc(dict(action='start',quality=quality,display=original['display'],connector=188));started=True
    for i in range(20):
        time.sleep(1)
        s=status();samples.append(s)
        if s.get('runtime')!='managed':raise RuntimeError('receiver stopped during test')
        live=s.get('live') or {};adaptive=live.get('adaptive') or {}
        print(i+1, 'adaptive',[(v.get('state'),(v.get('preprocess_prediction') or {}).get('mode'),
              (v.get('preprocess_control') or {}).get('target')) for v in adaptive.get('cameras',[])],
              'decoded',live.get('decoded_modes'),'fps',(live.get('display') or {}).get('rendered_fps_avg'),flush=True)
    save('samples.json',samples)
    last=samples[-1];a=(last.get('live') or {}).get('adaptive') or {}
    assert a.get('enabled') and len(a.get('cameras',[]))==2
    assert any(v.get('preprocess_prediction') for v in a['cameras']), 'No fresh tree prediction'
    assert not a.get('error'),a.get('error')
    # A manual setting must immediately take priority even if it equals the current value.
    current=(last['hardware']['requested']>>1)&7
    config(mode_a=current)
    time.sleep(2)
    manual=status();save('manual_override.json',manual)
    assert manual['live']['adaptive']['cameras'][0]['preprocess_control']['manual_override']
    config(adaptive_enabled=False)
    time.sleep(2)
    disabled=status();save('disabled.json',disabled)
    assert disabled['live']['adaptive']['enabled'] is False
    save('result.json',dict(ok=True,samples=len(samples),note='live conditions only; dark QF/YOLO thresholds exercised in unit tests'))
finally:
    if started:
        try:c.rpc(dict(action='stop'))
        except Exception as exc:print('STOP ERROR',exc,flush=True)
    try:
        restore=dict(mode_a=original['mode_a'],mode_b=original['mode_b'],display=original['display'],quality=original['quality'])
        if dual is not None:
            restore.update(quality_a=dual&127,quality_b=(dual>>8)&127,independent_qf=bool(dual&(1<<16)))
            restore.pop('quality')
        config(**restore)
        with c.client.open_sftp() as ftp:
            if old_settings is None:
                try:ftp.remove(settings_path)
                except IOError:pass
            else:
                with ftp.open(settings_path+'.restore','wb') as f:f.write(old_settings)
                ftp.posix_rename(settings_path+'.restore',settings_path)
        save('after.json',status())
    finally:c.close()
