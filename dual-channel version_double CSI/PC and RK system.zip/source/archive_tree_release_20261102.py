"""Archive the current RK and PC release with board dependencies and checksums."""
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

from transport import SSHTransport, default_key
from telemetry import redact

ROOT = Path(__file__).resolve().parent
NAME = 'RK_PC_DUAL_TREE_ADAPTIVE_20261102'
TARGET = Path('D:/RK_PROJECT_ARCHIVE')/NAME
ZIP = TARGET.with_suffix('.zip')
if TARGET.exists() or ZIP.exists():
    raise SystemExit('Archive already exists; choose a new name to preserve it.')
TARGET.mkdir(parents=True)

def copy(src, dst):
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):h.update(chunk)
    return h.hexdigest()

copy(ROOT/'自适应决策树部署说明_20261031.md',TARGET/'自适应决策树部署说明.md')
copy(ROOT/'验证记录.md',TARGET/'历史验证记录.md')
shutil.copytree(ROOT/'dist_tree_adaptive_20261031'/'RKDualVisionHost',TARGET/'pc'/'RKDualVisionHost')
source=TARGET/'source';source.mkdir()
for f in ROOT.iterdir():
    if f.is_file() and f.suffix.lower() in ('.py','.txt','.md'):
        copy(f,source/f.name)
for folder in ('rk','tests'):
    shutil.copytree(ROOT/folder,source/folder,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for name in ('rk_payload.zip','rk_payload_manifest.json'):
    copy(ROOT/name,source/name)
native=Path('E:/FPGA/workspace/RK_DUAL_YOLO_PRF1_20261027/verification/road_parallel.cpp')
copy(native,source/'rk'/'native_source'/'road_parallel.cpp')
assert digest(source/'rk_payload.zip')==digest(TARGET/'pc/RKDualVisionHost/_internal/rk_payload.zip')
assert digest(source/'board_agent.py')==digest(TARGET/'pc/RKDualVisionHost/_internal/board_agent.py')

experiment=Path('D:/RK_EXPERIMENTS/fpga_degradation_20261031')
for name in ('decision_tree_training.json','decision_tree_dataset.json','summary.json',
             'summary.csv','预处理退化场景板端实验报告.md'):
    copy(experiment/name,TARGET/'model_training'/name)
study=ROOT.parent/'road_damage_yolov8n/fpga_degradation_20261031'
copy(study/'train_policy.py',TARGET/'model_training/train_policy.py')
for name in ('before.json','after.json','samples.json','manual_override.json','disabled.json','result.json'):
    original=ROOT/'verification/tree_adaptive_20261031'/name
    obj=redact(json.loads(original.read_text(encoding='utf8')))
    out=TARGET/'verification'/name;out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf8')
copy(ROOT/'verification/tree_adaptive_20261031/ui_1000.png',TARGET/'verification/ui_1000.png')

remote_files=[
 '/root/road_damage_yolov8n/road_damage_yolov8n_gray640_int8_rk3576.rknn',
 '/root/road_damage_yolov8n/area_resize_20261027/rk3576_benchmark.cpp',
 '/root/road_damage_yolov8n/area_resize_20261027/rk3576_infer.cpp',
 '/root/road_damage_yolov8n/area_resize_20261027/rknn_api.h',
 '/root/jpeg_rk/capture_jpeg_tiles.py','/root/jpeg_rk/libjpeg_native.so',
 '/root/jpeg_rk/libjpeg_weave.so','/root/jpeg_rk/jpeg_native.c',
 '/root/jpeg_rk/jpeg_weave.c','/root/jpeg_rk/libroad_infer.so',
 '/lib/modules/6.1.99/extra/anlogic_pci.ko',
]
missing=[];remote_hashes={}
connection=SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
try:
    status=connection.rpc(dict(action='status'))
    (TARGET/'board_status_at_archive.json').write_text(json.dumps(redact(status),ensure_ascii=False,indent=2),encoding='utf8')
    with connection.client.open_sftp() as sftp:
        for remote in remote_files:
            try:sftp.stat(remote)
            except OSError:
                missing.append(remote);continue
            local=TARGET/'rk_board_dependencies'/remote.lstrip('/')
            local.parent.mkdir(parents=True,exist_ok=True)
            sftp.get(remote,str(local))
            _,out,err=connection.client.exec_command('sha256sum '+remote,timeout=30)
            raw=out.read().decode().split();code=out.channel.recv_exit_status()
            if code or not raw or raw[0]!=digest(local):
                raise RuntimeError('Board dependency checksum mismatch: '+remote)
            remote_hashes[remote]=raw[0]
    command='uname -a; cat /etc/os-release; python3 --version; modinfo anlogic_pci; gst-launch-1.0 --version; pkg-config --modversion opencv4'
    _,out,err=connection.client.exec_command(command,timeout=30)
    (TARGET/'board_environment.txt').write_bytes(out.read()+err.read())
finally:connection.close()

model='/root/road_damage_yolov8n/road_damage_yolov8n_gray640_int8_rk3576.rknn'
if remote_hashes.get(model)!='ecdc6accd6558c3394d4a73eeb03b876f09d9e82ba11c2754869d8bb9add55ae':
    raise RuntimeError('Deployed model missing or does not match tested model')
expected=hashlib.sha256((ROOT/'rk_payload.zip').read_bytes()).hexdigest()
(TARGET/'README.md').write_text(f'''# RK 与上位机双路自适应工程归档

归档日期：2026-11-02（北京时间）。本包保存 2026-10-31 决策树展示版，包含 PC 可执行程序和源码、RK 用户态程序、板端模型和只读提取的依赖。

## 目录与使用

- `pc/RKDualVisionHost/RKDualVisionHost.exe` 是上位机入口；整个 `RKDualVisionHost` 目录必须保留。
- `source/` 保存 PC 和 RK 源码、单元测试、构建脚本、RK payload 和 NPU 并行实现参考源码。上位机内 payload 与 `source/rk_payload.zip` 校验一致，SHA-256：`{expected}`。
- `rk_board_dependencies/` 按 RK 根目录结构存放现场模型、JPEG 依赖、PCIe 模块和参考源码。恢复前先确认目标系统、内核、软硬件版本并备份目标文件；PCIe 模块仅适用于其编译内核。
- `model_training/` 为固定决策树的训练结果、配对样本特征和报告；训练脚本依赖原图及其他实验模块，本包不包含完整训练集，不保证单独运行训练脚本即可重训。
- `verification/` 保存上次短时板测的脱敏记录；`自适应决策树部署说明.md` 描述使用方法和测试边界。
- `board_environment.txt` 与 `board_status_at_archive.json` 为归档时只读获取的系统信息；`MANIFEST.json` 为每个归档文件的 SHA-256。

连接已有兼容环境的 RK 后，启动视频，在“应用检测设置”中打开自适应；如需双路独立 QF，需在运行参数中开启独立 QF。使用旧上位机可能重新部署旧 payload。此包不是完整 RK 系统镜像，不自动安装 RKNN、GStreamer、图形栈或配置 SSH/SD 卡。

本次不包含 FPGA 工程与位流、原始训练集、SSH 密钥、密码和 SD 卡检测图片。预处理决策树是探索性展示模型；暗场 QF、YOLO 配额为规则而非训练模型。历史板测的场景及局限详见部署说明。

未找到的可选板端依赖：{json.dumps(missing,ensure_ascii=False)}。现场提取的可用文件均已与板端 SHA-256 比对。
''',encoding='utf8')

manifest={p.relative_to(TARGET).as_posix():digest(p) for p in sorted(TARGET.rglob('*')) if p.is_file()}
(TARGET/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
with zipfile.ZipFile(ZIP,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for f in sorted(TARGET.rglob('*')):
        if f.is_file():archive.write(f,f.relative_to(TARGET).as_posix())
with zipfile.ZipFile(ZIP) as archive:
    if archive.testzip() is not None:raise RuntimeError('ZIP CRC verification failed')
    for name,expected_hash in manifest.items():
        h=hashlib.sha256()
        with archive.open(name) as f:
            for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
        if h.hexdigest()!=expected_hash:raise RuntimeError('ZIP file checksum mismatch: '+name)
zip_hash=digest(ZIP)
ZIP.with_suffix('.zip.sha256').write_text(zip_hash+'  '+ZIP.name+'\n',encoding='ascii')
print(json.dumps(dict(directory=str(TARGET),archive=str(ZIP),files=len(manifest),
    size_bytes=ZIP.stat().st_size,sha256=zip_hash,missing=missing,runtime=status.get('runtime')),ensure_ascii=False,indent=2))
