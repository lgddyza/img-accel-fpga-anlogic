"""Real cameras: compare OSD off/on and both HDMI choices in one receiver."""
import json
import argparse
from pathlib import Path
import time
from transport import SSHTransport, default_key
from telemetry import redact

parser=argparse.ArgumentParser()
parser.add_argument('--out',default='verification/hdmi_osd_final')
args=parser.parse_args()
dest=Path(args.out)
dest.mkdir(parents=True,exist_ok=True)
c=SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
results=[]
try:
    for camera,osd in ((0,False),(0,True),(1,False),(1,True)):
        c.rpc(dict(action='configure',display=camera,osd=osd))
        time.sleep(3)
        records=[]
        while len(records)<12:
            s=redact(c.rpc(dict(action='status')))
            live=s.get('live') or {}
            if live.get('selected')!=camera or live.get('display',{}).get('osd')!=osd:
                raise RuntimeError('Display configuration not applied')
            if not records or records[-1]['live']['sample_s']!=live['sample_s']:
                records.append(s)
            time.sleep(.5)
        first,last=records[0]['live'],records[-1]['live']
        d0,d1=first['display'],last['display']
        dt=d1['sample_s']-d0['sample_s']
        rendered=(d1['rendered']-d0['rendered'])/dt
        frames=d1['convert_frames']-d0['convert_frames']
        conversion=(d1['convert_osd_total_us']-d0['convert_osd_total_us'])/max(1,frames)/1000
        result=dict(camera='AB'[camera],osd=osd,seconds=dt,rendered_fps=rendered,
            decoded_fps=[(b-a)/(last['sample_s']-first['sample_s']) for a,b in zip(first['counters']['decoded_frames'],last['counters']['decoded_frames'])],
            queue_overrun_events=d1['queue_overrun_events']-d0['queue_overrun_events'],
            present_queue_overrun_events=d1.get('present_queue_overrun_events',0)-d0.get('present_queue_overrun_events',0),
            sink_dropped=d1['sink_dropped']-d0['sink_dropped'],
            convert_osd_ms=conversion,final_gap_p95_ms=d1['sink_gap_ms_p95'],
            jpeg_rejected=[b-a for a,b in zip(first['counters']['decode_rejected_frames'],last['counters']['decode_rejected_frames'])],
            c2h_discarded_bytes=[b['discarded_bytes']-a['discarded_bytes'] for a,b in zip(first['packet_streams'],last['packet_streams'])])
        results.append(result)
        (dest/f"camera_{camera}_osd_{osd}.json").write_text(json.dumps(records,indent=2),encoding='utf-8')
        print(json.dumps(result),flush=True)
    (dest/'summary.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
finally:
    c.rpc(dict(action='configure',display=1,osd=True))
    c.close()
