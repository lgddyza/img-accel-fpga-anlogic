"""Run an explicitly supplied board diagnostic command over the existing SSH key."""
import sys
from transport import SSHTransport, default_key

c = SSHTransport(dict(host='169.254.53.76', key=str(default_key())))
try:
    _, out, err = c.client.exec_command(sys.argv[1], timeout=60)
    print(out.read().decode(errors='replace'))
    print(err.read().decode(errors='replace'))
    raise SystemExit(out.channel.recv_exit_status())
finally:
    c.close()
