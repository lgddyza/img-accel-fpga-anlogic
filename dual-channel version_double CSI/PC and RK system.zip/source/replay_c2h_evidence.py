"""Replay recorded DMA bytes with different chunk boundaries, entirely offline."""
import hashlib
import json
from pathlib import Path
import random
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent/'rk'))
from dual_csi_protocol import PacketStream, parse_packet

dest=Path('investigation_c2h_20261025')
source=Path('E:/FPGA/workspace/DUAL_IMX415_PCIE_JPEG_GRAY_DEMO_20261024/build/board_test_str5_20261025/rk_results/trace_4m')
paths=sorted(source.glob('trace_ch3_read*.bin'))
chunks=[p.read_bytes() for p in paths]
def replay(parts):
    stream=PacketStream(3)
    packets=[]
    for part in parts: packets.extend(stream.feed(part))
    return dict(hashes=[hashlib.sha256(p).hexdigest() for p in packets],
                frames=[dict(camera=t.camera,frame=t.frame_id) for t in map(parse_packet,packets)],
                discarded=stream.discarded_bytes,invalid=stream.invalid_packets,buffered=len(stream.buffer))
baseline=replay(chunks)
joined=b''.join(chunks)
rng=random.Random(20261025)
cases={'original_reads':baseline,'single_read':replay([joined]),'one_byte_reads':replay(bytes([v]) for v in joined)}
offset=0;random_parts=[]
while offset<len(joined):
    size=rng.randint(1,8192);random_parts.append(joined[offset:offset+size]);offset+=size
cases['random_boundaries']=replay(random_parts)
for stride in (16,4096,65536):cases['stride_'+str(stride)]=replay(joined[i:i+stride] for i in range(0,len(joined),stride))
assert all(v==baseline for v in cases.values()),cases
result=dict(files=[p.name for p in paths],cases=cases,all_equal=True,
            lengths=[len(c) for c in chunks],
            markers=[dict(magic=c.find(b'DJP2'),soi=c.find(b'\xff\xd8'),eoi=c.rfind(b'\xff\xd9')) for c in chunks])
(dest/'replay.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
