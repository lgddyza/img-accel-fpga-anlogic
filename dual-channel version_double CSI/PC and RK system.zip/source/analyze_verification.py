"""Reduce the packaged EXE's real-board preview window to reproducible metrics."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
samples = json.loads((root/'verification/exe_ui/runtime_samples.json').read_text())
selected = [s for s in samples if s.get('live') and s['live']['preview']['clients']==[1,1]]
first,last = selected[0],selected[-1]
a,b = first['live'],last['live']
assert a['pid']==b['pid']
seconds = b['sample_s']-a['sample_s']
def counts(name):
    return [y-x for x,y in zip(a['counters'][name],b['counters'][name])]
ticks = last['resources']['cpu_total']-first['resources']['cpu_total']
idle = last['resources']['cpu_idle']-first['resources']['cpu_idle']
data = dict(samples=len(samples),both_preview_seconds=seconds,receiver_pid=b['pid'],
    decoded_frames=counts('decoded_frames'),decoded_fps=[n/seconds for n in counts('decoded_frames')],
    hdmi_submitted_fps=[n/seconds for n in counts('submitted_hdmi')],
    preview_fps=[(y-x)/seconds for x,y in zip(a['preview']['frames'],b['preview']['frames'])],
    strict_rejected=counts('decode_rejected_frames'),
    discarded_bytes=[y['discarded_bytes']-x['discarded_bytes'] for x,y in zip(a['packet_streams'],b['packet_streams'])],
    queue_drops=b['counters']['queue_drops']-a['counters']['queue_drops'],
    decode_queue_drops=counts('decode_queue_drops'),display_queue_drops=counts('display_queue_drops'),
    cpu_percent=100*(ticks-idle)/ticks,
    memory_used_percent=100*(1-last['resources']['memory_available_mb']/last['resources']['memory_total_mb']),
    workflow_passed=json.loads((root/'verification/workflow/result.json').read_text())['passed'],
    hashes={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in
        ('app.py','transport.py','board_agent.py','rk_payload.zip','dist/RKDualVisionHost/RKDualVisionHost.exe')})
(root/'verification/summary.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
print(json.dumps(data,indent=2))
