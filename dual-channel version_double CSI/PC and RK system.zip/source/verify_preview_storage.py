"""Check preview-only deployment, preserved settings, and SD image access."""
import base64
import hashlib
import json
from pathlib import Path
import time

from PySide6.QtGui import QImage
from transport import SSHTransport, default_key


root = Path(__file__).resolve().parent
folder = root/'verification'/'preview720_20261029'
old = json.loads((folder/'before'/'rk_payload_manifest.json').read_text())
new = json.loads((root/'rk_payload_manifest.json').read_text())
changed = sorted(k for k in set(old) | set(new) if old.get(k) != new.get(k))
assert changed == ['dual_preview.py'], changed
baseline = json.loads((folder/'baseline640'/'before.json').read_text())
original = json.loads((folder/'board_before.json').read_text())
connection = SSHTransport(dict(host='169.254.53.76', key=str(default_key())))
try:
    connection.rpc(dict(action='configure', display=original['display']))
    status = connection.rpc(dict(action='status'))
    deadline = time.monotonic()+5
    while status['live']['selected'] != original['display'] and time.monotonic() < deadline:
        time.sleep(.3)
        status = connection.rpc(dict(action='status'))
    live, hardware = status['live'], status['hardware']
    assert (live['preview']['width'], live['preview']['height']) == (960, 540)
    assert live['yolo']['enabled'] == baseline['live']['yolo']['enabled']
    assert live['yolo']['confidence'] == baseline['live']['yolo']['confidence']
    assert 'workers_per_camera' not in live['yolo'] and not live['yolo']['error']
    assert not live['detection_log']['error']
    assert hardware['applied_quality'] == original['quality']
    # Ignore only the HDMI selection bit when checking all FPGA control settings.
    assert hardware['requested'] & ~(1 << 14) == baseline['hardware']['requested'] & ~(1 << 14)
    assert live['selected'] == original['display']
    events = connection.rpc(dict(action='detection_list'))['events']
    assert 0 < len(events) <= 40
    detail = connection.rpc(dict(action='detection_detail', id=events[0]['id']))
    thumbnail = QImage.fromData(base64.b64decode(detail['jpeg']))
    assert not thumbnail.isNull()
    filename = detail['event']['image_file']
    assert Path(filename).name == filename
    listing = connection.rpc(dict(action='sd_list', path='dual_vision/detection_images'))
    assert any(item['name'] == filename for item in listing['entries'])
    relative = 'dual_vision/detection_images/'+filename
    chunk = connection.rpc(dict(action='sd_chunk', path=relative, offset=0, length=64))
    with connection.client.open_sftp() as sftp:
        with sftp.open('/root/dual_vision_host/bundle.path') as handle:
            release = handle.read().decode().strip()
        assert release.startswith('/root/dual_vision_host/releases/')
        for name in ('libroad_parallel0.so', 'libroad_parallel1.so', 'detection_log.py', 'dual_preview.py'):
            with sftp.open(release+'/'+name) as handle:
                assert hashlib.sha256(handle.read()).hexdigest() == new[name], name
        with sftp.open('/mnt/vision_sd/'+relative) as handle:
            pixels = handle.read()
    assert base64.b64decode(chunk['data']) == pixels[:64]
    image = QImage.fromData(pixels)
    assert pixels.startswith(b'\x89PNG\r\n\x1a\n')
    assert not image.isNull() and (image.width(), image.height()) == (1920, 1080)
    result = dict(passed=True, release=release, changed_payload_files=changed,
        preview_size=[960,540], preview_fps_limit=live['preview']['fps_limit'],
        original_yolo_and_fast_sd_preserved=True, quality=hardware['applied_quality'],
        restored_hdmi=live['selected'], fpga_control_preserved=True,
        sd_records=len(events), sd_list_and_read=True, sd_image_size=[image.width(),image.height()],
        sd_image_format='PNG', sd_image_bytes=len(pixels),
        thumbnail_size=[thumbnail.width(),thumbnail.height()], yolo_error=live['yolo']['error'],
        sd_error=live['detection_log']['error'])
    (folder/'integrity.json').write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
finally:
    connection.close()
