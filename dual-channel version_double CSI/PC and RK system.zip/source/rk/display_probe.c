/* Display probes run on GStreamer streaming threads, without entering Python. */
#include <gst/gst.h>
#include <stdint.h>
#include <string.h>

#define SAMPLE_CAPACITY 1024

typedef struct {
    int64_t time_us;
    uint64_t frame_id;
    uint64_t camera;
    int64_t queue_age_us;
} DisplaySample;

typedef struct {
    GMutex lock;
    GstPad *pad;
    GstElement *sink;
    GstClock *clock;
    GstElement *queue;
    GstElement *present;
    gulong probe_id, queue_handler, present_handler;
    uint64_t arrivals, queue_overruns, present_overruns;
    DisplaySample samples[SAMPLE_CAPACITY];
} DisplayProbe;

static GstPadProbeReturn record_arrival(GstPad *pad, GstPadProbeInfo *info, gpointer data) {
    (void)pad;
    DisplayProbe *probe = data;
    GstBuffer *buffer = GST_PAD_PROBE_INFO_BUFFER(info);
    if (!buffer) return GST_PAD_PROBE_OK;
    DisplaySample sample = {g_get_monotonic_time(), GST_BUFFER_OFFSET(buffer),
                            GST_BUFFER_OFFSET_END(buffer), -1};
    if (!probe->clock) probe->clock = gst_element_get_clock(probe->sink);
    if (probe->clock && GST_BUFFER_PTS_IS_VALID(buffer)) {
        GstClockTime now = gst_clock_get_time(probe->clock);
        GstClockTime base = gst_element_get_base_time(probe->sink);
        if (now >= base && now-base >= GST_BUFFER_PTS(buffer))
            sample.queue_age_us = (int64_t)((now-base-GST_BUFFER_PTS(buffer))/GST_USECOND);
    }
    g_mutex_lock(&probe->lock);
    probe->samples[probe->arrivals % SAMPLE_CAPACITY] = sample;
    probe->arrivals++;
    g_mutex_unlock(&probe->lock);
    return GST_PAD_PROBE_OK;
}

static void record_overrun(GstElement *queue, gpointer data) {
    DisplayProbe *probe = data;
    g_mutex_lock(&probe->lock);
    if (queue == probe->queue) probe->queue_overruns++;
    else probe->present_overruns++;
    g_mutex_unlock(&probe->lock);
}

void *rk_display_probe_new(void *sink, void *queue, void *present) {
    if (!GST_IS_ELEMENT(sink) || !GST_IS_ELEMENT(queue)) return NULL;
    GstPad *pad = gst_element_get_static_pad(GST_ELEMENT(sink), "sink");
    if (!pad) return NULL;
    DisplayProbe *probe = g_new0(DisplayProbe, 1);
    g_mutex_init(&probe->lock);
    probe->pad = pad;
    probe->sink = gst_object_ref(sink);
    probe->queue = gst_object_ref(queue);
    probe->present = present ? gst_object_ref(present) : NULL;
    probe->queue_handler = g_signal_connect(queue, "overrun", G_CALLBACK(record_overrun), probe);
    if (present)
        probe->present_handler = g_signal_connect(present, "overrun", G_CALLBACK(record_overrun), probe);
    probe->probe_id = gst_pad_add_probe(pad, GST_PAD_PROBE_TYPE_BUFFER, record_arrival, probe, NULL);
    return probe;
}

/* Copy a consistent, oldest-first snapshot. The caller owns the output array. */
unsigned rk_display_probe_read(void *handle, DisplaySample *output, unsigned capacity,
                               uint64_t *totals) {
    DisplayProbe *probe = handle;
    if (!probe || !output || !totals) return 0;
    g_mutex_lock(&probe->lock);
    unsigned count = (unsigned)MIN(probe->arrivals, (uint64_t)SAMPLE_CAPACITY);
    count = MIN(count, capacity);
    uint64_t first = probe->arrivals - count;
    for (unsigned i = 0; i < count; i++)
        output[i] = probe->samples[(first + i) % SAMPLE_CAPACITY];
    totals[0] = probe->arrivals;
    totals[1] = probe->queue_overruns;
    totals[2] = probe->present_overruns;
    g_mutex_unlock(&probe->lock);
    return count;
}

/* Stop the pipeline before freeing, so no streaming callback remains active. */
void rk_display_probe_free(void *handle) {
    DisplayProbe *probe = handle;
    if (!probe) return;
    gst_pad_remove_probe(probe->pad, probe->probe_id);
    g_signal_handler_disconnect(probe->queue, probe->queue_handler);
    if (probe->present)
        g_signal_handler_disconnect(probe->present, probe->present_handler);
    gst_object_unref(probe->pad);
    gst_object_unref(probe->sink);
    if (probe->clock) gst_object_unref(probe->clock);
    gst_object_unref(probe->queue);
    if (probe->present) gst_object_unref(probe->present);
    g_mutex_clear(&probe->lock);
    g_free(probe);
}
