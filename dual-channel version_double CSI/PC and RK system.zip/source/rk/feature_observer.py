"""Read-only OBS1 statistics; callers must serialize full pages with bar.lock."""
import argparse,ctypes,json,mmap
from pathlib import Path

BUILD=0x4f425331
MAGIC=0x3153424f

def decode(words):
    if len(words)!=16: raise ValueError('OBS1 requires exactly 16 words')
    packet=sum(int(w)<<(32*i) for i,w in enumerate(words))
    def field(start,width): return (packet>>start)&((1<<width)-1)
    n=field(64,18)
    hist=[field(168+18*i,18) for i in range(16)]
    raw=dict(valid=bool(field(29,1)),camera=field(28,1),frame_id=field(0,28),
        epoch=field(32,32),samples=n,luma_sum=field(82,25),dark_count=field(107,18),
        bright_count=field(125,18),gradient_sum=field(143,25),hist=hist,
        sequence=field(456,16),errors=field(472,16),stage='gray_before_enhancement_and_JPEG',
        score_supported=False)
    if not raw['valid']: return raw
    if n!=129600 or sum(hist)!=n or raw['dark_count']>n or raw['bright_count']>n:
        raise ValueError('OBS1 invalid sample count/histogram; check geometry or page access serialization')
    def percentile(rank):
        cumulative=0
        for i,h in enumerate(hist):
            cumulative+=h
            if cumulative>=rank: return i
        raise ValueError('Incomplete histogram')
    raw['features']=dict(mean=raw['luma_sum']/n,dark_fraction=raw['dark_count']/n,
        bright_fraction=raw['bright_count']/n,
        hist_contrast=16*(percentile((9*n+9)//10)-percentile((n+9)//10)),
        gradient_mean=raw['gradient_sum']/n)
    return raw

def read_observations(read,build):
    if build not in (BUILD,0x50524631,0x434c4131,0x434c4132,0x434c4133,0x434c4134,0x434c4135,0x434c4136,0x434c4137,0x434c4138,0x434c4139,0x44514631): return None
    if read(0x6f0)!=MAGIC or read(0x6f4)!=0x20e01010:
        raise ValueError('Unknown OBS1 feature page ABI')
    return {name:decode([read(base+4*i) for i in range(16)])
        for name,base in (('camera_a',0x700),('camera_b',0x740))}

def main():
    import fcntl
    p=argparse.ArgumentParser();p.add_argument('--bar',type=Path,required=True)
    p.add_argument('--lock',type=Path,default=Path('/root/dual_vision_host/run/bar.lock'))
    a=p.parse_args();a.lock.parent.mkdir(parents=True,exist_ok=True)
    with a.lock.open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        with a.bar.open('r+b',buffering=0) as file,mmap.mmap(file.fileno(),4096) as bar:
            def read(offset): return ctypes.c_uint32.from_buffer(bar,offset).value
            result=read_observations(read,read(0x28c))
            if result is None: raise SystemExit('FPGA is not OBS1; no feature registers read')
            print(json.dumps(result,indent=2))

if __name__=='__main__': main()
