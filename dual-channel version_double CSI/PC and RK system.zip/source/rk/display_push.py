"""Owned native GstBuffer copy, retaining source IDs without per-byte GI work."""
import ctypes
from pathlib import Path


class FramePusher:
    def __init__(self,source):
        library=Path(__file__).resolve().with_name('libgstrkdualdisplay.so')
        self.library=ctypes.CDLL(str(library))
        self.push_native=self.library.rkdual_push_gray
        self.push_native.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t,
            ctypes.c_uint64,ctypes.c_uint64]
        self.push_native.restype=ctypes.c_int
        capsule_pointer=ctypes.pythonapi.PyCapsule_GetPointer
        capsule_pointer.argtypes=[ctypes.py_object,ctypes.c_char_p]
        capsule_pointer.restype=ctypes.c_void_p
        self.pointer=capsule_pointer(source.__gpointer__,None)
        self.source=source

    def push_timed(self,pixels,frame_id,camera,pts,duration):
        native=self.library.rkdual_push_gray_timed
        native.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t,
            ctypes.c_uint64,ctypes.c_uint64,ctypes.c_uint64,ctypes.c_uint64]
        native.restype=ctypes.c_int
        return native(self.pointer,ctypes.c_char_p(pixels),len(pixels),frame_id,camera,pts,duration)

    def push(self,pixels,frame_id,camera):
        return self.push_native(self.pointer,ctypes.c_char_p(pixels),len(pixels),frame_id,camera)
