"""Bounded asynchronous detection history with inference-frame thumbnails."""
import hashlib
import json
import os
import queue
import re
import sqlite3
import struct
import threading
import time
import zlib
from pathlib import Path

LIMIT=40
MAX_JPEG=70000

def frame_png(pixels,event):
    """Losslessly encode the 1080p grayscale frame supplied to inference."""
    width,height=1920,1080
    if len(pixels)!=width*height:raise ValueError('invalid source frame size')
    def chunk(name,data):
        return struct.pack('>I',len(data))+name+data+struct.pack('>I',zlib.crc32(name+data)&0xffffffff)
    # Stored DEFLATE blocks preserve every pixel and leave CPU time for video.
    scanlines=b''.join(b'\x00'+pixels[y*width:(y+1)*width] for y in range(height))
    compressed=zlib.compress(scanlines,0)
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',width,height,8,0,0,0,0))+chunk(b'IDAT',compressed)+chunk(b'IEND',b'')

class DetectionLog:
    def __init__(self, Gst, path, model, interval=1.0, encoder=None, require_mount=None, image_encoder=frame_png):
        self.Gst=Gst;self.path=Path(path);self.model=Path(model);self.interval=interval
        self.encoder=encoder;self.queue=queue.Queue(maxsize=2);self.last=[0.0,0.0]
        self.require_mount=Path(require_mount) if require_mount else None
        self.image_encoder=image_encoder
        self.lock=threading.Lock();self.dropped=0;self.error=None;self.saved=0
        self.thread=threading.Thread(target=self._run,name='detection-log',daemon=True)
        self.thread.start()

    def offer(self, camera, frame_id, pixels, mode, quality, epoch, boxes, confidence, inference_ms):
        if not boxes:return
        now=time.monotonic()
        with self.lock:
            if now-self.last[camera]<self.interval:return
            event=dict(camera=camera,frame_id=frame_id,mode=mode,quality=quality,epoch=epoch,
                       boxes=boxes,threshold=confidence,inference_ms=inference_ms,wall_time=time.time())
            try:self.queue.put_nowait((event,pixels));self.last[camera]=now
            except queue.Full:self.dropped+=1

    def snapshot(self):
        with self.lock:return dict(saved=self.saved,dropped=self.dropped,error=self.error,limit=LIMIT)

    def _run(self):
        pipeline=None
        try:
            if self.require_mount and not os.path.ismount(self.require_mount):
                raise RuntimeError('SD 卡未挂载，检测日志暂停')
            self.path.parent.mkdir(parents=True,exist_ok=True)
            db=sqlite3.connect(str(self.path),timeout=2)
            db.execute('PRAGMA auto_vacuum=FULL')
            db.execute('CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT, wall_time REAL NOT NULL, camera INTEGER NOT NULL, data TEXT NOT NULL, jpeg BLOB NOT NULL)')
            db.commit()
            image_dir=self.path.parent/'detection_images';image_dir.mkdir(exist_ok=True)
            retained=set()
            for data, in db.execute('SELECT data FROM events'):
                name=json.loads(data).get('image_file')
                if name:retained.add(name)
            for image in image_dir.iterdir():
                if re.fullmatch(r'record_[0-9]+_[AB]_frame_[0-9]+\.png(?:\.tmp)?',image.name) and image.name not in retained:
                    image.unlink()
            model_hash=hashlib.sha256(self.model.read_bytes()).hexdigest()
            if self.encoder is None:
                from display_push import FramePusher
                G=self.Gst
                pipeline=G.parse_launch('appsrc name=input is-live=true format=time block=false max-buffers=1 max-bytes=0 leaky-type=downstream caps=video/x-raw,format=GRAY8,width=1920,height=1080,framerate=1/1 ! videoscale method=1 ! video/x-raw,width=640,height=360 ! jpegenc quality=50 ! appsink name=output sync=false async=false max-buffers=1 drop=true')
                if pipeline.set_state(G.State.PLAYING)==G.StateChangeReturn.FAILURE:raise RuntimeError('log JPEG pipeline failed')
                pusher=FramePusher(pipeline.get_by_name('input'));sink=pipeline.get_by_name('output')
                def encode(pixels,event):
                    pts=time.monotonic_ns()
                    if pusher.push_timed(pixels,event['frame_id'],event['camera'],pts,1000000000)!=G.FlowReturn.OK:raise RuntimeError('log JPEG input failed')
                    sample=sink.emit('try-pull-sample',1000000000)
                    if sample is None:raise RuntimeError('log JPEG timeout')
                    buf=sample.get_buffer()
                    if buf.pts!=pts:raise RuntimeError('log JPEG frame mismatch')
                    return buf.extract_dup(0,buf.get_size())
                self.encoder=encode
            while True:
                item=self.queue.get()
                if item is None:break
                event,pixels=item
                try:
                    if self.require_mount and not os.path.ismount(self.require_mount):
                        raise RuntimeError('SD 卡未挂载，检测日志暂停')
                    jpeg=self.encoder(pixels,event)
                    if not jpeg or len(jpeg)>MAX_JPEG:raise ValueError('log JPEG exceeds size limit')
                    png=self.image_encoder(pixels,event)
                    event.update(model_sha256=model_hash,image_width=640,image_height=360,
                                 source_width=1920,source_height=1080)
                    created=None;temporary=None
                    try:
                        with db:
                            cursor=db.execute('INSERT INTO events(wall_time,camera,data,jpeg) VALUES(?,?,?,?)',
                                (event['wall_time'],event['camera'],'{}',jpeg))
                            event['image_file']=f"record_{cursor.lastrowid:010d}_{'AB'[event['camera']]}_frame_{event['frame_id']}.png"
                            created=image_dir/event['image_file'];temporary=image_dir/(event['image_file']+'.tmp')
                            with temporary.open('xb') as out:out.write(png)
                            os.replace(temporary,created);temporary=None
                            db.execute('UPDATE events SET data=? WHERE id=?',(json.dumps(event,ensure_ascii=False),cursor.lastrowid))
                            expired=db.execute('SELECT data FROM events WHERE id NOT IN (SELECT id FROM events ORDER BY id DESC LIMIT ?)',(LIMIT,)).fetchall()
                            db.execute('DELETE FROM events WHERE id NOT IN (SELECT id FROM events ORDER BY id DESC LIMIT ?)',(LIMIT,))
                    except Exception:
                        if temporary:temporary.unlink(missing_ok=True)
                        if created:created.unlink(missing_ok=True)
                        raise
                    for data, in expired:
                        name=json.loads(data).get('image_file','')
                        if re.fullmatch(r'record_[0-9]+_[AB]_frame_[0-9]+\.png',name):
                            (image_dir/name).unlink(missing_ok=True)
                    with self.lock:self.saved+=1
                except Exception as exc:
                    with self.lock:self.error=str(exc);self.dropped+=1
            db.close()
        except Exception as exc:
            with self.lock:self.error=str(exc)
        finally:
            if pipeline:pipeline.set_state(self.Gst.State.NULL)

    def close(self):
        try:self.queue.put(None,timeout=2)
        except queue.Full:return
        self.thread.join(timeout=5)
