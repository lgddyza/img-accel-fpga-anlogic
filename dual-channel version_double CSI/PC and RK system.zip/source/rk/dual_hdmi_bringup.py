#!/usr/bin/env python3
"""DJP2 DMA -> per-camera native JPEG workers -> selectable HDMI.

Uses a project-local strict decoder with direct stripe reconstruction.
Legacy decoding requires an explicit option because it ignores warnings. Does not load the V1
V4L2 driver. Both cameras are received; BAR bit14 selects the displayed one.
"""
import argparse
from collections import deque
import ctypes
import json
import mmap
import os
from pathlib import Path
import queue
import signal
import sys
import threading
import time
from dual_csi_protocol import Assembler, CONTROL_MAGIC, PacketStream, parse_packet, _marker_scan
from dual_control import STREAM_BUILDS, decode_stream_diagnostics, read_performance, read_store_diagnostics
from feature_observer import read_observations


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--seconds', type=float, default=30)
    ap.add_argument('--connector', type=int, default=188)
    ap.add_argument('--bar', default='/sys/bus/pci/devices/0000:21:00.0/resource0')
    ap.add_argument('--out', type=Path, default=Path('/tmp/dual_hdmi_bringup/results'))
    ap.add_argument('--switch-every', type=float, default=0)
    ap.add_argument('--decode-queue', type=int, default=4)
    ap.add_argument('--decoder', choices=('direct', 'original'), default='direct')
    ap.add_argument('--decode-affinity', choices=('auto', 'none'), default='auto')
    ap.add_argument('--telemetry-mode', choices=('async', 'inline'), default='async')
    ap.add_argument('--save-frames', type=int, default=2)
    ap.add_argument('--dma-bytes', type=int, default=4*1024*1024)
    ap.add_argument('--jpeg-library', type=Path, default=Path(__file__).resolve().with_name('libjpeg_str4.so'))
    ap.add_argument('--allow-legacy-decoder', action='store_true')
    ap.add_argument('--replay', type=Path, help='Explicit offline RTL packets; NOT camera data')
    ap.add_argument('--status-file', type=Path)
    ap.add_argument('--preview-port', type=int, default=0)
    ap.add_argument('--quiet', action='store_true')
    ap.add_argument('--no-osd', action='store_true')
    ap.add_argument('--display-convert', choices=('fast','generic'), default='fast')
    ap.add_argument('--skip-vsync', action='store_true', default=True)
    ap.add_argument('--wait-vsync', action='store_false', dest='skip_vsync')
    ap.add_argument('--display-settings', type=Path)
    ap.add_argument('--yolo-settings', type=Path)
    ap.add_argument('--yolo-model', default='/root/road_damage_yolov8n/road_damage_yolov8n_gray640_int8_rk3576.rknn')
    ap.add_argument('--yolo-library', default='/root/jpeg_rk/libroad_infer.so')
    args = ap.parse_args()
    if args.allow_legacy_decoder and args.decoder != 'original':
        ap.error('allow-legacy-decoder requires --decoder original')
    if args.decode_queue < 1 or args.save_frames < 0:
        ap.error('decode-queue must be positive; save-frames must be nonnegative')
    if args.dma_bytes < 4096 or args.dma_bytes > 4*1024*1024 or args.dma_bytes % 4096:
        ap.error('dma-bytes must be page aligned and within 4096..4194304')
    args.out.mkdir(parents=True, exist_ok=True)
    sys.path.insert(0, '/root/jpeg_rk')
    from capture_jpeg_tiles import Gst, NativeJpegDecoder, weave, _jpeg_lib, _weave_lib
    if _jpeg_lib is None:
        raise RuntimeError('Existing native JPEG decoder is unavailable')
    if args.allow_legacy_decoder:
        decoder_lib = _jpeg_lib
    else:
        decoder_lib = ctypes.CDLL(str(args.jpeg_library.resolve()))
        decoder_lib.jpeg_decode_gray.argtypes = _jpeg_lib.jpeg_decode_gray.argtypes
        decoder_lib.jpeg_decode_gray.restype = ctypes.c_int
    Gst.init(None)
    if args.display_convert == 'fast':
        Gst.Plugin.load_file(str(Path(__file__).resolve().with_name('libgstrkdualdisplay.so')))
    from live_status import LiveStatus
    live_status = LiveStatus(args.status_file)
    preview = None
    if args.preview_port:
        from dual_preview import DualPreview
        preview = DualPreview(Gst, args.preview_port)
    pipe = Gst.parse_launch(
        'appsrc name=frames is-live=true format=time do-timestamp=true block=false '
        'caps=video/x-raw,format=GRAY8,width=1920,height=1080,framerate=60/1 '
        '! queue name=display_buffer max-size-buffers=2 max-size-bytes=0 max-size-time=0 leaky=downstream '
        + ('! rkdualgray name=display_convert osd='+str(not args.no_osd).lower()+' '
           if args.display_convert == 'fast' else '! videoconvert name=display_convert ')
        + '! video/x-raw,format=NV12 '
        + '! queue name=present_buffer max-size-buffers=4 max-size-bytes=0 max-size-time=0 leaky=downstream '
        + f'! kmssink name=hdmi connector-id={args.connector} sync=false '
        + f'skip-vsync={str(args.skip_vsync).lower()}')
    src = pipe.get_by_name('frames')
    from display_push import FramePusher
    pusher=FramePusher(src)
    from display_metrics import DisplayMetrics
    display_metrics = DisplayMetrics(Gst, pipe)
    converter = pipe.get_by_name('display_convert')
    bus = pipe.get_bus()
    assembler = Assembler(max_pending=12)
    streams = [PacketStream(ch) for ch in (1, 2, 3)]
    events = queue.Queue(maxsize=192)
    decode_queues = [queue.Queue(maxsize=args.decode_queue) for _ in range(2)]
    display_queue = queue.Queue(maxsize=4)
    stop = threading.Event()
    from dual_yolo import DualYolo, Detector
    from detection_log import DetectionLog
    log_mount = Path('/mnt/vision_sd')
    detection_log = DetectionLog(Gst, log_mount/'dual_vision'/'detection_history.sqlite3', args.yolo_model, require_mount=log_mount) if args.status_file else None
    yolo = DualYolo(lambda camera: Detector(args.yolo_model,
        Path(__file__).resolve().with_name('libroad_parallel%d.so' % camera), camera), detection_log=detection_log)
    if preview:
        preview.yolo = yolo
    settings_cache = None
    from adaptive_policy import AdaptivePolicy, SharedQfController, PreprocessController, predict_preprocess
    adaptive_policy = AdaptivePolicy()
    shared_qf = SharedQfController()
    camera_qf = [SharedQfController(), SharedQfController()]
    preprocess_control = [PreprocessController(), PreprocessController()]
    qf_mode = [None]
    adaptive_enabled = False
    yolo_overlay_cache = None
    last_yolo_overlay = 0.0
    stats = dict(source='RTL_REPLAY' if args.replay else 'LIVE_PCIE',
                 dma_reads=[0]*3, dma_bytes=[0]*3, bad_packets=0, queue_drops=0,
                 complete_frames=[0, 0], decoded_frames=[0, 0], submitted_hdmi=[0, 0],
                 decode_queue_drops=[0, 0], display_queue_drops=[0, 0],
                 decoder_validation='legacy_ignores_warnings' if args.allow_legacy_decoder else 'strict',
                 decode_rejected_frames=[0, 0],
                 decode_seconds=[0.0, 0.0], bad_packet_records=[], stream_resync_records=[],
                 dma_errors=[], decode_errors=[], switches=[], bar_samples=[], last_frame_ids=[None, None],
                 decoded_modes=[None, None], decoded_quality=[None, None], submitted_modes=[None, None])
    manual_qf_marker = [None]
    manual_mode_markers = [None, None]
    main_heartbeat = [time.monotonic()]
    def sync_manual_qf():
        marker = args.status_file.with_name('manual_qf')
        try:
            token = marker.read_text()
        except FileNotFoundError:
            token = ''
        if manual_qf_marker[0] is not None and token != manual_qf_marker[0]:
            shared_qf.manual_change()
            for controller in camera_qf: controller.manual_change()
        manual_qf_marker[0] = token
        for camera in (0, 1):
            marker = args.status_file.with_name('manual_mode_'+('a','b')[camera])
            try:
                token = marker.read_text()
            except FileNotFoundError:
                token = ''
            if manual_mode_markers[camera] is not None and token != manual_mode_markers[camera]:
                preprocess_control[camera].manual_change()
            manual_mode_markers[camera] = token
    bar_file = bar = None
    if not args.replay:
        bar_file = open(args.bar, 'r+b', buffering=0)
        bar = mmap.mmap(bar_file.fileno(), 4096)
        if ctypes.c_uint32.from_buffer(bar, 0x200).value != CONTROL_MAGIC:
            raise RuntimeError('Expected DVC2 BAR')
    def rd(offset):
        return ctypes.c_uint32.from_buffer(bar, offset).value
    def wr(offset, value):
        ctypes.c_uint32.from_buffer(bar, offset).value = value
    def sample():
        nonlocal shared_qf
        if args.status_file:
            import fcntl
            with args.status_file.with_name('bar.lock').open('a') as lock:
                while not stop.is_set():
                    try:
                        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                        break
                    except BlockingIOError:
                        stop.wait(.01)
                else:
                    return None
                sync_manual_qf()
                now = time.monotonic()
                enabled_now = adaptive_enabled and now-main_heartbeat[0] <= 3
                result = hardware_sample()
                try:
                    adaptive = adaptive_policy.update(result.get('feature_observations'), now, enabled_now)
                except Exception as exc:
                    adaptive = adaptive_policy.update(None, now, False)
                    adaptive['error'] = str(exc)
                yolo.set_intervals([1/x['yolo_limit_fps'] if x['yolo_limit_fps'] else 0.0
                                    for x in adaptive['cameras']])
                word = rd(0x218) & 0x7fff
                updated_word = word
                observations = result.get('feature_observations') or {}
                supported = result['configuration'].get('supported_modes')
                for camera, controller in enumerate(preprocess_control):
                    state = adaptive['cameras'][camera]
                    obs = observations.get(('camera_a','camera_b')[camera]) or {}
                    prediction = predict_preprocess(obs.get('features') or {}) if state['identity'] else None
                    shift = 1 + 3*camera
                    target = controller.update((word >> shift) & 7, state, prediction, supported, enabled_now, now)
                    if target is not None:
                        updated_word = (updated_word & ~(7 << shift)) | (target << shift)
                    state['preprocess_prediction'] = prediction
                    state['preprocess_control'] = dict(base=controller.base, target=controller.applied,
                                                       manual_override=controller.manual_override)
                if updated_word != word:
                    wr(0x218, updated_word)
                    word = updated_word
                dual = result['configuration'].get('dual_qf')
                independent = dual is not None and bool(dual & (1 << 16))
                if qf_mode[0] != independent:
                    shared_qf = SharedQfController()
                    camera_qf[:] = [SharedQfController(), SharedQfController()]
                    qf_mode[0] = independent
                if independent:
                    updated = dual
                    for camera, controller in enumerate(camera_qf):
                        shift = camera * 8
                        target = controller.update((dual >> shift) & 127, [adaptive['cameras'][camera]], enabled_now, now)
                        if target is not None: updated = (updated & ~(127 << shift)) | (target << shift)
                    if updated != dual: wr(0x2a0, updated)
                    adaptive['qf_control'] = 'independent'
                    adaptive['independent_qf'] = [dict(base=c.base,target=c.applied,manual_override=c.manual_override) for c in camera_qf]
                else:
                    target = shared_qf.update((word >> 7) & 127, adaptive['cameras'], enabled_now, now)
                    if target is not None: wr(0x218, (word & ~(127 << 7)) | (target << 7))
                    result['shared_qf_auto'] = dict(base=shared_qf.base, target=shared_qf.applied,
                                                    manual_override=shared_qf.manual_override)
                    adaptive['shared_qf'] = result['shared_qf_auto']
                result['adaptive'] = adaptive
                return result
        return hardware_sample()
    def hardware_sample():
        return dict(t=round(time.monotonic()-started, 3), revision=hex(rd(0x284)),
                    configuration=dict(supported_modes=rd(0x280),applied_quality=rd(0x224),
                        dual_qf_supported=rd(0x2a4)==0x32465144,
                        dual_qf=rd(0x2a0) if rd(0x2a4)==0x32465144 else None,
                        gaussian_strength=rd(0x22c) if rd(0x28c) in (0x50524631,0x434c4131,0x434c4132,0x434c4133,0x434c4134,0x434c4135,0x434c4136,0x434c4137,0x434c4138,0x434c4139,0x44514631) else None),
                    rx_build=hex(rd(0x288)),
                    store_diagnostics=read_store_diagnostics(rd, rd(0x28c)),
                    feature_observations=read_observations(rd, rd(0x28c)),
                    stream_diagnostics=decode_stream_diagnostics([
                        rd(offset) for offset in (0x28c,0x290,0x294,0x298,0x348,0x34c,0x350,0x354,0x358)
                    ]) if rd(0x28c) in STREAM_BUILDS else None,
                    performance=read_performance(rd,rd(0x28c)),
                    calibration=[rd(0x340),rd(0x344)] if rd(0x288)==0x444c5931 else None,
                    status=rd(0x220), control=rd(0x218),
                    statistics=[rd(0x240+4*i) for i in range(16)],
                    jpeg_packets=[rd(0x230+4*i) for i in range(3)],
                    jpeg_errors=rd(0x23c), diagnostics=[rd(0x300+4*i) for i in range(16)])
    opened = [threading.Event() for _ in range(3)]
    receiver_threads = []
    decoder_threads = []
    decode_durations = [deque(maxlen=600), deque(maxlen=600)]
    queue_waits = [deque(maxlen=600), deque(maxlen=600)]
    queue_peaks = [0, 0]
    stats['decoder_runtime'] = dict(backend=args.decoder, affinity=args.decode_affinity,
        telemetry_mode=args.telemetry_mode, queue_capacity=args.decode_queue, workers=[None, None],
        framing='native-marker' if _marker_scan else 'python-marker')

    def timing_snapshot():
        def distribution(values):
            values = sorted(values)
            return dict(samples=len(values), p50_ms=values[len(values)//2] if values else None,
                p95_ms=values[int((len(values)-1)*.95)] if values else None,
                max_ms=max(values) if values else None)
        stats['decoder_runtime']['timing'] = [dict(
            decode=distribution(decode_durations[camera]),
            queue_wait=distribution(queue_waits[camera]),
            queued=decode_queues[camera].qsize(), peak_queued=queue_peaks[camera])
            for camera in (0, 1)]

    def receiver(ch):
        fd = None
        try:
            fd = os.open('/dev/ANLOGIC-PCI0_c2h_'+str(ch), os.O_RDONLY | os.O_TRUNC)
            with mmap.mmap(-1, args.dma_bytes) as buf:
                address = ctypes.addressof(ctypes.c_char.from_buffer(buf))
                libc = ctypes.CDLL(None, use_errno=True)
                libc.read.argtypes = [ctypes.c_int, ctypes.c_void_p, ctypes.c_size_t]
                libc.read.restype = ctypes.c_ssize_t
                opened[ch-1].set()
                while not stop.is_set():
                    n = libc.read(fd, address, len(buf))
                    if n < 0:
                        raise OSError(ctypes.get_errno(), os.strerror(ctypes.get_errno()))
                    if not n:
                        raise RuntimeError('DMA returned EOF')
                    stats['dma_reads'][ch-1] += 1
                    stats['dma_bytes'][ch-1] += n
                    try:
                        events.put_nowait((ch, buf[:n]))
                    except queue.Full:
                        stats['queue_drops'] += 1
        except Exception as exc:
            if not stop.is_set():
                stats['dma_errors'].append(dict(channel=ch, error=str(exc)))
                stop.set()
        finally:
            opened[ch-1].set()
            if fd is not None:
                os.close(fd)

    def decode_worker(camera):
        # Each camera owns its decoder buffers. Native calls release the GIL.
        from stripe_decoder import StripeDecoder, bind_decoder
        try:
            stats['decoder_runtime']['workers'][camera] = bind_decoder(camera, args.decode_affinity)
            direct = StripeDecoder() if args.decoder == 'direct' else None
            decoders = [NativeJpegDecoder(360) for _ in range(3)] if not direct else []
            raster = ctypes.create_string_buffer(1920*1080) if not direct else None
        except Exception as exc:
            stats['decode_errors'].append(dict(camera=camera, error=str(exc)))
            stop.set()
            return
        while not stop.is_set():
            try:
                queued_at, tiles = decode_queues[camera].get(timeout=0.1)
            except queue.Empty:
                continue
            began = time.monotonic()
            queue_waits[camera].append((began-queued_at)*1000)
            try:
                if direct:
                    pixels = direct.decode([tile.jpeg for tile in tiles])
                else:
                    for decoder, tile in zip(decoders, tiles):
                        result = decoder_lib.jpeg_decode_gray(ctypes.c_char_p(tile.jpeg), len(tile.jpeg),
                            decoder.output, 1920, 360, decoder.error, len(decoder.error))
                        if result:
                            raise RuntimeError(f'tile={tile.tile} '+decoder.error.value.decode(errors='replace'))
                    if _weave_lib:
                        _weave_lib.jpeg_weave_1080p(raster, *(d.output for d in decoders))
                        pixels = raster.raw
                    else:
                        pixels = bytes(weave(*(d.output.raw for d in decoders)))
            except Exception as exc:
                stats['decode_rejected_frames'][camera] += 1
                if len(stats['decode_errors']) < 64:
                    stats['decode_errors'].append(dict(camera=camera, frame=tiles[0].frame_id, error=str(exc)))
                if stats['decode_rejected_frames'][camera] <= 4:
                    for tile in tiles:
                        (args.out/f'rejected_camera_{camera}_frame_{tile.frame_id}_tile_{tile.tile}.jpg').write_bytes(tile.jpeg)
                continue
            duration = time.monotonic()-began
            stats['decode_seconds'][camera] += duration
            decode_durations[camera].append(duration*1000)
            stats['decoded_frames'][camera] += 1
            stats['last_frame_ids'][camera] = tiles[0].frame_id
            stats['decoded_modes'][camera] = tiles[0].mode
            stats['decoded_quality'][camera] = tiles[0].quality
            yolo.offer(camera, tiles[0].frame_id, pixels, tiles[0].mode, tiles[0].quality, tiles[0].epoch)
            if preview:
                preview.offer(camera, pixels, tiles[0].frame_id, tiles[0].mode)
            if stats['decoded_frames'][camera] <= args.save_frames:
                tag = f"camera_{camera}_{stats['decoded_frames'][camera]}"
                (args.out/(tag+'.pgm')).write_bytes(b'P5\n1920 1080\n255\n'+pixels)
                for t in tiles:
                    (args.out/f'{tag}_tile_{t.tile}.jpg').write_bytes(t.jpeg)
            if args.replay or camera == last_display:
                try:
                    display_queue.put_nowait((camera, pixels, tiles[0].frame_id, tiles[0].mode))
                except queue.Full:
                    stats['display_queue_drops'][camera] += 1
        if direct:
            direct.close()

    def display_worker():
        try:
            while not stop.is_set():
                try:
                    camera, pixels, frame_id, mode = display_queue.get(timeout=0.1)
                except queue.Empty:
                    continue
                if args.replay or camera == last_display:
                    if pusher.push(pixels, frame_id, camera) != int(Gst.FlowReturn.OK):
                        raise RuntimeError('HDMI appsrc rejected a frame')
                    stats['submitted_hdmi'][camera] += 1
                    stats['submitted_modes'][camera] = mode
        except Exception as exc:
            stats['display_submit_error'] = str(exc)
            stop.set()

    def interrupt(*_):
        stop.set()
    signal.signal(signal.SIGINT, interrupt)
    signal.signal(signal.SIGTERM, interrupt)
    started = time.monotonic()
    last_sample = -1
    last_display = None
    sampler = None
    if bar is not None and args.telemetry_mode == 'async':
        from board_sampler import BoardSampler
        sampler = BoardSampler(sample, stop, interval=.25)
        sampler.latest = sample()
        sampler.thread.start()
    if pipe.set_state(Gst.State.PLAYING) == Gst.StateChangeReturn.FAILURE:
        raise RuntimeError('HDMI pipeline could not start')
    display_thread = threading.Thread(target=display_worker, name='hdmi-submit', daemon=True)
    display_thread.start()
    for camera in (0, 1):
        thread = threading.Thread(target=decode_worker, args=(camera,), daemon=True)
        thread.start()
        decoder_threads.append(thread)
    if args.replay:
        for camera in (0, 1):
            for lane in range(3):
                events.put((lane+1, (args.replay/f'cam_{camera}_tile_{lane}.djp').read_bytes()))
        print('RTL_REPLAY: software-generated simulation images; no live capture', flush=True)
    else:
        # Clear old stream state with capture disabled. Arm all three DMA
        # readers before enabling production, avoiding the former 100ms lead.
        requested = rd(0x218) & 0x7ffe
        wr(0x218, requested | 0x80000000)
        time.sleep(0.02)
        for ch in (1, 2, 3):
            thread = threading.Thread(target=receiver, args=(ch,), daemon=True)
            thread.start()
            receiver_threads.append(thread)
        if not all(event.wait(2) for event in opened) or stats['dma_errors']:
            stop.set()
        else:
            time.sleep(0.02)
            wr(0x218, requested | 1)
    try:
        while not stop.is_set() and time.monotonic()-started < args.seconds:
            main_heartbeat[0] = time.monotonic()
            elapsed = time.monotonic()-started
            if args.yolo_settings and int(elapsed) != last_sample:
                try:
                    setting = json.loads(args.yolo_settings.read_text())
                    adaptive_enabled = setting.get('adaptive_enabled') is True
                    enabled = [bool(setting.get('enable_a')),bool(setting.get('enable_b'))]
                    confidence = max(0.01,min(1.0,float(setting.get('confidence',0.10))))
                    config = (tuple(enabled),confidence)
                    if config != settings_cache:
                        yolo.configure(enabled,confidence);settings_cache=config
                except (OSError,ValueError,TypeError):
                    adaptive_enabled = False
            if bar is not None:
                if args.switch_every:
                    desired = int(elapsed/args.switch_every) % 2
                    current = rd(0x218)
                    if (current >> 14) & 1 != desired:
                        wr(0x218, (current & 0x3fff) | (desired << 14))
                selected = (rd(0x218) >> 14) & 1
                if int(elapsed) != last_sample:
                    last_sample = int(elapsed)
                    timing_snapshot()
                    if sampler and sampler.error:
                        raise RuntimeError('Board sampling failed: '+sampler.error)
                    stats['bar_samples'].append(sampler.latest if sampler else sample())
                    board_sample = stats['bar_samples'][-1]
                    stats['adaptive'] = board_sample.get('adaptive')
                    stats['decoder_runtime']['telemetry_max_read_ms'] = sampler.max_read_ms if sampler else None
                    if args.status_file:
                        snapshot_request=args.status_file.with_name('hdmi_snapshot.request')
                        if snapshot_request.exists():
                            snapshot_request.unlink(missing_ok=True)
                            display_metrics.request_snapshot(args.status_file.parent)
                        stats['display'] = display_metrics.sample(src)
                        stats['bar_samples'] = stats['bar_samples'][-20:]
                        stats['packet_streams'] = [s.diagnostics() for s in streams]
                        stats['runtime_elapsed'] = time.monotonic()-started
                        stats['yolo'] = yolo.snapshot()
                        stats['detection_log'] = detection_log.snapshot() if detection_log else None
                        live_status.write(stats, stats['bar_samples'][-1], selected,
                            preview.status(include_token=True) if preview else None)
                        if args.display_convert == 'fast':
                            if args.display_settings:
                                try:
                                    settings = json.loads(args.display_settings.read_text())
                                    if type(settings.get('osd')) is bool:
                                        converter.set_property('osd',settings['osd'])
                                except (OSError,ValueError):
                                    pass
                            live = live_status.latest
                            def fps(value):
                                return '--' if value is None else f'{value:.1f}'
                            mode = stats['submitted_modes'][selected]
                            mode_text = {0:'GRAY', 1:'GAUSS', 2:'CLAHE', 3:'GAUSS+CLAHE', 4:'SOBEL', 5:'BLACKHAT'}.get(mode, '--')
                            converter.set_property('text',
                                f"CAM {'AB'[selected]}  1920x1080\n"
                                f"HDMI FPS:{fps(live['display'].get('rendered_fps_avg'))}\n"
                                f"DECODE A:{fps(live['rates']['decoded'][0])} B:{fps(live['rates']['decoded'][1])}\n"
                                f"MODE:{mode_text}  QF:{stats['bar_samples'][-1]['configuration']['applied_quality']}\n"
                                f"YOLO A:{fps(stats['yolo']['fps'][0])} B:{fps(stats['yolo']['fps'][1])}")
                    if not args.quiet:
                        print(json.dumps(dict(t=last_sample, selected=selected,
                        reads=stats['dma_reads'], packets=[s.complete_packets for s in streams],
                        frames=stats['complete_frames'],
                        hdmi=stats['submitted_hdmi'], errors=stats['dma_errors'])), flush=True)
            else:
                selected = 0
            if selected != last_display:
                stats['switches'].append(dict(t=elapsed, camera=selected))
                if args.status_file:
                    stats['switches'] = stats['switches'][-20:]
                last_display = selected
            if args.display_convert == 'fast' and time.monotonic()-last_yolo_overlay >= 0.1:
                last_yolo_overlay=time.monotonic()
                info=yolo.snapshot(); result=info['results'][selected]
                active=info['enabled'][selected] and result and result['age_ms']<=750 and result['mode']==stats['submitted_modes'][selected]
                boxes=';'.join(','.join(str(v) for v in (int(b['x1']),int(b['y1']),int(b['x2']),int(b['y2']),b['cls'],round(b['confidence']*100))) for b in result['boxes'][:64]) if active else ''
                if boxes != yolo_overlay_cache:converter.set_property('boxes',boxes);yolo_overlay_cache=boxes
            message = bus.pop_filtered(Gst.MessageType.ERROR)
            if message:
                error, debug = message.parse_error()
                raise RuntimeError(str(error)+' '+str(debug))
            try:
                ch, chunk = events.get(timeout=0.1)
            except queue.Empty:
                continue
            stream = streams[ch-1]
            before = (stream.invalid_packets, stream.discarded_bytes)
            packets = stream.feed(chunk)
            if before != (stream.invalid_packets, stream.discarded_bytes):
                if len(stats['stream_resync_records']) < 16:
                    tag = f"resync_read_{len(stats['stream_resync_records'])+1:02d}_ch{ch}.bin"
                    (args.out/tag).write_bytes(chunk)
                    stats['stream_resync_records'].append(dict(file=tag, channel=ch,
                        t=time.monotonic()-started, length=len(chunk),
                        invalid_packets=stream.invalid_packets-before[0],
                        discarded_bytes=stream.discarded_bytes-before[1]))
            for packet in packets:
                try:
                    tile = parse_packet(packet, dma_channel=ch)
                    tiles = assembler.push(tile)
                except ValueError as exc:
                    stats['bad_packets'] += 1
                    if stats['bad_packets'] <= 16:
                        tag = f"bad_packet_{stats['bad_packets']:02d}_ch{ch}.bin"
                        (args.out/tag).write_bytes(packet)
                        stats['bad_packet_records'].append(dict(file=tag, channel=ch,
                            t=time.monotonic()-started, length=len(packet), error=str(exc),
                            head_hex=packet[:48].hex(), tail_hex=packet[-32:].hex()))
                    if stats['bad_packets'] <= 3:
                        print('BAD_PACKET '+str(exc), flush=True)
                    continue
                if not tiles:
                    continue
                camera = tiles[0].camera
                stats['complete_frames'][camera] += 1
                try:
                    decode_queues[camera].put_nowait((time.monotonic(), tiles))
                    queue_peaks[camera] = max(queue_peaks[camera], decode_queues[camera].qsize())
                except queue.Full:
                    stats['decode_queue_drops'][camera] += 1
    finally:
        stats['elapsed'] = time.monotonic()-started
        stop.set()
        yolo.close()
        if detection_log: detection_log.close()
        if sampler:
            sampler.thread.join(timeout=6)
            if sampler.thread.is_alive():
                raise RuntimeError('Board sampler did not stop; refusing to close its MMIO mapping')
        if bar is not None:
            if args.status_file:
                import fcntl
                with args.status_file.with_name('bar.lock').open('a') as lock:
                    fcntl.flock(lock, fcntl.LOCK_EX)
                    sync_manual_qf()
                    word = rd(0x218) & 0x7fff
                    updated_word = word
                    supported = rd(0x280)
                    for camera, controller in enumerate(preprocess_control):
                        shift = 1 + 3*camera
                        target = controller.update((word >> shift) & 7, {}, None, supported, False, time.monotonic())
                        if target is not None:
                            updated_word = (updated_word & ~(7 << shift)) | (target << shift)
                    if updated_word != word:
                        wr(0x218, updated_word)
                        word = updated_word
                    dual = rd(0x2a0) if rd(0x2a4)==0x32465144 else None
                    if dual is not None and dual & (1 << 16):
                        updated = dual
                        for camera, controller in enumerate(camera_qf):
                            shift = camera * 8
                            target = controller.update((dual >> shift) & 127, [], False, time.monotonic())
                            if target is not None: updated = (updated & ~(127 << shift)) | (target << shift)
                        if updated != dual: wr(0x2a0, updated)
                    else:
                        target = shared_qf.update((word >> 7) & 127, [], False, time.monotonic())
                        if target is not None: wr(0x218, (word & ~(127 << 7)) | (target << 7))
            if sampler:
                stats['bar_samples'].append(sampler.latest)
                if sampler.error:
                    stats['dma_errors'].append(dict(source='telemetry', error=sampler.error))
            else:
                stats['bar_samples'].append(hardware_sample())
            # Disable capture before joining readers; the kernel read timeout
            # bounds their shutdown. These expected timeouts are not failures.
            wr(0x218, rd(0x218) & 0x7ffe)
        for thread in decoder_threads+[display_thread]:
            thread.join(timeout=2)
        for thread in receiver_threads:
            thread.join(timeout=12)
        stats['workers_still_alive'] = [t.name for t in decoder_threads+receiver_threads+[display_thread] if t.is_alive()]
        timing_snapshot()
        if bar is not None:
            bar.close()
            bar_file.close()
        stats['incomplete_drops'] = assembler.incomplete_drops
        stats['packet_streams'] = [s.diagnostics() for s in streams]
        stats['pending_frame_groups'] = len(assembler.pending)
        stats['pending_dma_reads_at_shutdown'] = events.qsize()
        if args.status_file and stats['bar_samples']:
            stats['runtime_elapsed'] = stats['elapsed']
            live_status.write(stats, stats['bar_samples'][-1], selected,
                preview.status(include_token=True) if preview else None, running=False)
        if preview:
            preview.close()
        pipe.set_state(Gst.State.NULL)
        display_metrics.close()
        (args.out/'result.json').write_text(json.dumps(stats, indent=2))
        print('RESULT '+json.dumps({k:v for k,v in stats.items() if k!='bar_samples'}), flush=True)


if __name__ == '__main__':
    main()
