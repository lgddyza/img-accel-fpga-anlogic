"""Prove native streaming probes work while the Python GIL is unavailable."""
import ctypes
import json
import time
import gi
gi.require_version('Gst', '1.0')
from gi.repository import Gst
from native_display_probe import NativeDisplayProbe

Gst.init(None)
pipe = Gst.parse_launch(
    'videotestsrc is-live=true ! video/x-raw,width=16,height=16,framerate=120/1 '
    '! queue name=before max-size-buffers=2 leaky=downstream '
    '! queue name=after max-size-buffers=2 leaky=downstream '
    '! fakesink name=sink sync=false')
probe = NativeDisplayProbe(*(pipe.get_by_name(name) for name in ('sink', 'before', 'after')))
try:
    assert pipe.set_state(Gst.State.PLAYING) != Gst.StateChangeReturn.FAILURE
    time.sleep(.2)
    first, begin = probe.snapshot()
    # PyDLL deliberately retains the GIL during this native sleep.
    libc = ctypes.PyDLL('libc.so.6')
    libc.usleep.argtypes = [ctypes.c_uint]
    libc.usleep.restype = ctypes.c_int
    assert libc.usleep(250000) == 0
    after, end = probe.snapshot()
    count = end[0]-begin[0]
    assert count >= 20, ('Streaming stalled behind the GIL', count)
    assert all(x[0] <= y[0] for x, y in zip(after, after[1:]))
    assert end[1:] == [0, 0], end
    print(json.dumps(dict(passed=True, arrivals_while_gil_held=count,
                          held_ms=250, native_samples=len(after))))
finally:
    pipe.set_state(Gst.State.NULL)
    probe.close()
    probe.close()
