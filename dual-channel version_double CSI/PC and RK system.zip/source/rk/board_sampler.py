"""Read control telemetry independently of the video packet consumer."""
import threading
import time


class BoardSampler:
    def __init__(self, read, stop, interval=1.0):
        self.read = read
        self.stop = stop
        self.interval = interval
        self.latest = None
        self.error = None
        self.max_read_ms = 0.0
        self.thread = threading.Thread(target=self.run, daemon=True)

    def run(self):
        while not self.stop.is_set():
            began = time.monotonic()
            try:
                value = self.read()
                if value is not None:
                    self.latest = value
            except Exception as exc:
                self.error = str(exc)
                self.stop.set()
                return
            self.max_read_ms = max(self.max_read_ms, (time.monotonic()-began)*1000)
            self.stop.wait(max(0, self.interval-(time.monotonic()-began)))
