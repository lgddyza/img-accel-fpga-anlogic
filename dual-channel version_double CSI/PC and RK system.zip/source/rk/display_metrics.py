"""Bounded display timing samples; sink counts are distinct from appsrc input."""
from collections import deque
import json
import threading
import time


class DisplayMetrics:
    def __init__(self, Gst, pipe):
        self.Gst = Gst
        self.sink = pipe.get_by_name('hdmi')
        self.queue = pipe.get_by_name('display_buffer')
        self.present_queue = pipe.get_by_name('present_buffer')
        self.arrivals = deque(maxlen=7200)
        self.source_frames = deque(maxlen=7200)
        self.last = None
        self.history = deque(maxlen=8)
        self.overruns = 0
        self.present_overruns = 0
        self.capturing = False
        from native_display_probe import NativeDisplayProbe
        self.probe = NativeDisplayProbe(self.sink, self.queue, self.present_queue)

    def close(self):
        self.probe.close()

    def sample(self, source):
        now = time.monotonic()
        records, totals = self.probe.snapshot()
        self.source_frames = records
        self.arrivals = [record[0] for record in records]
        self.overruns, self.present_overruns = totals[1:]
        s = self.sink.get_property('stats')
        rendered, dropped = int(s.get_value('rendered')), int(s.get_value('dropped'))
        previous, self.last = self.last, (now, rendered, dropped)
        self.history.append(self.last)
        while len(self.history)>2 and now-self.history[1][0]>=5:
            self.history.popleft()
        first = self.history[0]
        stamps = list(self.arrivals)
        stamps = [t for t in stamps if now-t <= 5]
        gaps = sorted((b-a)*1000 for a, b in zip(stamps, stamps[1:]))
        result = dict(sample_s=now, rendered=rendered, sink_dropped=dropped,
            probe_backend='native', sink_arrivals=totals[0],
            rendered_fps=None if not previous else (rendered-previous[1])/(now-previous[0]),
            rendered_fps_avg=None if now-first[0]<.1 else (rendered-first[1])/(now-first[0]),
            queue_overrun_events=self.overruns,
            present_queue_overrun_events=self.present_overruns,
            sink_gap_ms_p50=gaps[len(gaps)//2] if gaps else None,
            sink_gap_ms_p95=gaps[int((len(gaps)-1)*.95)] if gaps else None,
            sink_gap_ms_max=max(gaps) if gaps else None,
            sink_gaps_over_25ms=sum(g>25 for g in gaps),
            sink_gaps_over_40ms=sum(g>40 for g in gaps),
            appsrc_queue=int(source.get_property('current-level-buffers')),
            pipeline_queue=int(self.queue.get_property('current-level-buffers')))
        frames=[record for record in list(self.source_frames) if now-record[0]<=5]
        repeated=0
        skipped=[0,0]
        for a,b in zip(frames,frames[1:]):
            if a[2]==b[2] and b[2] in (0,1):
                delta=(b[1]-a[1])&0xffffffff
                repeated += delta==0
                if 0<delta<0x80000000:
                    skipped[b[2]] += delta-1
        result.update(sink_repeated_source_ids_5s=repeated,sink_source_gaps_5s=skipped,
            last_sink_frame_id=frames[-1][1] if frames else None,
            last_sink_camera=frames[-1][2] if frames else None)
        ages = sorted(record[3] for record in records if now-record[0]<=5 and record[3]>=0)
        result.update(submit_to_sink_ms_p50=ages[len(ages)//2] if ages else None,
            submit_to_sink_ms_p95=ages[int((len(ages)-1)*.95)] if ages else None,
            submit_to_sink_ms_max=max(ages) if ages else None,
            present_queue=int(self.present_queue.get_property('current-level-buffers')) if self.present_queue else 0,
            present_queue_capacity=int(self.present_queue.get_property('max-size-buffers')) if self.present_queue else 0)
        converter = self.sink.get_parent().get_by_name('display_convert')
        if converter.find_property('processing-us'):
            frames = int(converter.get_property('frames'))
            result.update(convert_osd_avg_ms=converter.get_property('processing-us')/max(1,frames)/1000,
                convert_frames=frames,convert_osd_total_us=int(converter.get_property('processing-us')),
                convert_osd_max_ms=converter.get_property('max-processing-us')/1000,
                osd=converter.get_property('osd'),osd_text=converter.get_property('text'))
        return result

    def request_snapshot(self, directory):
        """Copy a sink sample only on explicit request, outside video workers."""
        if self.capturing:
            return
        self.capturing = True
        def capture():
            try:
                sample = self.sink.get_property('last-sample')
                if sample is None:
                    raise RuntimeError('No HDMI sink sample')
                caps = sample.get_caps().get_structure(0)
                buf = sample.get_buffer()
                pixels = buf.extract_dup(0,buf.get_size())
                metadata = dict(width=caps.get_value('width'),height=caps.get_value('height'),
                    format=caps.get_value('format'),bytes=len(pixels),sample_s=time.monotonic(),
                    source='kmssink last-sample, not physical HDMI capture')
                (directory/'hdmi_snapshot.nv12').write_bytes(pixels)
                (directory/'hdmi_snapshot.json').write_text(json.dumps(metadata,indent=2))
            except Exception as exc:
                (directory/'hdmi_snapshot.error').write_text(str(exc))
            finally:
                self.capturing = False
        threading.Thread(target=capture,name='requested-display-snapshot',daemon=True).start()
