"""Read bounded native display measurements outside the streaming callback."""
import ctypes
from pathlib import Path


class Sample(ctypes.Structure):
    _fields_ = [('time_us', ctypes.c_int64), ('frame_id', ctypes.c_uint64),
                ('camera', ctypes.c_uint64), ('queue_age_us', ctypes.c_int64)]


class NativeDisplayProbe:
    def __init__(self, sink, queue, present):
        library = Path(__file__).with_name('libdisplay_probe.so')
        self.library = ctypes.CDLL(str(library))
        new = self.library.rk_display_probe_new
        new.argtypes = [ctypes.c_void_p]*3
        new.restype = ctypes.c_void_p
        self.read = self.library.rk_display_probe_read
        self.read.argtypes = [ctypes.c_void_p, ctypes.POINTER(Sample), ctypes.c_uint,
                              ctypes.POINTER(ctypes.c_uint64)]
        self.read.restype = ctypes.c_uint
        self.free = self.library.rk_display_probe_free
        self.free.argtypes = [ctypes.c_void_p]
        self.free.restype = None
        pointer = ctypes.pythonapi.PyCapsule_GetPointer
        pointer.argtypes = [ctypes.py_object, ctypes.c_char_p]
        pointer.restype = ctypes.c_void_p
        self.handle = new(*(pointer(element.__gpointer__, None) if element else None
                            for element in (sink, queue, present)))
        if not self.handle:
            raise RuntimeError('Could not attach native display probe')
        self.samples = (Sample*1024)()
        self.totals = (ctypes.c_uint64*3)()

    def snapshot(self):
        if not self.handle:
            raise RuntimeError('Display probe is closed')
        count = self.read(self.handle, self.samples, len(self.samples), self.totals)
        return ([(s.time_us/1e6, s.frame_id, s.camera, s.queue_age_us/1000) for s in self.samples[:count]],
                list(self.totals))

    def close(self):
        if self.handle:
            self.free(self.handle)
            self.handle = None
