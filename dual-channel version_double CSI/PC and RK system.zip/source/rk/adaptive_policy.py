"""Dark-area based inference allocation and shared JPEG quality control."""
import math
from preprocess_tree import TREE


def predict_preprocess(features):
    """Return an FPGA mode and estimated utility gain using the frozen tree."""
    ranges = ((0, 255), (0, 1), (0, 1), (0, 240), (0, 255))
    values = [features.get(name) for name in TREE['features']]
    if not all(type(x) in (int, float) and math.isfinite(x) and low <= x <= high
               for x, (low, high) in zip(values, ranges)):
        return None
    node = 0
    while TREE['left'][node] != -1:
        node = (TREE['left'][node] if values[TREE['feature'][node]] <= TREE['threshold'][node]
                else TREE['right'][node])
    gains = TREE['value'][node]
    index = max(range(len(gains)), key=lambda i: gains[i])
    gain = float(gains[index])
    return dict(mode=TREE['mode_ids'][index+1] if gain > TREE['gain_floor'] else 0,
                gain=gain, leaf=node, model=TREE['version'])


class PreprocessController:
    """Debounce automatic selection and restore the last manual mode on exit."""
    def __init__(self):
        self.base = self.applied = None
        self.manual_override = False
        self.candidate = self.candidate_since = self.candidate_identity = None
        self.last_change = None

    def manual_change(self):
        self.base = self.applied = None
        self.manual_override = True
        self.candidate = self.candidate_since = self.candidate_identity = None

    def update(self, current, state, prediction, supported, enabled, now):
        if type(current) is not int or not 0 <= current <= 5:
            return None
        if self.applied is not None and current != self.applied:
            self.manual_change()
        valid = (enabled and state.get('identity') is not None and prediction is not None and
                 type(supported) is int and supported & (1 << prediction['mode']))
        if not valid:
            self.candidate = self.candidate_since = self.candidate_identity = None
            if not enabled:
                self.manual_override = False
            if self.applied is not None:
                target = self.base
                self.base = self.applied = None
                self.last_change = now
                return target if target != current and type(supported) is int and supported & (1 << target) else None
            return None
        if self.manual_override:
            return None
        target = prediction['mode']
        if target != self.candidate:
            self.candidate, self.candidate_since = target, now
            self.candidate_identity = state['identity']
        if target == current:
            return None
        if (state['identity'] == self.candidate_identity or now-self.candidate_since < .5 or
                (self.last_change is not None and now-self.last_change < .5)):
            return None
        if self.base is None:
            self.base = current
        self.applied = target
        self.last_change = now
        return target


class AdaptivePolicy:
    def __init__(self):
        self.states = [dict(identity=None, changed_at=None) for _ in range(2)]

    def update(self, observations, now, enabled, sample_age=0):
        output = []
        for camera, name in enumerate(('camera_a', 'camera_b')):
            state = self.states[camera]
            obs = (observations or {}).get(name) or {}
            features = obs.get('features') or {}
            keys = ('mean', 'dark_fraction', 'bright_fraction')
            valid = (enabled and 0 <= sample_age <= 3 and obs.get('valid') is True and
                     obs.get('camera') == camera and obs.get('samples') == 129600 and
                     all(type(features.get(k)) in (int, float) and math.isfinite(features[k]) for k in keys) and
                     0 <= features['mean'] <= 255 and
                     0 <= features['dark_fraction'] <= 1 and 0 <= features['bright_fraction'] <= 1 and
                     all(type(obs.get(k)) is int for k in ('epoch', 'sequence', 'frame_id')))
            if valid:
                identity = (obs['epoch'], obs['sequence'], obs['frame_id'])
                if identity != state['identity']:
                    state.update(identity=identity, changed_at=now)
                valid = state['changed_at'] is not None and now-state['changed_at'] <= 3
            if not valid:
                state.update(identity=None, changed_at=None)
            dark = features['dark_fraction'] if valid else None
            restricted = valid and dark > .90
            output.append(dict(state=('dark' if restricted else 'normal') if valid else ('waiting' if enabled else 'off'),
                               dark_fraction=dark, identity=state['identity'] if valid else None,
                               yolo_limit_fps=5 if restricted else None))
        return dict(enabled=bool(enabled), cameras=output, qf_control='shared')


class SharedQfController:
    """Select QF using the less-dark camera; manual settings always win."""
    def __init__(self):
        self.base = self.applied = None
        self.manual_override = False
        self.candidate = self.candidate_since = self.candidate_identity = None
        self.candidate_fresh = False
        self.last_change = None

    def manual_change(self):
        self.base = self.applied = None
        self.manual_override = True

    def update(self, current, states, enabled, now):
        if type(current) is not int or not 1 <= current <= 100:
            return None
        valid = (enabled and len(states) in (1, 2) and
                 all(type(s.get('dark_fraction')) in (int, float) and
                     math.isfinite(s['dark_fraction']) and 0 <= s['dark_fraction'] <= 1 and
                     s.get('identity') is not None for s in states))
        if self.applied is not None and current != self.applied:
            self.manual_change()
        dark = min(s['dark_fraction'] for s in states) if valid else 0
        if not valid or dark <= .50:
            self.manual_override = False
            self.candidate = self.candidate_since = self.candidate_identity = None
            self.candidate_fresh = False
            if self.applied is not None:
                target = self.base
                self.base = self.applied = None
                self.last_change = now
                return target if target != current else None
            return None
        if self.manual_override:
            return None
        if dark == 1:
            cap = 1
        elif dark >= .90:
            cap = 30
        elif dark >= .80:
            cap = 40
        elif dark >= .70:
            cap = 50
        else:
            cap = 65
        base = self.base if self.base is not None else current
        target = cap
        identities = tuple(s['identity'] for s in states)
        if target != self.candidate:
            self.candidate, self.candidate_since = target, now
            self.candidate_identity, self.candidate_fresh = identities, False
        elif all(a != b for a, b in zip(identities, self.candidate_identity)):
            self.candidate_fresh = True
        if target == current:
            return None
        delay = 1 if cap == 1 else .5
        if not self.candidate_fresh or now-self.candidate_since < delay:
            return None
        if cap != 1 and self.last_change is not None and now-self.last_change < .5:
            return None
        if target == base:
            self.base = self.applied = None
        else:
            self.base, self.applied = base, target
        self.last_change = now
        return target
