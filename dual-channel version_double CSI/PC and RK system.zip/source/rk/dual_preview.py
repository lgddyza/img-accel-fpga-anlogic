"""Two bounded MJPEG streams; consumers never own the DMA or display queues."""
import hmac
import base64
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import secrets
import threading
import time
from urllib.parse import parse_qs, urlsplit

from display_push import FramePusher


WIDTH, HEIGHT, FPS = 640, 360, 30
SIZES = {'360': (640, 360), '540': (960, 540), '720': (1280, 720)}
SAMPLE_EVERY = 2


class DualPreview:
    def __init__(self, Gst, port):
        self.Gst = Gst
        self.token = secrets.token_urlsafe(32)
        self.condition = threading.Condition()
        self.clients = [0, 0]
        self.sizes = [(WIDTH, HEIGHT), (WIDTH, HEIGHT)]
        self.raw = [None, None]
        self.latest = [None, None]
        self.sequence = [0, 0]
        self.offered = [0, 0]
        self.replaced = [0, 0]
        self.encode_us = [0, 0]
        self.max_encode_us = [0, 0]
        self.running = True
        self.error = None
        self.encoders = []
        self.metadata = [{}, {}]
        self.yolo = None
        owner = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = 'HTTP/1.1'

            def log_message(self, *_):
                pass

            def do_GET(self):
                url = urlsplit(self.path)
                params = parse_qs(url.query, keep_blank_values=True)
                if url.path not in ('/stream/0', '/stream/1') or not hmac.compare_digest(
                        self.headers.get('Authorization', ''), 'Bearer '+owner.token):
                    self.send_error(403)
                    return
                if set(params) - {'size'} or len(params.get('size', ['360'])) != 1 or params.get('size', ['360'])[0] not in SIZES:
                    self.send_error(400)
                    return
                size = SIZES[params.get('size', ['360'])[0]]
                camera = int(url.path[-1])
                self.connection.settimeout(3)
                with owner.condition:
                    if owner.error or owner.clients[camera] >= 2:
                        self.send_error(503)
                        return
                    if owner.sizes[camera] != size:
                        owner.sizes[camera] = size
                        owner.latest[camera] = None
                        owner.condition.notify_all()
                    owner.clients[camera] += 1
                try:
                    self.send_response(200)
                    self.send_header('Content-Type', 'multipart/x-mixed-replace; boundary=rkframe')
                    self.send_header('Cache-Control', 'no-store')
                    self.send_header('Connection', 'close')
                    self.end_headers()
                    sequence = owner.sequence[camera]
                    while owner.running:
                        with owner.condition:
                            changed = owner.condition.wait_for(lambda: not owner.running or
                                owner.sequence[camera] != sequence, timeout=1)
                            sequence = owner.sequence[camera]
                            packet = owner.latest[camera] if changed else None
                        if packet is None:
                            self.wfile.write(b'\r\n')
                        else:
                            stamp, frame_id, mode, jpeg = packet
                            ai = owner.yolo.snapshot() if owner.yolo else None
                            result = ai['results'][camera] if ai and ai['enabled'][camera] else None
                            gap = (frame_id-result['frame_id']) & 0x0fffffff if result else 0x0fffffff
                            boxes = result['boxes'][:64] if result and result['mode'] == mode and result['age_ms'] <= 250 and gap <= 12 else []
                            encoded = base64.b64encode(json.dumps(boxes, separators=(',', ':')).encode()).decode()
                            header = (f'--rkframe\r\nContent-Type: image/jpeg\r\n'
                                f'Content-Length: {len(jpeg)}\r\nX-Sequence: {sequence}\r\n'
                                f'X-RK-Time: {stamp:.6f}\r\nX-Camera: {camera}\r\n'
                                f'X-Source-Frame: {frame_id}\r\nX-Yolo: {encoded}\r\n\r\n')
                            self.wfile.write(header.encode()+jpeg+b'\r\n')
                        self.wfile.flush()
                except (OSError, ValueError):
                    pass
                finally:
                    with owner.condition:
                        owner.clients[camera] -= 1
                        if not owner.clients[camera]:
                            owner.latest[camera] = owner.raw[camera] = None

        self.server = ThreadingHTTPServer(('0.0.0.0', port), Handler)
        self.server.daemon_threads = True
        try:
            for camera in (0, 1):
                pipeline = Gst.parse_launch(
                    'appsrc name=input is-live=true format=time block=false '
                    'max-buffers=1 max-bytes=0 leaky-type=downstream '
                    f'caps=video/x-raw,format=GRAY8,width=1920,height=1080,framerate={FPS}/1 '
                    '! queue max-size-buffers=1 max-size-bytes=0 max-size-time=0 leaky=downstream '
                    f'! videoscale method=0 ! capsfilter name=preview_size caps="video/x-raw,width={WIDTH},height={HEIGHT}" '
                    '! jpegenc quality=70 ! appsink name=output sync=false async=false '
                    'max-buffers=1 drop=true enable-last-sample=false')
                self.encoders.append(pipeline)
                if pipeline.set_state(Gst.State.PLAYING) == Gst.StateChangeReturn.FAILURE:
                    raise RuntimeError('Preview encoder failed to start')
            self.threads = [threading.Thread(target=self.server.serve_forever, daemon=True)]
            self.threads += [threading.Thread(target=self.encode, args=(i,), daemon=True) for i in (0, 1)]
            for thread in self.threads:
                thread.start()
        except Exception:
            self.server.server_close()
            for pipeline in self.encoders:
                pipeline.set_state(Gst.State.NULL)
            raise

    def offer(self, camera, pixels, frame_id, mode):
        self.offered[camera] += 1
        if not self.clients[camera] or self.offered[camera] % SAMPLE_EVERY:
            return
        with self.condition:
            if self.raw[camera] is not None:
                self.replaced[camera] += 1
            self.raw[camera] = (pixels, frame_id, mode, time.monotonic())
            self.condition.notify_all()

    def encode(self, camera):
        Gst = self.Gst
        pipeline = self.encoders[camera]
        source, sink = pipeline.get_by_name('input'), pipeline.get_by_name('output')
        pusher = FramePusher(source)
        current_size = (WIDTH, HEIGHT)
        capsfilter = pipeline.get_by_name('preview_size')
        try:
            while self.running:
                with self.condition:
                    self.condition.wait_for(lambda: self.raw[camera] is not None or not self.running, timeout=.2)
                    raw = self.raw[camera]
                    self.raw[camera] = None
                    target_size = self.sizes[camera]
                if target_size != current_size:
                    capsfilter.set_property('caps', Gst.Caps.from_string(
                        f'video/x-raw,width={target_size[0]},height={target_size[1]}'))
                    current_size = target_size
                if raw is not None:
                    pixels, frame_id, mode, stamp = raw
                    pts = round(stamp*1e9)
                    self.metadata[camera][pts] = (stamp, frame_id, mode)
                    while len(self.metadata[camera]) > 4:
                        self.metadata[camera].pop(next(iter(self.metadata[camera])))
                    if pusher.push_timed(pixels, frame_id, camera, pts, round(1e9/FPS)) != Gst.FlowReturn.OK:
                        raise RuntimeError('Preview input rejected')
                sample = sink.emit('try-pull-sample', 20_000_000)
                if sample is not None:
                    buffer = sample.get_buffer()
                    metadata = self.metadata[camera].pop(buffer.pts, None)
                    structure = sample.get_caps().get_structure(0)
                    sample_size = (structure.get_value('width'), structure.get_value('height'))
                    if metadata is not None and self.clients[camera] and sample_size == self.sizes[camera]:
                        jpeg = buffer.extract_dup(0, buffer.get_size())
                        elapsed_us = round((time.monotonic()-metadata[0])*1e6)
                        with self.condition:
                            self.encode_us[camera] += elapsed_us
                            self.max_encode_us[camera] = max(self.max_encode_us[camera], elapsed_us)
                            self.latest[camera] = (*metadata, jpeg)
                            self.sequence[camera] += 1
                            self.condition.notify_all()
                message = pipeline.get_bus().pop_filtered(Gst.MessageType.ERROR)
                if message:
                    raise RuntimeError(str(message.parse_error()[0]))
        except Exception as exc:
            self.error = str(exc)

    def status(self, include_token=False):
        value = dict(port=self.server.server_port, clients=self.clients[:], frames=self.sequence[:],
            fps_limit=FPS, width=WIDTH, height=HEIGHT, source='strict_decoded_gray', error=self.error,
            sizes=self.sizes[:],
            replaced=self.replaced[:], encode_us=self.encode_us[:], max_encode_us=self.max_encode_us[:])
        if include_token:
            value['token'] = self.token
        return value

    def close(self):
        self.running = False
        with self.condition:
            self.condition.notify_all()
        self.server.shutdown()
        self.server.server_close()
        for thread in self.threads[1:]:
            thread.join(timeout=2)
        for pipeline in self.encoders:
            pipeline.set_state(self.Gst.State.NULL)
