/* Fixed-format GRAY8 -> limited-range NV12, with a bounded status panel. */
#include <gst/video/gstvideofilter.h>
#include <gst/app/gstappsrc.h>
#include <string.h>
#include <stdio.h>
#include <arm_neon.h>
#define PACKAGE "rkdualdisplay"

/* ctypes calls avoid GI's per-byte array marshalling for every 1080p frame. */
int rkdual_push_gray(void *source,const unsigned char *pixels,gsize length,
                     guint64 frame_id,guint64 camera) {
    if(length!=1920u*1080u || camera>1) return GST_FLOW_ERROR;
    GstBuffer *buffer=gst_buffer_new_allocate(NULL,length,NULL);
    if(!buffer) return GST_FLOW_ERROR;
    if(gst_buffer_fill(buffer,0,pixels,length)!=length) {
        gst_buffer_unref(buffer);return GST_FLOW_ERROR;
    }
    GST_BUFFER_OFFSET(buffer)=frame_id;
    GST_BUFFER_OFFSET_END(buffer)=camera;
    return gst_app_src_push_buffer(GST_APP_SRC(source),buffer);
}

int rkdual_push_gray_timed(void *source,const unsigned char *pixels,gsize length,
                          guint64 frame_id,guint64 camera,guint64 pts,guint64 duration) {
    if(length!=1920u*1080u || camera>1) return GST_FLOW_ERROR;
    GstBuffer *buffer=gst_buffer_new_allocate(NULL,length,NULL);
    if(!buffer) return GST_FLOW_ERROR;
    if(gst_buffer_fill(buffer,0,pixels,length)!=length) {
        gst_buffer_unref(buffer);return GST_FLOW_ERROR;
    }
    GST_BUFFER_OFFSET(buffer)=frame_id;
    GST_BUFFER_OFFSET_END(buffer)=camera;
    GST_BUFFER_PTS(buffer)=pts;
    GST_BUFFER_DURATION(buffer)=duration;
    return gst_app_src_push_buffer(GST_APP_SRC(source),buffer);
}

typedef struct {
    GstVideoFilter parent;
    gchar *text;
    gchar *boxes;
    gboolean osd;
    guint64 frames;
    guint64 processing_us;
    guint max_processing_us;
} GstDualGray;
typedef struct { GstVideoFilterClass parent; } GstDualGrayClass;
G_DEFINE_TYPE(GstDualGray, gst_dual_gray, GST_TYPE_VIDEO_FILTER)
enum { PROP_0, PROP_TEXT, PROP_OSD, PROP_FRAMES, PROP_PROCESSING_US, PROP_MAX_US, PROP_BOXES };

static GstStaticPadTemplate sink_template = GST_STATIC_PAD_TEMPLATE("sink", GST_PAD_SINK,
    GST_PAD_ALWAYS, GST_STATIC_CAPS("video/x-raw,format=GRAY8,width=[16,8192],height=[16,8192]"));
static GstStaticPadTemplate src_template = GST_STATIC_PAD_TEMPLATE("src", GST_PAD_SRC,
    GST_PAD_ALWAYS, GST_STATIC_CAPS("video/x-raw,format=NV12,width=[16,8192],height=[16,8192]"));

/* Five by seven uppercase bitmap font; cached text is drawn without font shaping. */
static const guint8 digits[10][7] = {
    {14,17,19,21,25,17,14},{4,12,4,4,4,4,14},{14,17,1,2,4,8,31},
    {30,1,1,14,1,1,30},{2,6,10,18,31,2,2},{31,16,16,30,1,1,30},
    {14,16,16,30,17,17,14},{31,1,2,4,8,8,8},{14,17,17,14,17,17,14},
    {14,17,17,15,1,1,14}};
static const guint8 letters[26][7] = {
    {14,17,17,31,17,17,17},{30,17,17,30,17,17,30},{14,17,16,16,16,17,14},
    {30,17,17,17,17,17,30},{31,16,16,30,16,16,31},{31,16,16,30,16,16,16},
    {14,17,16,23,17,17,15},{17,17,17,31,17,17,17},{31,4,4,4,4,4,31},
    {7,2,2,2,18,18,12},{17,18,20,24,20,18,17},{16,16,16,16,16,16,31},
    {17,27,21,21,17,17,17},{17,25,21,19,17,17,17},{14,17,17,17,17,17,14},
    {30,17,17,30,16,16,16},{14,17,17,17,21,18,13},{30,17,17,30,20,18,17},
    {15,16,16,14,1,1,30},{31,4,4,4,4,4,4},{17,17,17,17,17,17,14},
    {17,17,17,17,17,10,4},{17,17,17,21,21,21,10},{17,17,10,4,10,17,17},
    {17,17,10,4,4,4,4},{31,1,2,4,8,16,31}};
static guint8 glyph(char c, int row) {
    if(c>='0' && c<='9') return digits[c-'0'][row];
    if(c>='A' && c<='Z') return letters[c-'A'][row];
    if(c=='x') return letters['X'-'A'][row];
    if(c==':') return row==2 || row==5 ? 4:0;
    if(c=='.') return row==6 ? 4:0;
    if(c=='-') return row==3 ? 14:0;
    if(c=='/') return 1u<<(row*4/7);
    return 0;
}

static void draw_panel(guint8 *data, int stride, int width, int height, const char *text) {
    const int scale=3, left=24, top=24, row_height=32;
    int columns=0, longest=0, lines=1;
    for(const char *p=text;*p;p++) {
        if(*p=='\n') { longest=MAX(longest,columns);columns=0;lines++; }
        else columns++;
    }
    longest=MAX(longest,columns);
    int right=MIN(width,left+longest*6*scale+20);
    int bottom=MIN(height,top+lines*row_height+12);
    /* Forty percent translucent black, limited to the small text rectangle. */
    for(int y=top;y<bottom;y++) for(int x=left;x<right;x++) {
        guint8 *p=data+y*stride+x;
        *p=16+((*p-16)*3)/5;
    }
    int x=left+10,y=top+8;
    for(const char *p=text;*p;p++) {
        if(*p=='\n') {x=left+10;y+=row_height;continue;}
        for(int gy=0;gy<7;gy++) for(int gx=0;gx<5;gx++)
            if(glyph(*p,gy)&(1u<<(4-gx)))
                for(int sy=0;sy<scale;sy++) for(int sx=0;sx<scale;sx++)
                    if(x+gx*scale+sx<width && y+gy*scale+sy<height)
                        data[(y+gy*scale+sy)*stride+x+gx*scale+sx]=235;
        x+=6*scale;
    }
}

static void draw_boxes(guint8 *data,int stride,int width,int height,const char *boxes) {
    static const char *labels[]={"ALLIGATOR CRACK","LONGITUDINAL CRACK","OBLIQUE CRACK",
                                 "POTHOLE","REPAIR","TRANSVERSE CRACK"};
    if(!boxes) return;
    gchar **items=g_strsplit(boxes,";",65);
    for(int i=0;items[i] && i<64;i++) {
        int x1,y1,x2,y2,cls,score;
        if(sscanf(items[i],"%d,%d,%d,%d,%d,%d",&x1,&y1,&x2,&y2,&cls,&score)!=6)continue;
        x1=CLAMP(x1,0,width-1);x2=CLAMP(x2,0,width-1);
        y1=CLAMP(y1,0,height-1);y2=CLAMP(y2,0,height-1);
        if(x2<=x1 || y2<=y1)continue;
        for(int y=y1;y<=y2;y++) {
            if(y-y1<3 || y2-y<3) memset(data+y*stride+x1,235,x2-x1+1);
            else {
                memset(data+y*stride+x1,235,MIN(3,x2-x1+1));
                memset(data+y*stride+MAX(x1,x2-2),235,MIN(3,x2-x1+1));
            }
        }
        char title[80];g_snprintf(title,sizeof(title),"%s %d.%02d",cls>=0&&cls<6?labels[cls]:"UNKNOWN",score/100,score%100);
        int yy=MAX(0,y1-19),xx=x1;
        for(const char *p=title;*p && xx+10<width;p++,xx+=12)
            for(int gy=0;gy<7;gy++) for(int gx=0;gx<5;gx++) if(glyph(*p,gy)&(1u<<(4-gx)))
                for(int sy=0;sy<2;sy++)for(int sx=0;sx<2;sx++)
                    if(yy+gy*2+sy<height)data[(yy+gy*2+sy)*stride+xx+gx*2+sx]=235;
    }
    g_strfreev(items);
}

static GstCaps *transform_caps(GstBaseTransform *base, GstPadDirection direction,
                              GstCaps *caps, GstCaps *filter) {
    (void)base;
    GstCaps *result=gst_caps_copy(caps);
    for(guint i=0;i<gst_caps_get_size(result);i++) {
        GstStructure *s=gst_caps_get_structure(result,i);
        gst_structure_set(s,"format",G_TYPE_STRING,direction==GST_PAD_SINK?"NV12":"GRAY8",NULL);
        gst_structure_remove_fields(s,"colorimetry","chroma-site",NULL);
    }
    if(filter) {
        GstCaps *intersection=gst_caps_intersect_full(filter,result,GST_CAPS_INTERSECT_FIRST);
        gst_caps_unref(result);result=intersection;
    }
    return result;
}

static GstFlowReturn transform_frame(GstVideoFilter *filter, GstVideoFrame *in, GstVideoFrame *out) {
    GstDualGray *self=(GstDualGray *)filter;
    gint64 began=g_get_monotonic_time();
    int width=GST_VIDEO_FRAME_WIDTH(in), height=GST_VIDEO_FRAME_HEIGHT(in);
    guint8 *dest=GST_VIDEO_FRAME_PLANE_DATA(out,0);
    const guint8 *src=GST_VIDEO_FRAME_PLANE_DATA(in,0);
    int ds=GST_VIDEO_FRAME_PLANE_STRIDE(out,0), ss=GST_VIDEO_FRAME_PLANE_STRIDE(in,0);
    for(int y=0;y<height;y++) {
        int x=0;
        for(;x+16<=width;x+=16) {
            uint8x16_t v=vld1q_u8(src+y*ss+x);
            uint16x8_t a=vmull_u8(vget_low_u8(v),vdup_n_u8(219));
            uint16x8_t b=vmull_u8(vget_high_u8(v),vdup_n_u8(219));
            /* Rounded divide by 255: (n+128 + ((n+128)>>8))>>8. */
            a=vaddq_u16(a,vdupq_n_u16(128));b=vaddq_u16(b,vdupq_n_u16(128));
            a=vaddq_u16(a,vshrq_n_u16(a,8));b=vaddq_u16(b,vshrq_n_u16(b,8));
            uint8x16_t mapped=vcombine_u8(vshrn_n_u16(a,8),vshrn_n_u16(b,8));
            vst1q_u8(dest+y*ds+x,vaddq_u8(mapped,vdupq_n_u8(16)));
        }
        for(;x<width;x++) dest[y*ds+x]=16+(src[y*ss+x]*219+127)/255;
    }
    guint8 *uv=GST_VIDEO_FRAME_PLANE_DATA(out,1);
    int us=GST_VIDEO_FRAME_PLANE_STRIDE(out,1);
    for(int y=0;y<(height+1)/2;y++) memset(uv+y*us,128,us);
    GST_OBJECT_LOCK(self);
    if(self->boxes && *self->boxes) draw_boxes(dest,ds,width,height,self->boxes);
    if(self->osd && self->text && *self->text) draw_panel(dest,ds,width,height,self->text);
    guint elapsed=(guint)(g_get_monotonic_time()-began);
    self->frames++;self->processing_us+=elapsed;self->max_processing_us=MAX(self->max_processing_us,elapsed);
    GST_OBJECT_UNLOCK(self);
    return GST_FLOW_OK;
}

static void set_property(GObject *obj,guint id,const GValue *value,GParamSpec *spec) {
    GstDualGray *self=(GstDualGray *)obj;
    GST_OBJECT_LOCK(self);
    switch(id) {
    case PROP_TEXT: g_free(self->text);self->text=g_value_dup_string(value);break;
    case PROP_OSD: self->osd=g_value_get_boolean(value);break;
    case PROP_BOXES: g_free(self->boxes);self->boxes=g_value_dup_string(value);break;
    default: G_OBJECT_WARN_INVALID_PROPERTY_ID(obj,id,spec);break;
    }
    GST_OBJECT_UNLOCK(self);
}
static void get_property(GObject *obj,guint id,GValue *value,GParamSpec *spec) {
    GstDualGray *self=(GstDualGray *)obj;
    GST_OBJECT_LOCK(self);
    switch(id) {
    case PROP_TEXT:g_value_set_string(value,self->text);break;
    case PROP_OSD:g_value_set_boolean(value,self->osd);break;
    case PROP_BOXES:g_value_set_string(value,self->boxes);break;
    case PROP_FRAMES:g_value_set_uint64(value,self->frames);break;
    case PROP_PROCESSING_US:g_value_set_uint64(value,self->processing_us);break;
    case PROP_MAX_US:g_value_set_uint(value,self->max_processing_us);break;
    default:G_OBJECT_WARN_INVALID_PROPERTY_ID(obj,id,spec);break;
    }
    GST_OBJECT_UNLOCK(self);
}
static void finalize(GObject *obj) {
    g_free(((GstDualGray *)obj)->text);
    g_free(((GstDualGray *)obj)->boxes);
    G_OBJECT_CLASS(gst_dual_gray_parent_class)->finalize(obj);
}
static void gst_dual_gray_class_init(GstDualGrayClass *klass) {
    GObjectClass *object=G_OBJECT_CLASS(klass);
    GstElementClass *element=GST_ELEMENT_CLASS(klass);
    GstBaseTransformClass *base=GST_BASE_TRANSFORM_CLASS(klass);
    GstVideoFilterClass *video=GST_VIDEO_FILTER_CLASS(klass);
    object->set_property=set_property;object->get_property=get_property;object->finalize=finalize;
    g_object_class_install_property(object,PROP_TEXT,g_param_spec_string("text","Text","ASCII multiline OSD", "",G_PARAM_READWRITE));
    g_object_class_install_property(object,PROP_OSD,g_param_spec_boolean("osd","OSD","Show status panel",TRUE,G_PARAM_READWRITE));
    g_object_class_install_property(object,PROP_BOXES,g_param_spec_string("boxes","Boxes","Bounded YOLO boxes", "",G_PARAM_READWRITE));
    g_object_class_install_property(object,PROP_FRAMES,g_param_spec_uint64("frames","Frames","Processed frames",0,G_MAXUINT64,0,G_PARAM_READABLE));
    g_object_class_install_property(object,PROP_PROCESSING_US,g_param_spec_uint64("processing-us","Processing time","Total conversion and OSD microseconds",0,G_MAXUINT64,0,G_PARAM_READABLE));
    g_object_class_install_property(object,PROP_MAX_US,g_param_spec_uint("max-processing-us","Maximum time","Maximum microseconds per frame",0,G_MAXUINT,0,G_PARAM_READABLE));
    gst_element_class_set_static_metadata(element,"Dual gray display","Filter/Converter/Video","GRAY8 to NV12 and bounded OSD","Codex");
    gst_element_class_add_static_pad_template(element,&sink_template);
    gst_element_class_add_static_pad_template(element,&src_template);
    base->transform_caps=transform_caps;
    video->transform_frame=transform_frame;
}
static void gst_dual_gray_init(GstDualGray *self) { self->osd=TRUE;self->text=g_strdup("");self->boxes=g_strdup(""); }
static gboolean plugin_init(GstPlugin *plugin) {
    return gst_element_register(plugin,"rkdualgray",GST_RANK_NONE,gst_dual_gray_get_type());
}
GST_PLUGIN_DEFINE(GST_VERSION_MAJOR,GST_VERSION_MINOR,rkdualdisplay,"Dual gray display",plugin_init,"1.0","LGPL",PACKAGE,"local")
