/* Strict JPEG decoders write each 8-row stripe directly to the raster. */
#include <stddef.h>
#include <stdio.h>
#include <jpeglib.h>
#include <setjmp.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    struct jpeg_error_mgr base;
    jmp_buf jump;
    char message[JMSG_LENGTH_MAX];
} StripeError;

typedef struct {
    struct jpeg_decompress_struct decoder;
    StripeError error;
} StripeDecoder;

typedef struct {
    StripeDecoder tile[3];
} StripeContext;

static void failed(j_common_ptr common) {
    StripeError *error = (StripeError *)common->err;
    (*common->err->format_message)(common, error->message);
    longjmp(error->jump, 1);
}

static void emitted(j_common_ptr common, int level) {
    StripeError *error = (StripeError *)common->err;
    if (level < 0) {
        if (!error->base.num_warnings)
            (*common->err->format_message)(common, error->message);
        error->base.num_warnings++;
    }
}

void jpeg_stripes_destroy(void *opaque) {
    StripeContext *context = opaque;
    int tile;
    if (!context) return;
    for (tile = 0; tile < 3; tile++)
        if (context->tile[tile].decoder.mem)
            jpeg_destroy_decompress(&context->tile[tile].decoder);
    free(context);
}

void *jpeg_stripes_create(void) {
    StripeContext *context = calloc(1, sizeof(*context));
    int tile;
    if (!context) return NULL;
    for (tile = 0; tile < 3; tile++) {
        StripeDecoder *state = &context->tile[tile];
        state->decoder.err = jpeg_std_error(&state->error.base);
        state->error.base.error_exit = failed;
        state->error.base.emit_message = emitted;
    }
    return context;
}

static int decode_tile(StripeDecoder *state, const unsigned char *data,
                       size_t size, unsigned char *raster, int tile,
                       char *message, size_t message_size) {
    struct jpeg_decompress_struct *decoder = &state->decoder;
    state->error.base.num_warnings = 0;
    state->error.message[0] = 0;
    if (setjmp(state->error.jump)) {
        snprintf(message, message_size, "tile=%d %s", tile, state->error.message);
        jpeg_abort_decompress(decoder);
        return -1;
    }
    /* A frame must carry its own tables, exactly as with the original decoder. */
    if (decoder->mem) jpeg_destroy_decompress(decoder);
    jpeg_create_decompress(decoder);
    jpeg_mem_src(decoder, data, size);
    jpeg_read_header(decoder, TRUE);
    if (decoder->image_width != 1920 || decoder->image_height != 360) {
        snprintf(message, message_size, "tile=%d unexpected JPEG dimensions %ux%u",
                 tile, decoder->image_width, decoder->image_height);
        jpeg_abort_decompress(decoder);
        return -1;
    }
    decoder->out_color_space = JCS_GRAYSCALE;
    decoder->dct_method = JDCT_IFAST;
    jpeg_start_decompress(decoder);
    if (decoder->output_width != 1920 || decoder->output_height != 360 ||
        decoder->output_components != 1) {
        snprintf(message, message_size, "tile=%d unexpected decoded layout", tile);
        jpeg_abort_decompress(decoder);
        return -1;
    }
    while (decoder->output_scanline < 360) {
        JSAMPROW rows[16];
        JDIMENSION first = decoder->output_scanline;
        JDIMENSION count = 360 - first, row;
        if (count > 16) count = 16;
        for (row = 0; row < count; row++) {
            size_t y = first + row;
            rows[row] = raster + ((y / 8) * 24 + tile * 8 + y % 8) * 1920;
        }
        if (!jpeg_read_scanlines(decoder, rows, count)) {
            snprintf(message, message_size, "tile=%d suspended scanline decode", tile);
            jpeg_abort_decompress(decoder);
            return -1;
        }
    }
    jpeg_finish_decompress(decoder);
    if (state->error.base.num_warnings) {
        snprintf(message, message_size, "tile=%d %s", tile, state->error.message);
        return -2;
    }
    return 0;
}

int jpeg_stripes_decode(void *opaque,
    const unsigned char *a, size_t na,
    const unsigned char *b, size_t nb,
    const unsigned char *c, size_t nc,
    unsigned char *raster, size_t capacity, char *message, size_t message_size) {
    StripeContext *context = opaque;
    const unsigned char *data[3] = {a, b, c};
    size_t sizes[3] = {na, nb, nc};
    int tile, result;
    if (message && message_size) message[0] = 0;
    if (!context || !raster || capacity < 1920 * 1080 || !message || !message_size)
        return -1;
    for (tile = 0; tile < 3; tile++) {
        result = decode_tile(&context->tile[tile], data[tile], sizes[tile],
                             raster, tile, message, message_size);
        if (result) return result;
    }
    return 0;
}
