/* Incremental JPEG marker scan; framing and recovery remain in Python. */
#include <stddef.h>
#include <stdint.h>
#include <string.h>

int jpeg_marker_scan(const uint8_t *data, size_t length, size_t *position,
                     int *entropy, size_t *packet_end) {
    size_t pos = *position;
    int scan = *entropy;
    while (pos < length) {
        size_t start = pos, marker, end;
        unsigned code, segment_length;
        if (scan) {
            const uint8_t *found = memchr(data + pos, 0xff, length - pos);
            if (!found) { pos = length; break; }
            start = (size_t)(found - data);
        } else if (data[start] != 0xff) {
            return -1;
        }
        marker = start + 1;
        while (marker < length && data[marker] == 0xff) marker++;
        if (marker == length) { pos = start; break; }
        code = data[marker];
        if (scan && (code == 0 || (code >= 0xd0 && code <= 0xd7))) {
            pos = marker + 1;
            continue;
        }
        if (code == 0xd9) {
            *position = pos;
            *entropy = scan;
            *packet_end = marker + 1;
            return 1;
        }
        if (code == 0 || code == 0xd8 || (code >= 0xd0 && code <= 0xd7)) return -2;
        if (code == 1) { pos = marker + 1; continue; }
        if (length - marker < 3) { pos = start; break; }
        segment_length = ((unsigned)data[marker+1] << 8) | data[marker+2];
        if (segment_length < 2) return -3;
        end = marker + 1 + segment_length;
        if (end > length) { pos = start; break; }
        pos = end;
        scan = code == 0xda;
    }
    *position = pos;
    *entropy = scan;
    return 0;
}
