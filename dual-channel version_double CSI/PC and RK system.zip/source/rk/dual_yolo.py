"""One bounded NPU worker per camera, with independent library contexts."""
import ctypes
import threading
import time
from collections import deque

LABELS = ('Alligator crack', 'Longitudinal crack', 'Oblique crack',
          'Pothole', 'Repair', 'Transverse crack')

class RoadBox(ctypes.Structure):
    _fields_ = [('cls',ctypes.c_int),('score',ctypes.c_float),
                ('x1',ctypes.c_float),('y1',ctypes.c_float),
                ('x2',ctypes.c_float),('y2',ctypes.c_float)]

class Detector:
    def __init__(self, model, library, core=None):
        self.lib=ctypes.CDLL(str(library))
        if core is None:
            self.init=self.lib.road_init
            self.init.argtypes=[ctypes.c_char_p]
        else:
            self.init=self.lib.road_init_core
            self.init.argtypes=[ctypes.c_char_p,ctypes.c_int]
        self.init.restype=ctypes.c_int
        self.lib.road_detect.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_int,
            ctypes.c_float,ctypes.POINTER(RoadBox),ctypes.c_int]
        self.lib.road_detect.restype=ctypes.c_int
        self.lib.road_error.restype=ctypes.c_char_p
        result=self.init(str(model).encode()) if core is None else self.init(str(model).encode(),core)
        if result:
            raise RuntimeError(self.lib.road_error().decode(errors='replace'))

    def run(self, frame, confidence):
        buf=ctypes.c_char_p(frame)
        boxes=(RoadBox*300)()
        n=self.lib.road_detect(ctypes.cast(buf,ctypes.c_void_p),1920,1080,confidence,boxes,300)
        if n<0: raise RuntimeError(self.lib.road_error().decode(errors='replace'))
        return [dict(cls=b.cls, label=LABELS[b.cls] if 0<=b.cls<len(LABELS) else str(b.cls),
                     confidence=float(b.score),x1=float(b.x1),y1=float(b.y1),
                     x2=float(b.x2),y2=float(b.y2)) for b in boxes[:n]]

    def close(self): self.lib.road_close()

class DualYolo:
    def __init__(self, detector_factory, confidence=0.10, detection_log=None):
        self.detectors=[None,None];self.detector_factory=detector_factory;self.confidence=confidence
        self.init_lock=threading.Lock();self.init_ready=threading.Event()
        self.cv=threading.Condition();self.pending=[None,None];self.enabled=[False,False]
        self.results=[None,None];self.completed=[0,0];self.replaced=[0,0]
        self.generation=[0,0]
        self.intervals=[0.0,0.0];self.next_offer=[0.0,0.0]
        self.history=[deque(),deque()];self.stopping=False;self.error=None;self.detection_log=detection_log
        self.threads=[threading.Thread(target=self._run,args=(i,),name='yolo-'+str(i),daemon=True) for i in range(2)]
        for thread in self.threads: thread.start()

    def configure(self, enabled, confidence):
        with self.cv:
            for i in range(2):
                if bool(enabled[i]) != self.enabled[i]: self.generation[i]+=1
            self.enabled=list(enabled);self.confidence=confidence
            for i in range(2):
                if not enabled[i]: self.pending[i]=self.results[i]=None
            self.cv.notify_all()

    def offer(self, camera, frame_id, frame, mode, quality=None, epoch=None):
        with self.cv:
            if not self.enabled[camera] or self.stopping or self.error: return
            if self.intervals[camera]:
                now=time.monotonic()
                if now < self.next_offer[camera]: return
                self.next_offer[camera]=now+self.intervals[camera]
            if self.pending[camera] is not None: self.replaced[camera]+=1
            self.pending[camera]=(frame_id,frame,mode,time.monotonic(),quality,epoch)
            self.cv.notify_all()

    def set_intervals(self, intervals):
        with self.cv:
            for camera, interval in enumerate(intervals):
                if self.intervals[camera] != interval:
                    self.intervals[camera] = interval
                    self.next_offer[camera] = 0.0
                    self.pending[camera] = None
                    self.generation[camera] += 1

    def snapshot(self):
        now=time.monotonic()
        with self.cv:
            for h in self.history:
                while h and now-h[0]>5: h.popleft()
            return dict(enabled=self.enabled[:],confidence=self.confidence,completed=self.completed[:],
                replaced=self.replaced[:],fps=[len(h)/5 for h in self.history],
                results=[dict(x,age_ms=(now-x['offered'])*1000) if x else None for x in self.results],
                error=self.error)

    def _run(self, worker):
        try:
            while True:
                with self.cv:
                    def choose_camera():
                        other = 1-worker
                        if self.pending[worker] is not None:
                            return worker
                        if (self.intervals[worker] > 0 and self.enabled[worker] and
                                self.enabled[other] and self.intervals[other] == 0 and
                                self.pending[other] is not None):
                            return other
                        return None
                    self.cv.wait_for(lambda:self.stopping or choose_camera() is not None)
                    if self.stopping:return
                    cam=choose_camera()
                    item=self.pending[cam];self.pending[cam]=None
                    confidence=self.confidence
                    generation=self.generation[cam]
                frame_id,frame,mode,offered,quality,epoch=item
                if not self.init_ready.is_set():
                    with self.init_lock:
                        if not self.init_ready.is_set():
                            for i in range(2):
                                if self.detectors[i] is None:
                                    self.detectors[i]=self.detector_factory(i)
                            self.init_ready.set()
                t=time.monotonic();boxes=self.detectors[worker].run(frame,confidence);done=time.monotonic()
                with self.cv:
                    self.completed[cam]+=1;self.history[cam].append(done)
                    previous=self.results[cam]
                    if (self.enabled[cam] and generation==self.generation[cam] and
                            (previous is None or offered>previous['offered'])):
                        self.results[cam]=dict(camera=cam,frame_id=frame_id,mode=mode,
                            offered=offered,completed=done,inference_ms=(done-t)*1000,boxes=boxes)
                        if self.detection_log:
                            self.detection_log.offer(cam,frame_id,frame,mode,quality,epoch,boxes,confidence,(done-t)*1000)
        except Exception as exc:
            with self.cv:self.error=str(exc);self.pending=[None,None]

    def close(self):
        with self.cv:self.stopping=True;self.pending=[None,None];self.cv.notify_all()
        for thread in self.threads: thread.join(timeout=10)
        for i, thread in enumerate(self.threads):
            if not thread.is_alive() and self.detectors[i]:self.detectors[i].close()
