"""Aligned native 32-bit MMIO accesses preserve atomic AXI-Lite writes.
Explicit V2 BAR control. Never enable streams while the old V1 driver runs."""
import argparse,json,mmap,ctypes
from pathlib import Path
from dual_csi_protocol import CONTROL_MAGIC
from feature_observer import read_observations

STREAM_BUILDS = (0x53545231, 0x53545232, 0x53545233, 0x53545234, 0x53545235, 0x4f425331, 0x50524631, 0x434c4131, 0x434c4132,0x434c4133,0x434c4134,0x434c4135,0x434c4136,0x434c4137,0x434c4138,0x434c4139,0x44514631)
PIPELINE_FIELDS = ('tick', 'raw_groups', 'isp_input_groups', 'isp_output_groups',
                   'processed_groups', 'line_admission_wait', 'raw_blocked',
                   'ddr_ar_wait', 'ddr_r_blocked', 'ddr_aw_wait', 'ddr_w_wait',
                   'ddr_response_wait')


def decode_performance(pipeline, jpeg):
    if pipeline is None or jpeg is None:
        return None
    if len(pipeline) != 16 or len(jpeg) != 12:
        raise ValueError('STR3 performance requires 16 pipeline and 12 JPEG words')
    reserved = pipeline[12] | ((pipeline[13] & 15) << 32)
    peak = pipeline[14] | ((pipeline[15] & 15) << 32)
    return dict(pipeline=dict(zip(PIPELINE_FIELDS, pipeline[:12])),
                reserved_groups=[(reserved >> (12*i)) & 4095 for i in range(3)],
                peak_groups=[(peak >> (12*i)) & 4095 for i in range(3)],
                line_fault=bool(pipeline[15] & 16),
                credit_fault=bool(pipeline[15] & 32),
                jpeg=[dict(accepted_pixels=jpeg[3*i], input_wait=jpeg[3*i+1],
                           output_wait=jpeg[3*i+2], dma_wait=jpeg[9+i])
                      for i in range(3)])


def read_performance(read, stream_build):
    if stream_build not in (0x53545233, 0x53545234, 0x53545235, 0x4f425331, 0x50524631, 0x434c4131, 0x434c4132,0x434c4133,0x434c4134,0x434c4135,0x434c4136,0x434c4137,0x434c4138,0x434c4139,0x44514631):
        return None
    # BAR words are live samples. Counters wrap at 32 bits; compare short
    # intervals, and do not interpret a multiword sample as an atomic trace.
    return decode_performance([read(0x400+4*i) for i in range(16)],
                              [read(0x480+4*i) for i in range(12)])


STORE_FIELDS = ('ar_requests', 'r_beats', 'r_no_valid_cycles', 'ar_first_latency_sum',
                'ar_first_latency_max', 'read_outstanding_peak', 'read_fifo_peak',
                'aw_requests', 'w_beats', 'b_responses', 'aw_to_b_latency_sum',
                'aw_to_b_latency_max', 'both_write_banks_full_cycles', 'no_ready_cycles',
                'jpeg_unarmed_cycles', 'jpeg_tail_sum', 'jpeg_tail_max', 'jobs',
                'job_interval_sum', 'job_interval_max')
DROP_FIELDS = ('no_free', 'input_timeout', 'frame_id', 'ordinal', 'bad_flag',
               'new_sof_interrupt', 'axi_write')


def decode_store_diagnostics(words, dma):
    if len(words) != 48 or len(dma) != 9:
        raise ValueError('STR5 requires 48 store words and 9 DMA words')
    if words[0] == 0:
        return None  # Pipeline reset or first mailbox transfer not yet complete.
    if words[0] != 0x44353031:
        raise ValueError('Unknown STR5 diagnostic page version')
    flags = words[37]
    return dict(version=hex(words[0]), max_reads=words[1], tick=words[2],
                drops={name: [words[3+2*i], words[4+2*i]] for i, name in enumerate(DROP_FIELDS)},
                counters=dict(zip(STORE_FIELDS, words[17:37])),
                first_drop=None if not flags & 1 else dict(
                    causes=[name for i, name in enumerate(DROP_FIELDS) if flags & (2 << i)],
                    camera=(flags >> 9) & 1, slot=(flags >> 10) & 7,
                    tx_state=(flags >> 13) & 3, write_state=(flags >> 15) & 7,
                    frame_id=words[38], ordinal=words[39], tick=words[40]),
                read_buffered=words[41] & 1023,
                read_reserved=(words[41] >> 10) & 1023,
                read_outstanding=(words[41] >> 20) & 7,
                write_bank_peak=words[42], ready_peaks=[words[43] & 7, (words[43] >> 16) & 7],
                raw_frames=words[44], r_mid_burst_gaps=words[45],
                ar_stall_cycles=words[46], r_backpressure_cycles=words[47],
                dma=[dict(bytes=dma[i*3] | (dma[i*3+1] << 32), packets=dma[i*3+2]) for i in range(3)])


def read_store_diagnostics(read, stream_build):
    if stream_build not in (0x53545235, 0x4f425331, 0x50524631, 0x434c4131, 0x434c4132,0x434c4133,0x434c4134,0x434c4135,0x434c4136,0x434c4137,0x434c4138,0x434c4139,0x44514631):
        return None
    # Each first read freezes its whole page. These two pages are individually
    # atomic, but the store/DDR and DMA snapshots are from different clocks.
    return decode_store_diagnostics([read(0x500+4*i) for i in range(48)],
                                    [read(0x600+4*i) for i in range(9)])

def decode_diagnostics(words):
    if words is None:return None
    status=words[0]
    def camera(i):
        p,nack,last,rx,frames,cropped,errors=words[i:i+7]
        return {'register_index':p&255,'config_state':(p>>8)&15,
                'i2c_busy':bool(p&(1<<12)),'pwdnb':bool(p&(1<<13)),
                'stream_configured':bool(p&(1<<14)),
                'clock_alive':bool(p&(1<<19)),'auto_delay_done':bool(p&(1<<20)),
                'phy_flags':hex(p>>24),'nack_count':nack,
                'last_failed_register':hex((last>>8)&65535),
                'last_failed_data':last&255,'last_failed_byte':(last>>24)&3,
                'decoded_words':rx,'decoded_frames':frames,
                'cropped_frames':cropped,'crop_errors':errors}
    return {'pll_lock':bool(status&1),'ddr_calibrated':bool(status&2),
            'pipeline_released':bool(status&4),'stream_reset_released':bool(status&8),
            'ddr_calibration_error':(status>>4)&255,
            'camera_a':camera(1),'camera_b':camera(8),'heartbeat':words[15]}

def decode_calibration(word):
    return {'selected_tap':word&63,'manual_mode':bool(word&64),
            'load_pulse':bool(word&128),'eye_width':(word>>8)&63,
            'scan_done':bool(word&(1<<14)),'no_eye_fallback':bool(word&(1<<15))}

def decode_stream_diagnostics(words):
    if words is None:return None
    build,jpeg,detail,capacity,flags,index,output,frame,guard=words
    causes={1:'axi_write_response',2:'axi_read_response',3:'axi_read_last',4:'jpeg_or_pipeline'}
    def bridge_cause(value):
        return {'unexpected_sof':bool(value&1),'bad_eol':bool(value&2),
                'too_many_lines':bool(value&4),'fifo_full':bool(value&8)}
    return {'build':hex(build),'jpeg_output_capacity_bytes':capacity,
            'bridge_fault_lanes':jpeg&7,'packer_fault_lanes':(jpeg>>3)&7,
            'bridge_causes':[bridge_cause(detail>>28),bridge_cause(detail>>24),bridge_cause(detail)],
            'tile_c_fault_line':(detail>>4)&1023,'tile_c_fault_beat':(detail>>14)&1023,
            'first_fault':None if not flags&1 else {
                'cause':causes.get((flags>>1)&7,'unknown'),'read_state':(flags>>4)&7,
                'write_state':(flags>>7)&3,'camera':(flags>>9)&1,'slot':(flags>>10)&7,
                'read_beat':(flags>>13)&15,'rresp':(flags>>17)&3,
                'rlast':bool(flags&(1<<19)),'bresp':(flags>>20)&3,
                'read_word_index':index,'output_word_index':output,'frame_id':frame},
            'ddr_guard':{'write_active':bool(guard&1),'write_address_sent':bool(guard&2),
                'write_done':bool(guard&4),'read_active':bool(guard&8),
                'read_address_sent':bool(guard&16),'abort_write':bool(guard&32),
                'abort_read':bool(guard&64),'write_beat':(guard>>8)&255,
                'aborted_transactions':guard>>16}}

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--bar',type=Path,required=True,help='PCI user BAR resource file; do not guess resource index')
    p.add_argument('--mode-a',type=int,choices=(0,1,2,3,4,5))
    p.add_argument('--mode-b',type=int,choices=(0,1,2,3,4,5))
    p.add_argument('--gauss-a',type=int,choices=range(5),help='Gaussian alpha in quarters; PRF1, CLA1 or CLA2')
    p.add_argument('--gauss-b',type=int,choices=range(5),help='Gaussian alpha in quarters; PRF1, CLA1 or CLA2')
    p.add_argument('--quality',type=int,choices=range(1,101))
    p.add_argument('--quality-a',type=int,choices=range(1,101))
    p.add_argument('--quality-b',type=int,choices=range(1,101))
    p.add_argument('--independent-qf',type=int,choices=(0,1))
    p.add_argument('--display',type=int,choices=(0,1),help='RK display request; FPGA still streams both cameras')
    p.add_argument('--enable',type=int,choices=(0,1))
    p.add_argument('--reset',action='store_true')
    a=p.parse_args()
    with a.bar.open('r+b',buffering=0) as f, mmap.mmap(f.fileno(),4096) as bar:
        def read(offset):return ctypes.c_uint32.from_buffer(bar,offset).value
        if read(0x200)!=CONTROL_MAGIC or read(0x204)!=2:
            raise SystemExit('BAR does not contain the DVC2 control ABI')
        supported=read(0x280)
        dqf_supported=read(0x2a4)==0x32465144
        if any(v is not None for v in (a.quality_a,a.quality_b,a.independent_qf)) and not dqf_supported:
            raise SystemExit('Independent QF is not supported by this bitstream')
        if a.quality is not None and a.quality_a is not None:
            raise SystemExit('Use either --quality or --quality-a')
        stream_build=read(0x28c)
        for mode in (a.mode_a,a.mode_b):
            if mode is not None and not supported & (1<<mode):
                raise SystemExit('Selected preprocessing mode is not supported by this bitstream')
        if a.gauss_a is not None or a.gauss_b is not None:
            if stream_build not in (0x50524631,0x434c4131,0x434c4132,0x434c4133,0x434c4134,0x434c4135,0x434c4136,0x434c4137,0x434c4138,0x434c4139,0x44514631):
                raise SystemExit('Adjustable Gaussian requires PRF1, CLA1 or CLA2')
            strength=read(0x22c)
            for value,shift in ((a.gauss_a,0),(a.gauss_b,4)):
                if value is not None:strength=(strength&~(7<<shift))|(value<<shift)
            ctypes.c_uint32.from_buffer(bar,0x22c).value=strength
        word=read(0x218)&0x7fff
        for value,shift,mask in [(a.enable,0,1),(a.mode_a,1,7),(a.mode_b,4,7),(a.quality,7,127),(a.display,14,1)]:
            if value is not None:word=(word&~(mask<<shift))|(value<<shift)
        if a.reset:word|=0x80000000
        if a.reset or any(v is not None for v in (a.enable,a.mode_a,a.mode_b,a.quality,a.display)):
            ctypes.c_uint32.from_buffer(bar,0x218).value=word
        if any(v is not None for v in (a.quality_a,a.quality_b,a.independent_qf)):
            qf=read(0x2a0)
            for value,shift,mask in ((a.quality_a,0,127),(a.quality_b,8,127),(a.independent_qf,16,1)):
                if value is not None:qf=(qf&~(mask<<shift))|(value<<shift)
            ctypes.c_uint32.from_buffer(bar,0x2a0).value=qf
        revision=read(0x284)
        diagnostics=[read(0x300+4*i) for i in range(16)] if revision in (0x20261023,0x20261024) else None
        rx_build=read(0x288)
        calibration={name:decode_calibration(read(offset)) for name,offset in
                     (('camera_a',0x340),('camera_b',0x344))} if rx_build==0x444c5931 else None
        stream_build=read(0x28c)
        stream_words=[read(offset) for offset in (0x28c,0x290,0x294,0x298,0x348,0x34c,0x350,0x354,0x358)] if stream_build in STREAM_BUILDS else None
        print(json.dumps({'revision':hex(revision),'rx_build':hex(rx_build),
                          'calibration':calibration,'diagnostics':decode_diagnostics(diagnostics),
                          'stream_diagnostics':decode_stream_diagnostics(stream_words),
                          'performance':read_performance(read,stream_build),
                          'store_diagnostics':read_store_diagnostics(read,stream_build),
                          'feature_observations':read_observations(read,stream_build),
                          'requested':read(0x218),'epoch':read(0x21c),'status':read(0x220),
                          'dual_qf_supported':dqf_supported,
                          'dual_qf':read(0x2a0) if dqf_supported else None,
                          'supported_modes':supported,
                          'gaussian_strength':read(0x22c) if stream_build in (0x50524631,0x434c4131,0x434c4132,0x434c4133,0x434c4134,0x434c4135,0x434c4136,0x434c4137,0x434c4138,0x434c4139,0x44514631) else None,
                          'applied_quality':read(0x224),'current_metadata':read(0x228),
                          'statistics':[read(0x240+4*i) for i in range(16)]},indent=2))
if __name__=='__main__':main()
