"""Temporary synthetic display microbenchmark; not a camera throughput test."""
import json
import time
import gi
gi.require_version('Gst','1.0')
from gi.repository import Gst
Gst.init(None)
for fmt, sink_options in [('NV12','fakesink'), ('RGBx','fakesink'),
        ('NV12','kmssink sync-mode=auto'), ('NV12','kmssink skip-vsync=true'),
        ('RGBx','kmssink sync-mode=auto')]:
    ending = sink_options+' name=output sync=false'
    if 'kmssink' in ending:
        ending += ' connector-id=188'
    pipe = Gst.parse_launch('videotestsrc is-live=true pattern=ball '
        '! video/x-raw,format=GRAY8,width=1920,height=1080,framerate=60/1 '
        '! videoconvert name=convert ! video/x-raw,format='+fmt+' ! '+ending)
    starts, elapsed = [], []
    def before(pad, info):
        starts.append(time.monotonic())
        return Gst.PadProbeReturn.OK
    def after(pad, info):
        if starts:
            elapsed.append((time.monotonic()-starts.pop())*1000)
        return Gst.PadProbeReturn.OK
    pipe.get_by_name('convert').get_static_pad('sink').add_probe(Gst.PadProbeType.BUFFER,before)
    pipe.get_by_name('convert').get_static_pad('src').add_probe(Gst.PadProbeType.BUFFER,after)
    pipe.set_state(Gst.State.PLAYING)
    time.sleep(1)
    sink = pipe.get_by_name('output')
    r0 = int(sink.get_property('stats').get_value('rendered'))
    t0 = time.monotonic()
    time.sleep(3)
    r1 = int(sink.get_property('stats').get_value('rendered'))
    dt = time.monotonic()-t0
    error = pipe.get_bus().pop_filtered(Gst.MessageType.ERROR)
    pipe.set_state(Gst.State.NULL)
    print(json.dumps(dict(format=fmt,sink=sink_options,fps=(r1-r0)/dt,
        convert_ms=sum(elapsed)/max(1,len(elapsed)),
        error=str(error.parse_error()) if error else None)),flush=True)
