"""Strict direct-to-raster decoding and capacity-aware, per-thread CPU affinity."""
import ctypes
import os
from pathlib import Path
import threading


def fast_cpus():
    allowed = sorted(os.sched_getaffinity(0)) if hasattr(os, 'sched_getaffinity') else []
    capacities = {}
    for cpu in allowed:
        try:
            capacities[cpu] = int(Path(f'/sys/devices/system/cpu/cpu{cpu}/cpu_capacity').read_text())
        except (OSError, ValueError):
            return []
    if not capacities or min(capacities.values()) == max(capacities.values()):
        return []
    return [cpu for cpu in allowed if capacities[cpu] == max(capacities.values())]


def bind_decoder(camera, policy):
    cpus = fast_cpus() if policy == 'auto' else []
    result = dict(policy=policy, tid=threading.get_native_id())
    if cpus:
        try:
            os.sched_setaffinity(0, {cpus[camera % len(cpus)]})
        except OSError as exc:
            result['error'] = str(exc)
    if hasattr(os, 'sched_getaffinity'):
        result['cpus'] = sorted(os.sched_getaffinity(0))
    return result


class StripeDecoder:
    def __init__(self, path=None):
        self.lib = ctypes.CDLL(str(path or Path(__file__).with_name('libjpeg_stripes.so')))
        self.lib.jpeg_stripes_create.argtypes = []
        self.lib.jpeg_stripes_create.restype = ctypes.c_void_p
        self.lib.jpeg_stripes_destroy.argtypes = [ctypes.c_void_p]
        self.lib.jpeg_stripes_destroy.restype = None
        self.lib.jpeg_stripes_decode.argtypes = [ctypes.c_void_p,
            ctypes.c_char_p, ctypes.c_size_t, ctypes.c_char_p, ctypes.c_size_t,
            ctypes.c_char_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t,
            ctypes.c_void_p, ctypes.c_size_t]
        self.lib.jpeg_stripes_decode.restype = ctypes.c_int
        self.context = self.lib.jpeg_stripes_create()
        if not self.context:
            raise MemoryError('Cannot allocate JPEG stripe context')
        self.output = ctypes.create_string_buffer(1920 * 1080)
        self.error = ctypes.create_string_buffer(512)

    def decode(self, tiles):
        if len(tiles) != 3:
            raise ValueError('Three JPEG stripes required')
        result = self.lib.jpeg_stripes_decode(self.context,
            tiles[0], len(tiles[0]), tiles[1], len(tiles[1]), tiles[2], len(tiles[2]),
            self.output, len(self.output), self.error, len(self.error))
        if result:
            raise RuntimeError(self.error.value.decode(errors='replace'))
        return self.output.raw

    def close(self):
        if self.context:
            self.lib.jpeg_stripes_destroy(self.context)
            self.context = None
