"""DJP2 framing and bounded, camera-aware three-tile assembly. Python 3.9+."""
from dataclasses import dataclass, replace
from collections import OrderedDict
import ctypes
from pathlib import Path
import struct

HEADER = struct.Struct('<4sHHIBBBBHHHBBII')
MAGIC = b'DJP2'
CONTROL_MAGIC = 0x32435644
MAX_JPEG_BYTES = 4194304

try:
    _marker_library = ctypes.CDLL(str(Path(__file__).with_name('libjpeg_marker_scan.so')))
    _marker_scan = _marker_library.jpeg_marker_scan
    _marker_scan.argtypes = [ctypes.c_void_p, ctypes.c_size_t,
        ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_size_t)]
    _marker_scan.restype = ctypes.c_int
except OSError:
    _marker_scan = None

@dataclass(frozen=True)
class Tile:
    frame_id: int
    camera: int
    tile: int
    mode: int
    quality: int
    width: int
    height: int
    tile_height: int
    stripe: int
    layout: int
    epoch: int
    timestamp: int
    jpeg: bytes

    @property
    def group(self):
        return (self.camera, self.frame_id)

    @property
    def configuration(self):
        return (self.mode, self.quality, self.width, self.height,
                self.tile_height, self.stripe, self.layout, self.epoch, self.timestamp)

def _envelope(packet, dma_channel):
    if len(packet) < HEADER.size:
        raise ValueError('truncated DJP2 header')
    magic, version, size, *fields = HEADER.unpack_from(packet)
    if (magic, version, size) != (MAGIC, 2, 32):
        raise ValueError(f'invalid DJP2 header: magic={magic!r}, version={version}, size={size}')
    tile = Tile(*fields, b'')
    if tile.camera not in (0, 1) or tile.tile not in (0, 1, 2):
        raise ValueError('invalid camera/tile ID')
    if dma_channel is not None and dma_channel != tile.tile + 1:
        raise ValueError('tile ID does not match C2H channel')
    if (tile.width, tile.height, tile.tile_height, tile.stripe, tile.layout) != (1920, 1080, 360, 8, 1):
        raise ValueError('unsupported geometry/stripe layout')
    if tile.mode not in (0,1,2,3,4,5) or not 1 <= tile.quality <= 100:
        raise ValueError('invalid demo mode/quality')
    return tile


def parse_packet(packet: bytes, dma_channel=None) -> Tile:
    if len(packet) < HEADER.size + 4:
        raise ValueError('truncated DJP2 packet')
    tile = _envelope(packet, dma_channel)
    tile = replace(tile, jpeg=packet[HEADER.size:])
    if len(tile.jpeg) > MAX_JPEG_BYTES or not tile.jpeg.startswith(b'\xff\xd8') or not tile.jpeg.endswith(b'\xff\xd9'):
        raise ValueError('invalid or truncated JPEG payload')
    return tile


class PacketStream:
    """Bounded DJP2/JPEG framing independent of DMA read completion boundaries.

    JPEG segment lengths protect embedded marker/header-like bytes in APP/COM
    data. Entropy data is scanned for markers with FF00 stuffing and restart
    markers handled explicitly. A damaged packet is discarded and resynced.
    """
    def __init__(self, dma_channel, max_jpeg_bytes=MAX_JPEG_BYTES):
        if dma_channel not in (1, 2, 3) or max_jpeg_bytes < 4:
            raise ValueError('invalid channel or JPEG size bound')
        self.channel = dma_channel
        self.limit = HEADER.size + max_jpeg_bytes
        self.buffer = bytearray()
        self.position = None
        self.entropy = False
        self.invalid_packets = 0
        self.discarded_bytes = 0
        self.complete_packets = 0
        self.read_chunks = 0
        self.max_buffered_bytes = 0

    def _discard(self, count):
        del self.buffer[:count]
        self.discarded_bytes += count
        self.position = None
        self.entropy = False

    def _end(self):
        if _marker_scan is None:
            return self._end_python()
        position=ctypes.c_size_t(self.position)
        entropy=ctypes.c_int(self.entropy)
        end=ctypes.c_size_t()
        pointer=ctypes.c_ubyte.from_buffer(self.buffer)
        result=_marker_scan(ctypes.addressof(pointer),len(self.buffer),
            ctypes.byref(position),ctypes.byref(entropy),ctypes.byref(end))
        del pointer
        self.position=position.value
        self.entropy=bool(entropy.value)
        if result<0:
            raise ValueError({-1:'JPEG marker prefix missing',-2:'unexpected JPEG marker',
                              -3:'invalid JPEG segment length'}.get(result,'JPEG marker scan failed'))
        return end.value if result else None

    def _end_python(self):
        data = self.buffer
        while self.position < len(data):
            pos = self.position
            if self.entropy:
                pos = data.find(b'\xff', pos)
                if pos < 0:
                    self.position = len(data)
                    return None
            elif data[pos] != 0xff:
                raise ValueError('JPEG marker prefix missing')
            marker = pos + 1
            while marker < len(data) and data[marker] == 0xff:
                marker += 1
            if marker == len(data):
                self.position = pos
                return None
            code = data[marker]
            if self.entropy and (code == 0 or 0xd0 <= code <= 0xd7):
                self.position = marker + 1
                continue
            if code == 0xd9:
                return marker + 1
            if code in (0, 0xd8) or 0xd0 <= code <= 0xd7:
                raise ValueError('unexpected JPEG marker')
            if code == 1:
                self.position = marker + 1
                continue
            if len(data) < marker + 3:
                self.position = pos
                return None
            length = (data[marker+1] << 8) | data[marker+2]
            if length < 2:
                raise ValueError('invalid JPEG segment length')
            end = marker + 1 + length
            if len(data) < end:
                self.position = pos
                return None
            self.position = end
            self.entropy = code == 0xda
        return None

    def _extract(self):
        packets = []
        while self.buffer:
            if self.position is None:
                start = self.buffer.find(MAGIC)
                if start < 0:
                    self._discard(max(0, len(self.buffer)-len(MAGIC)+1))
                    break
                if start:
                    self._discard(start)
                if len(self.buffer) < HEADER.size + 2:
                    break
                try:
                    _envelope(self.buffer, self.channel)
                    if self.buffer[HEADER.size:HEADER.size+2] != b'\xff\xd8':
                        raise ValueError('JPEG SOI missing')
                except ValueError:
                    self.invalid_packets += 1
                    self._discard(1)
                    continue
                self.position = HEADER.size + 2
            try:
                end = self._end()
            except ValueError:
                self.invalid_packets += 1
                self._discard(1)
                continue
            if end is None:
                break
            packets.append(bytes(self.buffer[:end]))
            del self.buffer[:end]
            self.position = None
            self.entropy = False
            self.complete_packets += 1
        return packets

    def feed(self, chunk):
        self.read_chunks += 1
        packets = []
        view = memoryview(chunk)
        offset = 0
        while offset < len(view):
            if len(self.buffer) == self.limit:
                self.invalid_packets += 1
                self._discard(1)
                packets.extend(self._extract())
            amount = min(len(view)-offset, self.limit-len(self.buffer))
            self.buffer.extend(view[offset:offset+amount])
            offset += amount
            self.max_buffered_bytes = max(self.max_buffered_bytes, len(self.buffer))
            packets.extend(self._extract())
        return packets

    def diagnostics(self):
        return dict(read_chunks=self.read_chunks, complete_packets=self.complete_packets,
                    invalid_packets=self.invalid_packets, discarded_bytes=self.discarded_bytes,
                    buffered_bytes=len(self.buffer), max_buffered_bytes=self.max_buffered_bytes)

class Assembler:
    """Accepts asynchronous C2H1/2/3 completions; never pairs different cameras.

    A missing tile evicts a whole group when the pending bound is reached.
    Reset this object when the FPGA stream is reset (frame IDs restart).
    """
    def __init__(self, max_pending=12):
        if max_pending < 2:
            raise ValueError('max_pending must be at least two')
        self.max_pending = max_pending
        self.pending = OrderedDict()
        self.incomplete_drops = 0
        self.stale_drops = 0
        self.last = [None, None]

    def push(self, tile: Tile):
        previous = self.last[tile.camera]
        if previous is not None:
            delta = (tile.frame_id - previous) & 0x0fffffff
            if delta == 0 or delta >= 0x08000000:
                self.stale_drops += 1
                return None
        group = self.pending.setdefault(tile.group, {})
        if tile.tile in group:
            raise ValueError('duplicate tile in one source frame')
        if group and next(iter(group.values())).configuration != tile.configuration:
            del self.pending[tile.group]
            raise ValueError('mixed configuration/timestamp within one source frame')
        group[tile.tile] = tile
        if len(group) == 3:
            del self.pending[tile.group]
            self.last[tile.camera] = tile.frame_id
            return tuple(group[i] for i in range(3))
        while len(self.pending) > self.max_pending:
            self.pending.popitem(last=False)
            self.incomplete_drops += 1
        return None

def decode_frame(tiles):
    """Reference reconstruction; production RK should use its native decoder."""
    from io import BytesIO
    import numpy as np
    from PIL import Image
    first = tiles[0]
    if len(tiles) != 3 or any(t.group != first.group or t.configuration != first.configuration for t in tiles):
        raise ValueError('requires three consistent tiles from one camera/frame')
    rows = []
    for t in tiles:
        image = Image.open(BytesIO(t.jpeg)).convert('L')
        if image.size != (first.width, first.tile_height):
            raise ValueError('JPEG dimensions disagree with envelope')
        rows.append(np.asarray(image).reshape(-1, first.stripe, first.width))
    # [stripe group][tile][8 rows][pixel] -> original raster image.
    raster = np.stack(rows, axis=1).reshape(first.height, first.width)
    return Image.fromarray(raster)
