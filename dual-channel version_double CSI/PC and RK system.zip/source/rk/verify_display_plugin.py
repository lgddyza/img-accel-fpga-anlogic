"""Board-native pixel/stride/OSD regression, not a camera or HDMI test."""
import json
from pathlib import Path
import sys
import gi
gi.require_version('Gst','1.0')
from gi.repository import Gst
Gst.init(None)
Gst.Plugin.load_file(str(Path(sys.argv[1]).resolve()))
cases=[]
for width,height,osd in ((256,16,False),(258,32,False),(1920,1080,True)):
    pipe=Gst.parse_launch(f'appsrc name=input caps=video/x-raw,format=GRAY8,width={width},height={height},framerate=1/1 '
        f'! rkdualgray name=converter osd={str(osd).lower()} ! appsink name=output sync=false')
    converter=pipe.get_by_name('converter')
    converter.set_property('text','CAM B  1920x1080\nHDMI FPS:60.0\nDECODE A:60.0 B:60.0\nMODE:GRAY  QF:85')
    stride=(width+3)&~3
    src=bytes((x%256) for y in range(height) for x in range(stride))
    pipe.set_state(Gst.State.PLAYING)
    pipe.get_by_name('input').emit('push-buffer',Gst.Buffer.new_wrapped(src))
    sample=pipe.get_by_name('output').emit('try-pull-sample',5*Gst.SECOND)
    assert sample is not None, 'No output sample'
    buf=sample.get_buffer()
    result=buf.extract_dup(0,buf.get_size())
    expected=bytes(16+(x%256*219+127)//255 for y in range(height) for x in range(stride))
    for y in range(height):
        for x in range(width):
            if osd and 24<=x<700 and 24<=y<170:
                continue
            assert result[y*stride+x]==expected[y*stride+x],(x,y,result[y*stride+x],expected[y*stride+x])
    y_size=stride*((height+1)&~1)
    assert all(v==128 for v in result[y_size:]), 'Nonneutral chroma'
    if osd:
        assert any(result[y*stride+x]!=expected[y*stride+x] for y in range(24,165) for x in range(24,650))
        Path('/root/dual_vision_host/build_display/osd_reference.pgm').write_bytes(b'P5\n1920 1080\n255\n'+result[:1920*1080])
    cases.append(dict(width=width,height=height,osd=osd,pixels_verified=True))
    pipe.set_state(Gst.State.NULL)
print(json.dumps(dict(passed=True,cases=cases)))
