"""Atomic status snapshots and monotonic five-second throughput windows."""
from collections import deque
import json
import os
from pathlib import Path
import time


class LiveStatus:
    def __init__(self, path):
        self.path = Path(path) if path else None
        self.history = deque(maxlen=8)

    def write(self, stats, sample, selected, preview, running=True):
        now = time.monotonic()
        self.history.append((now, stats['decoded_frames'][:], stats['submitted_hdmi'][:], stats['dma_bytes'][:]))
        while len(self.history) > 2 and now-self.history[1][0] >= 5:
            self.history.popleft()
        first = self.history[0]
        elapsed = now-first[0]
        def rates(values, before, scale=1):
            return [(b-a)*scale/elapsed for a,b in zip(before,values)] if elapsed >= .1 else [None]*len(values)
        result = dict(schema=1, pid=os.getpid(), running=running, sample_s=now,
            elapsed=stats.get('runtime_elapsed', sample['t']), selected=selected, board=sample,
            board_sample_age_s=max(0, stats.get('runtime_elapsed', sample['t'])-sample['t']),
            rates=dict(decoded=rates(stats['decoded_frames'],first[1]),
                hdmi_submitted=rates(stats['submitted_hdmi'],first[2]),
                dma_mbps=rates(stats['dma_bytes'],first[3],8/1e6)),
            counters={k:stats[k] for k in ('decoded_frames','complete_frames','submitted_hdmi',
                'decode_rejected_frames','dma_bytes','queue_drops','decode_queue_drops',
                'display_queue_drops','dma_errors','decode_errors','last_frame_ids')},
            decoded_modes=stats.get('decoded_modes', [None, None]),
            decoded_quality=stats.get('decoded_quality', [None, None]),
            submitted_modes=stats.get('submitted_modes', [None, None]),
            yolo=stats.get('yolo'),
            adaptive=stats.get('adaptive'),
            detection_log=stats.get('detection_log'),
            packet_streams=stats.get('packet_streams', []), preview=preview,
            decoder=stats.get('decoder_runtime'),
            display=stats.get('display'))
        self.latest = result
        if self.path:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self.path.with_suffix('.tmp')
            temporary.write_text(json.dumps(result), encoding='utf-8')
            temporary.chmod(0o600)
            temporary.replace(self.path)
        return result
