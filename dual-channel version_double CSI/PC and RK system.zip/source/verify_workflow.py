"""Exercise actual Qt controls against the board, including stop and reconnect."""
import json
import os
from pathlib import Path
import time
from PySide6.QtCore import QTimer
from PySide6.QtGui import QFontDatabase
from PySide6.QtWidgets import QApplication
from app import Window
from transport import SSHTransport,default_key
from telemetry import redact

app = QApplication([])
if not QFontDatabase.families():
    for name in ('msyh.ttc','msyhbd.ttc','segoeui.ttf'):
        QFontDatabase.addApplicationFont('C:/Windows/Fonts/'+name)
app.setStyle('Fusion')
window = Window()
window.show()
output = Path('verification/workflow')
output.mkdir(parents=True,exist_ok=True)
state = dict(phase='connect',events=[],pid=None,done=False)


def record(name,status=None):
    value = dict(event=name,pc_monotonic=time.monotonic(),status=redact(status))
    state['events'].append(value)
    print(name,flush=True)


def fail(action,message):
    if state['done']:
        return
    state['done'] = True
    (output/'failure.json').write_text(json.dumps(dict(action=action,error=message,events=state['events']),indent=2),encoding='utf-8')
    window.close()
    app.exit(1)


def status_changed(status):
    if state['done']:
        return
    phase = state['phase']
    live = status.get('live') or {}
    hardware = status.get('hardware') or {}
    if window.busy:
        return
    if phase=='connect' and live:
        state['pid']=live['pid']
        record('initial_connected',status)
        state['phase']='camera_a'
        window.display_buttons[0].click()
    elif phase=='camera_a' and live.get('selected')==0:
        record('hdmi_a_verified',status)
        state['phase']='camera_b'
        window.display_buttons[1].click()
    elif phase=='camera_b' and live.get('selected')==1:
        record('hdmi_b_verified',status)
        state['phase']='qf90'
        window.quality.setValue(90)
        window.apply_button.click()
    elif phase=='qf90' and hardware.get('applied_quality')==90:
        record('qf90_applied',status)
        state['phase']='qf85'
        window.quality.setValue(85)
        window.apply_button.click()
    elif phase=='qf85' and hardware.get('applied_quality')==85:
        record('qf85_restored',status)
        state['phase']='preview'
        for preview in window.previews:
            preview.start_button.click()
    elif phase=='preview' and all(p.seen>=8 for p in window.previews):
        assert all(p.canvas.image is not None for p in window.previews)
        window.previews[0].open_fullscreen()
        assert window.previews[0].fullscreen.isFullScreen()
        window.previews[0].fullscreen.close()
        window.grab().save(str(output/'ui_controls.png'))
        record('both_previews_and_fullscreen',status)
        state['phase']='disconnected'
        window.connect_button.click()
    elif phase=='reconnected' and live and window.linked:
        assert live['pid']==state['pid'],'Reconnecting restarted the receiver'
        record('same_receiver_survived_reconnect',status)
        state['phase']='stop'
        window.stop_button.click()
    elif phase=='stop' and status['runtime']=='stopped':
        record('explicit_stop_verified',status)
        state['phase']='restart'
        window.start_button.click()
    elif phase=='restart' and live and all(n>=100 for n in live['counters']['decoded_frames']):
        assert live['pid']!=state['pid']
        record('explicit_start_verified',status)
        state['phase']='stale'
        window.last_received = time.monotonic()-10
        window.check_stale()
        assert all(label.text()=='—' for label in window.metric_values)
        assert not window.apply_button.isEnabled()
        record('stale_metrics_and_controls_cleared')
        state['done']=True
        (output/'result.json').write_text(json.dumps(dict(passed=True,events=state['events']),indent=2),encoding='utf-8')
        window.close()
        app.quit()


def link_changed(linked):
    if not linked and state['phase']=='disconnected':
        check = SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
        try:
            status = check.rpc(dict(action='status'))
            assert status['runtime']=='managed'
            assert status['live']['pid']==state['pid']
            record('hdmi_survived_pc_disconnect',status)
        finally:
            check.close()
        state['phase']='reconnected'
        QTimer.singleShot(300,window.toggle_connect)


window.worker.status.connect(status_changed)
window.worker.linked.connect(link_changed)
window.worker.error.connect(fail)
QTimer.singleShot(200,window.toggle_connect)
QTimer.singleShot(100000,lambda:fail('timeout',state['phase']))
raise SystemExit(app.exec())
