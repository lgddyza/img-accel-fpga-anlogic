"""Deliver the external control-agent fix and verify recovery on the board."""
import hashlib
import json
from pathlib import Path
import shutil
import time

from telemetry import redact
from transport import SSHTransport,default_key

root=Path(__file__).resolve().parent
evidence=root/'verification/pcie_recovery_20261026'
evidence.mkdir(parents=True,exist_ok=True)
release=Path('D:/RK_PROJECT_ARCHIVE/RK_DUAL_VISION_HOST_20261026_PCIE_RECOVERY')
original=Path('D:/RK_PROJECT_ARCHIVE/RK_DUAL_VISION_HOST_20261026_PREVIEW30')
release.mkdir(exist_ok=False)
shutil.copytree(original/'pc',release/'pc')
shutil.copy2(root/'board_agent.py',release/'pc/_internal/board_agent.py')
shutil.copy2(root/'release_launch.cmd',release/'launch.cmd')
source=release/'source_patch'
source.mkdir()
for name in ('board_agent.py','tests/test_control_and_status.py'):
    destination=source/name
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(root/name,destination)
manifest={path.relative_to(release).as_posix():hashlib.sha256(path.read_bytes()).hexdigest()
    for path in release.rglob('*') if path.is_file()}
(release/'MANIFEST.json').write_text(json.dumps(manifest,indent=2))
assert hashlib.sha256((release/'pc/_internal/rk_payload.zip').read_bytes()).hexdigest()==hashlib.sha256((root/'rk_payload.zip').read_bytes()).hexdigest()
print('Prepared corrected portable host',flush=True)

c=SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
records=[]
try:
    c.install()
    records.append(dict(event='before',status=redact(c.rpc(dict(action='status')))))
    c.rpc(dict(action='stop'))
    # Recreate the missing driver link seen after the boot-time probe failure.
    _,out,err=c.client.exec_command("printf 2a210000.pcie > /sys/bus/platform/drivers/rk-pcie/unbind",timeout=20)
    out.read()
    if out.channel.recv_exit_status():
        raise RuntimeError(err.read().decode(errors='replace'))
    records.append(dict(event='unbound',status=redact(c.rpc(dict(action='status')))))
    result=c.rpc(dict(action='recover'))
    assert result['hardware_error'] is None,result['hardware_error']
    assert result['hardware']['stream_diagnostics']['build']=='0x53545235'
    records.append(dict(event='recovered_unbound_controller',status=redact(result)))
    print('Previously unbound controller recovered through corrected RPC',flush=True)
finally:
    try:
        state=c.rpc(dict(action='start',quality=85,display=1,connector=188))
        records.append(dict(event='restarted',status=redact(state)))
    finally:
        (evidence/'recovery.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
        c.close()

shutil.copy2(evidence/'recovery.json',release/'RECOVERY_EVIDENCE.json')
print(release,flush=True)
