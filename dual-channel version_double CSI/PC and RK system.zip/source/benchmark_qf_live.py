"""Capture bounded, redacted live samples without changing board settings."""
import json,sys,time
from pathlib import Path
from transport import SSHTransport,default_key
from telemetry import redact

output=Path(sys.argv[1]);output.parent.mkdir(parents=True,exist_ok=True)
count=int(sys.argv[2]) if len(sys.argv)>2 else 16
c=SSHTransport({'host':'169.254.53.76','key':str(default_key())})
samples=[]
try:
    for _ in range(count):
        samples.append(redact(c.rpc({'action':'status'})))
        time.sleep(1)
finally:
    c.close();output.write_text(json.dumps(samples,indent=2,ensure_ascii=False),encoding='utf-8')
if len(samples)>1 and samples[0].get('live') and samples[-1].get('live'):
    a,b=samples[0]['live'],samples[-1]['live'];dt=b['sample_s']-a['sample_s']
    rates=lambda k:[(y-x)/dt for x,y in zip(a['counters'][k],b['counters'][k])]
    print('seconds',round(dt,2),'QF',samples[-1]['hardware']['applied_quality'],
        'complete',rates('complete_frames'),'decoded',rates('decoded_frames'),
        'display',(b['display']['rendered']-a['display']['rendered'])/dt,
        'drops',b['counters']['queue_drops']-a['counters']['queue_drops'],
        'decode_drops',[y-x for x,y in zip(a['counters']['decode_queue_drops'],b['counters']['decode_queue_drops'])],
        'framing',b['decoder'].get('framing'),'yolo',b['yolo']['fps'],flush=True)
