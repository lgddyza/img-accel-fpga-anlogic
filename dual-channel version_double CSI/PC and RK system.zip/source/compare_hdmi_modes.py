"""Capture selected HDMI sink frames and restore mode and overlay controls."""
import json
import argparse
import time
from pathlib import Path
from transport import SSHTransport, default_key

parser = argparse.ArgumentParser()
parser.add_argument('--out', default='verification/live_fixed_20261029/hdmi_1080')
parser.add_argument('--qf', type=int)
args = parser.parse_args()
out = Path(args.out)
out.mkdir(parents=True, exist_ok=True)
c = SSHTransport(dict(host='169.254.53.76', key=str(default_key())))
saved = None
remote = '/root/dual_vision_host/run/'
try:
    s = c.rpc(dict(action='status'))
    h, live = s['hardware'], s['live']
    ai = live['yolo']
    saved = dict(mode_a=(h['requested'] >> 1) & 7, display=live['selected'], quality=h['applied_quality'],
                 osd=live['display']['osd'], yolo_a=ai['enabled'][0], yolo_b=ai['enabled'][1])
    c.rpc(dict(action='configure', display=0, osd=False, yolo_a=False, yolo_b=False))
    if args.qf is not None: c.rpc(dict(action='configure', quality=args.qf))
    with c.client.open_sftp() as ftp:
        for name in ('hdmi_snapshot.nv12', 'hdmi_snapshot.json', 'hdmi_snapshot.error'):
            try:
                ftp.stat(remote+name)
            except OSError:
                continue
            backup = remote+name+'.backup_'+str(time.time_ns())
            ftp.rename(remote+name, backup)
        for index, mode in enumerate((0, 1, 5, 0)):
            c.rpc(dict(action='configure', mode_a=mode))
            time.sleep(3)
            s = c.rpc(dict(action='status'))
            if s['live']['decoded_modes'][0] != mode or s['live']['selected'] != 0:
                raise RuntimeError('Mode or displayed camera did not apply')
            for name in ('hdmi_snapshot.nv12', 'hdmi_snapshot.json', 'hdmi_snapshot.error'):
                try: ftp.remove(remote+name)
                except OSError: pass
            with ftp.open(remote+'hdmi_snapshot.request', 'w') as f: f.write('1')
            deadline = time.monotonic()+8
            while time.monotonic() < deadline:
                try:
                    with ftp.open(remote+'hdmi_snapshot.json', 'r') as f: metadata = json.loads(f.read())
                    break
                except (OSError, ValueError): time.sleep(.1)
            else: raise RuntimeError('Snapshot timed out')
            with ftp.open(remote+'hdmi_snapshot.nv12', 'rb') as f: data = f.read()
            w, h = metadata['width'], metadata['height']
            if metadata['format'] != 'NV12' or len(data) < w*h:
                raise RuntimeError('Unsupported HDMI snapshot layout: '+str(metadata))
            tag = 'gray_after' if index == 3 else 'mode_'+str(mode)
            (out/(tag+'.pgm')).write_bytes(f'P5\n{w} {h}\n255\n'.encode()+data[:w*h])
            (out/(tag+'.json')).write_text(json.dumps(metadata, indent=2), encoding='utf-8')
            print(tag, w, h, metadata['format'], flush=True)
finally:
    if saved is not None: c.rpc(dict(action='configure', **saved))
    c.close()
