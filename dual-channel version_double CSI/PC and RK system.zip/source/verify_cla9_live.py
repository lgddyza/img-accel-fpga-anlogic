"""Measure CLA9 modes and inference, then restore the original settings."""
import json
import time
from pathlib import Path
from transport import SSHTransport, default_key
from telemetry import redact

out = Path('verification/cla9_20261028/modes_yolo.json')
out.parent.mkdir(parents=True, exist_ok=True)
c = SSHTransport(dict(host='169.254.53.76', key=str(default_key())))
results = []
original = None
try:
    s = c.rpc(dict(action='status'))
    h, live = s['hardware'], s['live']
    if s['runtime'] != 'managed' or h['stream_diagnostics']['build'] != '0x434c4139':
        raise RuntimeError('CLA9 managed receiver required')
    word, strength = h['requested'], h['gaussian_strength']
    ai = live.get('yolo') or {}
    enabled = ai.get('enabled', [False, False])
    original = dict(mode_a=(word >> 1) & 7, mode_b=(word >> 4) & 7,
        gauss_a=strength & 7, gauss_b=(strength >> 4) & 7, display=live['selected'],
        yolo_a=enabled[0], yolo_b=enabled[1], yolo_confidence=ai.get('confidence', .1))
    cases = [(f'mode_{m}', dict(mode_a=m, mode_b=m, yolo_a=False, yolo_b=False))
             for m in (0, 1, 2, 3, 5)]
    cases.append(('dual_yolo', dict(mode_a=0, mode_b=0, yolo_a=True, yolo_b=True)))
    for name, params in cases:
        c.rpc(dict(action='configure', **params))
        time.sleep(8 if name == 'dual_yolo' else 4)
        a = c.rpc(dict(action='status'))
        time.sleep(10)
        b = c.rpc(dict(action='status'))
        x, y = a['live'], b['live']
        if not x or not y or x['pid'] != y['pid']:
            raise RuntimeError('Receiver stopped or restarted: ' + name)
        dt = y['sample_s'] - x['sample_s']
        delta = lambda k: [v-u for u, v in zip(x['counters'][k], y['counters'][k])]
        row = dict(case=name, seconds=dt, decoded_modes=y['decoded_modes'],
            decoded_fps=[v/dt for v in delta('decoded_frames')],
            hdmi_fps=(y['display']['rendered']-x['display']['rendered'])/dt,
            decode_drops=delta('decode_queue_drops'), rejected=delta('decode_rejected_frames'),
            dma_errors=y['counters']['dma_errors'], decode_errors=y['counters']['decode_errors'],
            yolo=y.get('yolo'), resources=b['resources'], hardware=b['hardware'])
        results.append(redact(row))
        out.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps({k: row[k] for k in ('case', 'seconds', 'decoded_modes',
            'decoded_fps', 'hdmi_fps', 'decode_drops', 'rejected', 'yolo')},
            ensure_ascii=True), flush=True)
finally:
    if original is not None:
        c.rpc(dict(action='configure', **original))
        print('Original settings restored', flush=True)
    c.close()
