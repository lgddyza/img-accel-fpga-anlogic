"""Read-only capture of runtime, kernel/driver evidence and saved raw chunks."""
import hashlib
import json
from pathlib import Path
import time
from transport import SSHTransport, default_key
from telemetry import redact

root=Path('investigation_c2h_20261025')
root.mkdir(exist_ok=True)
c=SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
try:
    commands={
        'kernel':'uname -a; modinfo anlogic_pci; cat /proc/interrupts | grep -Ei "anlogic|sgdma|pcie"; lspci -s 21:00.0 -vv',
        'dma_parameters':'find /sys/module/anlogic_pci/parameters -maxdepth 1 -type f -print -exec cat {} \\;',
        'kernel_messages':'dmesg | grep -Ei "anlogic|sgdma|AER|IOMMU|smmu|pcie|dma.*error|timeout|fault" | tail -100',
        'driver_sources':'find /root -maxdepth 6 -type f \\( -name anlogic_pci_lib.c -o -name cdev_sgdma.c -o -name anlogic_pci.ko \\) -print',
        'reader_ownership':"python3 -c 'from pathlib import Path;\nfor p in Path(\"/proc\").glob(\"[0-9]*\"):\n for f in (p/\"fd\").glob(\"*\"):\n  try:\n   t=str(f.resolve());\n   if \"ANLOGIC-PCI0_c2h_\" in t: print(p.name,f.name,t)\n  except OSError: pass'",
    }
    for name,command in commands.items():
        _,out,err=c.client.exec_command(command,timeout=20)
        data=out.read().decode(errors='replace')+err.read().decode(errors='replace')
        (root/(name+'.txt')).write_text(data,encoding='utf-8')
        print(name,data[:350],flush=True)
    with c.client.open_sftp() as ftp:
        for name in ftp.listdir('/root/dual_vision_host/run'):
            if name.startswith('resync_read_') and name.endswith('.bin'):
                ftp.get('/root/dual_vision_host/run/'+name,str(root/name))
    records=[]
    for _ in range(25):
        s=redact(c.rpc(dict(action='status')))
        records.append(s)
        live=s.get('live') or {}
        print(json.dumps(dict(t=live.get('elapsed'),runtime=s.get('runtime'),
            streams=live.get('packet_streams'),counters=live.get('counters',{}).get('queue_drops'))),flush=True)
        time.sleep(1)
    (root/'live_window.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
finally:
    c.close()
