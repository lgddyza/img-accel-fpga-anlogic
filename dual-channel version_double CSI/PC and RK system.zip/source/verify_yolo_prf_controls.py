"""Exercise both preview controls against the running PRF1 board."""
import json
from pathlib import Path
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication
from app import Window

out=Path('verification/prf1_yolo_ui_20261027')
out.mkdir(parents=True,exist_ok=True)
app=QApplication([])
window=Window()
window.show()
state={'phase':'connect','events':[],'saved':None}

def finish(error=None):
    (out/'result.json').write_text(json.dumps(dict(passed=error is None,error=error,**state),indent=2),encoding='utf-8')
    print('FAILED: '+str(error) if error else 'UI BOARD CHECK PASSED',flush=True)
    window.close();app.exit(1 if error else 0)

def activate(combo,value):
    index=combo.findData(value)
    if index<0: raise RuntimeError('Missing selection '+str(value))
    combo.setCurrentIndex(index);combo.activated.emit(index)

def status_changed(status):
    if window.busy or not status.get('live'): return
    live=status['live'];hw=status.get('hardware') or {};phase=state['phase']
    word=hw.get('requested',0);modes=[(word>>1)&7,(word>>4)&7]
    strength=hw.get('gaussian_strength')
    if phase=='connect':
        if strength is None:return
        if any([window.mode_boxes[c].itemData(i) for i in range(window.mode_boxes[c].count())]!=[0,1,5] for c in (0,1)):
            return finish('Capability list does not match PRF1')
        state['saved']={'modes':modes,'strength':strength}
        state['phase']='a_gray';activate(window.mode_boxes[0],0)
    elif phase=='a_gray' and modes[0]==0 and live.get('decoded_modes',[None,None])[0]==0:
        state['events'].append('A gray');state['phase']='a_gauss';activate(window.mode_boxes[0],1)
    elif phase=='a_gauss' and modes[0]==1 and live.get('decoded_modes',[None,None])[0]==1:
        state['events'].append('A Gaussian');state['phase']='b_gray';activate(window.mode_boxes[1],0)
    elif phase=='b_gray' and modes[1]==0 and live.get('decoded_modes',[None,None])[1]==0:
        state['events'].append('B gray');state['phase']='b_blackhat';activate(window.mode_boxes[1],5)
    elif phase=='b_blackhat' and modes==[1,5] and live.get('decoded_modes')==[1,5]:
        state['events'].append('B blackhat');state['phase']='strength';activate(window.gauss_boxes[0],2)
    elif phase=='strength' and strength is not None and (strength&7)==2:
        state['events'].append('A Gaussian strength 0.5');state['phase']='restore_strength';activate(window.gauss_boxes[0],state['saved']['strength']&7)
    elif phase=='restore_strength' and strength is not None and (strength&7)==(state['saved']['strength']&7):
        state['phase']='restore_a';activate(window.mode_boxes[0],state['saved']['modes'][0])
    elif phase=='restore_a' and modes[0]==state['saved']['modes'][0]:
        state['phase']='restore_b';activate(window.mode_boxes[1],state['saved']['modes'][1])
    elif phase=='restore_b' and modes==state['saved']['modes'] and live.get('decoded_modes')==modes:
        state['events'].append('original modes restored')
        window.grab().save(str(out/'monitor.png'))
        window.tabs.setCurrentIndex(2);app.processEvents();window.grab().save(str(out/'performance.png'))
        state['events'].append({'npu':{core:bar.format() for core,bar in window.npu_bars.items()},
            'pcie':window.pcie_link.text(),'channels':[bar.format() for bar in window.pcie_bars]})
        finish()

window.worker.status.connect(status_changed)
window.worker.error.connect(lambda action,message:finish(action+': '+message))
QTimer.singleShot(200,window.toggle_connect)
QTimer.singleShot(50000,lambda:finish('timeout: '+state['phase']) if state['phase']!='done' else None)
raise SystemExit(app.exec())
