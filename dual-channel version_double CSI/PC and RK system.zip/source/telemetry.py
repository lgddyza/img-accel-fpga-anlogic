"""Counter-derived rates with process, boot, wrap and freshness checks."""
import copy

def pcie_capacity_mbps(link):
    if not link:
        return None
    speed, width = link.get('speed_gtps'), link.get('width')
    if speed not in (2.5,5.0,8.0,16.0,32.0) or not isinstance(width,int) or width<1:
        return None
    encoding = .8 if speed<=5 else 128/130
    return speed*1000*width*encoding


def redact(value):
    if isinstance(value, dict):
        return {k:redact(v) for k,v in value.items() if k not in ('token','password')}
    if isinstance(value, list):
        return [redact(v) for v in value]
    return copy.deepcopy(value)


class Rates:
    def __init__(self):
        self.previous = None

    def update(self, status):
        previous = self.previous
        self.previous = status
        result = dict(cpu=None,capture=[None,None],delivery=[None,None])
        if not previous:
            return result
        a,b = previous.get('resources',{}),status.get('resources',{})
        wall = status['sample_s']-previous['sample_s']
        if a.get('boot_id')==b.get('boot_id') and .1<=wall<=5:
            ticks = b.get('cpu_total',0)-a.get('cpu_total',0)
            idle = b.get('cpu_idle',0)-a.get('cpu_idle',0)
            if ticks>0 and 0<=idle<=ticks:
                result['cpu'] = 100*(ticks-idle)/ticks
        before,after = previous.get('live'),status.get('live')
        if before and after and before['pid']==after['pid'] and .1<=after['sample_s']-before['sample_s']<=5:
            elapsed = after['sample_s']-before['sample_s']
            x,y = before['board']['statistics'],after['board']['statistics']
            for name,start in (('capture',0),('delivery',4)):
                values = [((y[i]-x[i])&0xffffffff)/elapsed for i in (start,start+1)]
                if all(v<1000 for v in values):
                    result[name] = values
        return result
