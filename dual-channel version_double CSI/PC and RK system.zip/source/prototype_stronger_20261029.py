"""Visualize stronger filtering on the same captured frame; software only."""
from pathlib import Path
import json
import numpy as np
from PIL import Image, ImageDraw
from compare_blackhat_profiles import profile, raw

out=Path('verification/stronger_preview_20261029')
out.mkdir(parents=True,exist_ok=True)
p=np.pad(raw.astype(np.uint16),2,mode='edge')
h,w=raw.shape
weights=[1,4,6,4,1]
total=np.zeros((h,w),dtype=np.uint32)
for y,wy in enumerate(weights):
    for x,wx in enumerate(weights): total+=p[y:y+h,x:x+w]*wy*wx
g5=((total+128)//256).astype(np.uint8)
images=[('Gray',raw),('Gaussian 5x5',g5)]
for gain in (1,4,8):
    image,_=profile(3,gain)
    images.append((f'Blackhat 3x3 gain {gain}',image))
stats={}
for name,im in images:
    label=name.lower().replace(' ','_').replace('x','x')
    Image.fromarray(im).save(out/(label+'.png'))
    d=np.abs(im.astype(np.int16)-raw.astype(np.int16))
    stats[name]={'mean_abs':float(d.mean()),'changed_pixels_percent':float((d>0).mean()*100)}
(out/'metrics.json').write_text(json.dumps(stats,indent=2),encoding='utf-8')
panel=Image.new('RGB',(1575,960),'white');draw=ImageDraw.Draw(panel)
for i,(name,im) in enumerate(images):
    x,y=(i%3)*525,(i//3)*480
    panel.paste(Image.fromarray(im).crop((150,0,1200,900)).resize((525,450)).convert('RGB'),(x,y+25))
    draw.text((x+8,y+5),name,fill='black')
panel.save(out/'comparison.png')
print(json.dumps(stats,indent=2))
