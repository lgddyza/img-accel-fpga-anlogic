"""Deploy original inference with only the fast lossless SD PNG change."""
import hashlib,json,shlex,time
from pathlib import Path
from transport import SSHTransport,default_key

root=Path(__file__).resolve().parent
c=SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
def remote(command):
    _,out,err=c.client.exec_command(command,timeout=30)
    text=out.read().decode();error=err.read().decode()
    if out.channel.recv_exit_status():raise RuntimeError(error)
    return text
before=c.rpc(dict(action='status'))
quality=before['hardware']['applied_quality'];display=before['live']['selected']
previous=remote('cat /root/dual_vision_host/bundle.path').strip()
assert previous=='/root/dual_vision_host/releases/3c65908c7952110c'
try:
    c.install()
    c.rpc(dict(action='stop'));c.rpc(dict(action='start',quality=quality,display=display))
    deadline=time.monotonic()+12
    while time.monotonic()<deadline:
        time.sleep(1)
        current=c.rpc(dict(action='status'));y=current['live']['yolo']
        if all(y['completed'][i]>0 for i in range(2) if y['enabled'][i]) and current['live']['detection_log']['saved']>0:break
    assert 'workers_per_camera' not in y and not y['error']
    assert not current['live']['detection_log']['error']
    events=c.rpc(dict(action='detection_list'))['events'];assert len(events)<=40
    saved=current['live']['detection_log']['saved']
    if saved:
        detail=c.rpc(dict(action='detection_detail',id=events[0]['id']))['event']
        with c.client.open_sftp() as sf:
            size=sf.stat('/mnt/vision_sd/dual_vision/detection_images/'+detail['image_file']).st_size
        assert 2074000<size<2080000,size
    result=dict(passed=True,original_inference_restored=True,fast_sd_png=True,records=len(events),
        saved_after_restart=saved,release=remote('cat /root/dual_vision_host/bundle.path').strip(),
        yolo_error=y['error'],sd_error=current['live']['detection_log']['error'])
    expected='ca505bbd24077ab1895ea59a8ebbb7006c2df8b89477bfbad7dc5613bf2b5983'
    for i in range(2):assert hashlib.sha256((root/'rk'/f'libroad_parallel{i}.so').read_bytes()).hexdigest()==expected
    (root/'verification'/'rollback_keep_fast_sd.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
except BaseException:
    c.rpc(dict(action='stop'))
    remote('cp /root/dual_vision_host/perf120_20261029/before/bundle.path /root/dual_vision_host/bundle.path')
    c.rpc(dict(action='start',quality=quality,display=display))
    raise
finally:c.close()
