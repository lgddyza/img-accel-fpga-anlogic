"""Summarize saved samples; fetch exact deployed driver files without restarting RX."""
import hashlib
import json
from pathlib import Path
from transport import SSHTransport, default_key

root = Path('investigation_c2h_20261025')
samples = json.loads((root/'live_window.json').read_text())
first, last = samples[0]['live'], samples[-1]['live']
dt = last['elapsed'] - first['elapsed']
def delta(a, b):
    if isinstance(a, dict):
        return {k:delta(v,b[k]) for k,v in a.items() if k in b and isinstance(v,(dict,list,int,float))}
    if isinstance(a,list):
        return [delta(x,y) for x,y in zip(a,b)]
    return b-a
summary = dict(seconds=dt, elapsed=[first['elapsed'],last['elapsed']],
    packet_delta=delta(first['packet_streams'],last['packet_streams']),
    counter_delta=delta(first['counters'],last['counters']),
    hardware_drop_delta=delta(first['board']['store_diagnostics']['drops'],last['board']['store_diagnostics']['drops']),
    dma_hardware_delta=delta(first['board']['store_diagnostics']['dma'],last['board']['store_diagnostics']['dma']),
    stream_faults=[s['live']['board']['stream_diagnostics'] for s in (samples[0],samples[-1])])
summary['events'] = []
for a,b in zip(samples,samples[1:]):
    change=[y['discarded_bytes']-x['discarded_bytes'] for x,y in zip(a['live']['packet_streams'],b['live']['packet_streams'])]
    if any(change): summary['events'].append(dict(elapsed=b['live']['elapsed'],discarded_bytes=change))
raw=[]
for p in sorted(root.glob('resync_read_*.bin')):
    data=p.read_bytes()
    raw.append(dict(file=p.name,bytes=len(data),magic=data.find(b'DJP2'),soi=data.find(b'\xff\xd8'),eoi=data.rfind(b'\xff\xd9'),prefix=data[:32].hex()))
summary['raw_blocks']=raw
(root/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ('stream_faults','raw_blocks')},indent=2),flush=True)
c=SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
try:
    command="sha256sum /lib/modules/6.1.99/extra/anlogic_pci.ko /root/jpeg_rk/releases/dma_wait_opt_20261021/{source,msi_source,rollback}/anlogic_pci.ko /root/pcie_smoke_demo/vendor_deploy/sgdma_drv/anlogic_pci.ko; cat /sys/module/anlogic_pci/srcversion; modinfo -F srcversion /lib/modules/6.1.99/extra/anlogic_pci.ko"
    _,out,err=c.client.exec_command(command,timeout=15)
    hashes=out.read().decode()+err.read().decode()
    (root/'driver_hashes.txt').write_text(hashes,encoding='utf-8')
    print(hashes,flush=True)
    dest=root/'driver';dest.mkdir(exist_ok=True)
    with c.client.open_sftp() as sftp:
        paths=['/root/jpeg_rk/releases/dma_wait_opt_20261021/source','/root/jpeg_rk/releases/dma_wait_opt_20261021/msi_source','/root/pcie_smoke_demo/vendor_deploy/sgdma_drv']
        for base in paths:
            label='vendor' if 'vendor_deploy' in base else base.rsplit('/',1)[1]
            for name in ('anlogic_pci_lib.c','cdev_sgdma.c','Makefile','anlogic_pci.h'):
                try:sftp.get(base+'/'+name,str(dest/(label+'_'+name)))
                except OSError as exc:print(label,name,str(exc))
finally:c.close()
