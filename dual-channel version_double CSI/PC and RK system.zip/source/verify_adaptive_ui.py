"""Render adaptive telemetry using a previously recorded board snapshot."""
import copy
import json
import os
from pathlib import Path

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
from PySide6.QtWidgets import QApplication
from app import Window

root = Path(__file__).resolve().parent
samples = json.loads((root/'adaptive_policy_20261029/default_off/runtime_samples.json').read_text())
status = copy.deepcopy(samples[-1]['status'])
live = status['live']
live['decoded_quality'] = [60, 60]
live['adaptive'] = dict(enabled=True, qf_control='shared', cameras=[
    dict(state='dark', yolo_limit_fps=5), dict(state='normal', yolo_limit_fps=None)])
live['yolo']['fps'] = [4.8, 49.2]
live['yolo']['enabled'] = [True, True]
app = QApplication.instance() or QApplication([])
window = Window(demo=True)
window.demo = False
window.linked = True
window.worker.submit = lambda *args, **kwargs: None
out = root/'verification/adaptive_qf_20261029/ui'
out.mkdir(parents=True, exist_ok=True)
try:
    window.show()
    for width, height in ((1360,850), (1000,700), (960,680), (1920,1080)):
        window.resize(width,height)
        window.update_status(copy.deepcopy(status))
        app.processEvents()
        assert 'QF 60 ' in window.allocation_labels[0].text()
        assert '4.8 FPS' in window.allocation_labels[0].text()
        assert 'QF 60 ' in window.allocation_labels[1].text()
        for preview, label in zip(window.previews, window.allocation_labels):
            assert preview.rect().contains(label.mapTo(preview,label.rect().topLeft()))
            assert preview.rect().contains(label.mapTo(preview,label.rect().bottomRight()))
            assert label.fontMetrics().horizontalAdvance(label.text()) <= label.width()
        window.grab().save(str(out/f'monitor_{width}.png'))
    window.clear_rates()
    assert all(label.text() == 'QF --  |  YOLO -- FPS' for label in window.allocation_labels)
    print('PASS shared actual QF, YOLO rate, allocation, stale reset and four viewports')
finally:
    window.close()
