"""Capture original FPGA JPEG tiles and verify their DQT tables."""
import json
import shlex
from pathlib import Path
from PIL import Image
from transport import SSHTransport,default_key

BASE=[16,11,10,16,24,40,51,61,12,12,14,19,26,58,60,55,
      14,13,16,24,40,57,69,56,14,17,22,29,51,87,80,62,
      18,22,37,56,68,109,103,77,24,35,55,64,81,104,113,92,
      49,64,78,87,103,121,120,101,72,92,95,98,112,100,103,99]
out=Path('verification/independent_qf_20261031/board_jpeg')
out.mkdir(parents=True,exist_ok=True)
c=SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
before=c.rpc(dict(action='status'))
adaptive=bool((before['live'].get('adaptive') or {}).get('enabled'))
selected=before['live']['selected']
try:
    c.rpc(dict(action='configure',adaptive_enabled=False))
    c.rpc(dict(action='stop'))
    c.rpc(dict(action='configure',quality_a=85,quality_b=30,independent_qf=True))
    remote='/root/dual_vision_host/run/dual_qf_dqt_capture_20261031'
    command=('mkdir -p '+shlex.quote(remote)+'; bundle=$(cat /root/dual_vision_host/bundle.path); '
        'python3 -X faulthandler -u "$bundle/dual_hdmi_bringup.py" --seconds 6 --save-frames 1 '
        '--quiet --connector 188 --out '+shlex.quote(remote))
    _,stdout,stderr=c.client.exec_command(command,timeout=45)
    text=stdout.read().decode(errors='replace');error=stderr.read().decode(errors='replace')
    rc=stdout.channel.recv_exit_status()
    (out/'capture.log').write_text(text+'\n'+error,encoding='utf-8')
    if rc: raise RuntimeError(f'Capture failed: {error[-2000:]}')
    sftp=c.client.open_sftp()
    try:
        for camera in (0,1):
            for tile in range(3):
                name=f'camera_{camera}_1_tile_{tile}.jpg'
                sftp.get(remote+'/'+name,str(out/name))
    finally:sftp.close()
    for camera,quality in ((0,85),(1,30)):
        scale=200-2*quality if quality>=50 else 5000//quality
        expected=[max(1,min(255,((v*scale+50)*1311)>>17)) for v in BASE]
        for tile in range(3):
            path=out/f'camera_{camera}_1_tile_{tile}.jpg'
            with Image.open(path) as image:
                image.load()
                if image.size!=(1920,360) or image.quantization[0]!=expected:
                    raise AssertionError(f'JPEG DQT mismatch: {path}')
        print(f'PASS camera {camera} QF {quality}: 3 original JPEGs decoded, 64 DQT entries matched',flush=True)
finally:
    try:
        c.rpc(dict(action='configure',quality_a=85,quality_b=85,independent_qf=False,adaptive_enabled=adaptive))
        s=c.rpc(dict(action='start',quality=85,display=selected,connector=188))
        print('Restored receiver:',s['runtime'],flush=True)
    finally:c.close()
