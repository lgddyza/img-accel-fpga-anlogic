"""Measure both actual Qt previews alongside board decode and HDMI counters."""
import argparse
import json
from pathlib import Path
import time

from PySide6.QtCore import QTimer
from PySide6.QtGui import QFont, QFontDatabase
from PySide6.QtWidgets import QApplication

from app import Window
from telemetry import redact
from transport import SSHTransport, default_key
from video_preview import Receiver


parser = argparse.ArgumentParser()
parser.add_argument('--seconds', type=int, default=60)
parser.add_argument('--output', type=Path, default=Path('verification/preview30'))
parser.add_argument('--install', action='store_true')
parser.add_argument('--size', type=int, nargs=2, default=(640,360), metavar=('WIDTH','HEIGHT'))
parser.add_argument('--display', type=int, choices=(0,1))
parser.add_argument('--reference', type=Path, help='Matched baseline result.json for the HDMI regression gate')
parser.add_argument('--clients-per-camera', type=int, choices=(1,2))
args = parser.parse_args()
reference = json.loads(args.reference.read_text()) if args.reference else None
args.output.mkdir(parents=True, exist_ok=True)
connection = SSHTransport(dict(host='169.254.53.76', key=str(default_key())))
try:
    before = connection.rpc(dict(action='status'))
    (args.output/'before.json').write_text(json.dumps(redact(before), indent=2))
    if args.install:
        connection.install()
        if before.get('runtime') == 'managed':
            connection.rpc(dict(action='stop'))
    connection.rpc(dict(action='start', quality=(before.get('hardware') or {}).get('applied_quality',85),
        display=args.display if args.display is not None else (before.get('hardware') or {}).get('requested', 1) >> 14 & 1))
finally:
    connection.close()

application = QApplication([])
if not QFontDatabase.families():
    for name in ('msyh.ttc', 'msyhbd.ttc', 'segoeui.ttf'):
        QFontDatabase.addApplicationFont('C:/Windows/Fonts/'+name)
application.setStyle('Fusion')
application.setFont(QFont('Microsoft YaHei UI', 10))
window = Window()
for size in window.preview_sizes:
    size.setCurrentIndex(size.findData(str(args.size[1])))
window.show()
records, first, done = [], None, False
extra_receivers = [None, None]
extra_errors = []
started = time.monotonic()


def snapshot(status):
    return dict(pc_time=time.monotonic(), status=redact(status),
        previews=[dict(received=p.receiver.sequence if p.receiver else 0,
            presented=p.presented, bytes=p.receiver.received_bytes if p.receiver else 0,
            stats=p.stats) for p in window.previews])


def finish(result):
    global done
    done = True
    (args.output/'result.json').write_text(json.dumps(result, indent=2))
    (args.output/'runtime_samples.json').write_text(json.dumps(records, indent=2))
    if result['passed']:
        window.grab().save(str(args.output/'ui_live.png'))
        for camera, preview in enumerate(window.previews):
            preview.canvas.image.save(str(args.output/f'camera_{camera}.png'))
    print(json.dumps(result, indent=2), flush=True)
    for receiver in extra_receivers:
        if receiver:
            receiver.stop()
            receiver.wait(6500)
    window.close()
    application.exit(0 if result['passed'] else 1)


def ready(status):
    global first
    if done:
        return
    live = status.get('live')
    if not live:
        return
    for camera, preview in enumerate(window.previews):
        if preview.receiver is None and not window.busy:
            window.request_preview(camera)
        elif (args.clients_per_camera and preview.receiver and preview.receiver.sequence
                and live['preview']['clients'][camera] < args.clients_per_camera
                and extra_receivers[camera] is None):
            receiver = Receiver(preview.receiver.host, preview.receiver.options)
            receiver.failed.connect(extra_errors.append)
            extra_receivers[camera] = receiver
            receiver.start()
    row = snapshot(status)
    records.append(row)
    if first is None:
        if (time.monotonic()-started >= 5 and all(p.seen >= 40 for p in window.previews)
                and (not args.clients_per_camera or live['preview']['clients'] == [args.clients_per_camera]*2)):
            first = row
            print('Both previews warmed up; measuring', args.seconds, 'seconds', flush=True)
        return
    if row['pc_time']-first['pc_time'] < args.seconds:
        return
    dt = row['pc_time']-first['pc_time']
    a, b = first['status']['live'], live
    board_dt = b['sample_s']-a['sample_s']
    counters_a, counters_b = a['counters'], b['counters']
    delta = lambda name: [y-x for x, y in zip(counters_a[name], counters_b[name])]
    previews = [dict(receive_fps=(end['received']-begin['received'])/dt,
        presented_fps=(end['presented']-begin['presented'])/dt,
        mbps=(end['bytes']-begin['bytes'])*8/dt/1e6,
        width=p.width, height=p.height) for begin, end, p in
        zip(first['previews'], row['previews'], window.previews)]
    decoded = [value/board_dt for value in delta('decoded_frames')]
    display_dt = b['display']['sample_s']-a['display']['sample_s']
    hdmi = (b['display']['rendered']-a['display']['rendered'])/display_dt
    cpu_a, cpu_b = first['status']['resources'], status['resources']
    cpu = 100*(1-(cpu_b['cpu_idle']-cpu_a['cpu_idle'])/(cpu_b['cpu_total']-cpu_a['cpu_total']))
    result = dict(passed=False, seconds=dt, pid=live['pid'], previews=previews,
        decoded_fps=decoded, hdmi_fps=hdmi, cpu_percent=cpu,
        min_available_memory_mb=min(r['status']['resources']['memory_available_mb'] for r in records),
        decode_queue_drops=delta('decode_queue_drops'),
        display_queue_drops=delta('display_queue_drops'),
        jpeg_rejected=delta('decode_rejected_frames'),
        receive_queue_drops=counters_b['queue_drops']-counters_a['queue_drops'],
        preview_error=b['preview'].get('error'),
        preview_frames_delta=[y-x for x, y in zip(a['preview']['frames'], b['preview']['frames'])],
        preview_replaced_delta=[y-x for x, y in zip(a['preview'].get('replaced', [0,0]),
            b['preview'].get('replaced', [0,0]))],
        packet_discarded_delta=[y['discarded_bytes']-x['discarded_bytes']
            for x, y in zip(a['packet_streams'], b['packet_streams'])])
    result['yolo_fps']=[(y-x)/board_dt for x,y in zip(a['yolo']['completed'],b['yolo']['completed'])]
    result['yolo_error']=b['yolo'].get('error')
    result['sd_error']=(b.get('detection_log') or {}).get('error')
    result['sd_saved_delta']=(b.get('detection_log') or {}).get('saved',0)-(a.get('detection_log') or {}).get('saved',0)
    result['preview_encode_mean_ms']=[(y-x)/max(1,n)/1000 for x,y,n in zip(a['preview']['encode_us'],b['preview']['encode_us'],result['preview_frames_delta'])]
    result['hdmi_camera'] = b['selected']
    result['extra_preview_errors'] = extra_errors
    result['preview_clients'] = b['preview']['clients']
    result['display_path'] = {name:b['display'].get(name,0)-a['display'].get(name,0)
        for name in ('rendered','convert_frames','queue_overrun_events',
                     'present_queue_overrun_events','sink_dropped','sink_arrivals')}
    result['display_path']['converted_minus_rendered'] = result['display_path']['convert_frames']-result['display_path']['rendered']
    result['display_path']['probe_backend'] = b['display'].get('probe_backend','python')
    measured = [r['status']['live'] for r in records if r['pc_time'] >= first['pc_time']]
    result['preprocessing_modes_seen'] = sorted({tuple(v.get('decoded_modes',[])) for v in measured})
    result['quality_seen'] = sorted({r['status']['hardware']['applied_quality'] for r in records
                                    if r['pc_time'] >= first['pc_time']})
    result['display_path']['present_queue_capacity'] = b['display'].get('present_queue_capacity')
    ages = [v['display'].get('submit_to_sink_ms_p50') for v in measured]
    ages = [v for v in ages if v is not None]
    result['display_path']['window_p50_age_ms_mean'] = sum(ages)/len(ages) if ages else None
    ages95 = [v['display'].get('submit_to_sink_ms_p95') for v in measured]
    result['display_path']['window_p95_age_ms_max'] = max((v for v in ages95 if v is not None), default=None)
    if reference:
        result['hdmi_reference_fps'] = reference['hdmi_fps']
        result['hdmi_delta_fps'] = hdmi-reference['hdmi_fps']
        result['hdmi_regression_passed'] = result['hdmi_delta_fps'] >= -.1
    result['passed'] = (a['pid'] == b['pid'] and all(p['presented_fps'] >= 28 for p in previews)
        and all((p['width'],p['height']) == tuple(args.size) for p in previews)
        and all(fps >= 59 for fps in decoded) and hdmi >= 58.5
        and not any(result['decode_queue_drops']+result['jpeg_rejected']
            +result['packet_discarded_delta']) and not result['receive_queue_drops']
        and not result['preview_error'] and not result['yolo_error'] and not result['sd_error']
        and result.get('hdmi_regression_passed', True) and not extra_errors)
    finish(result)


def timeout():
    if not done:
        finish(dict(passed=False, error='Timed out', notice=window.notice.text(),
            events=window.events.toPlainText()))


window.worker.status.connect(ready)
QTimer.singleShot(200, window.toggle_connect)
QTimer.singleShot((args.seconds+45)*1000, timeout)
raise SystemExit(application.exec())
