"""Exercise independent QF on the active receiver and restore its settings."""
import json
import time
from pathlib import Path
from transport import SSHTransport, default_key
from telemetry import redact

out = Path('verification/independent_qf_20261031')
out.mkdir(parents=True, exist_ok=True)
c = SSHTransport(dict(host='169.254.53.76', key=str(default_key())))
records = []
before = c.rpc(dict(action='status'))
assert before['runtime'] == 'managed' and before['hardware'].get('dual_qf_supported')
initial = before['hardware']['dual_qf']
adaptive = bool((before['live'].get('adaptive') or {}).get('enabled'))
try:
    c.rpc(dict(action='configure',adaptive_enabled=False))
    phases = [
        ('shared_85', dict(quality_a=85, quality_b=85, independent_qf=False)),
        ('a85_b30', dict(quality_a=85, quality_b=30, independent_qf=True)),
        ('a30_b85', dict(quality_a=30, quality_b=85, independent_qf=True)),
        ('a65_b65', dict(quality_a=65, quality_b=65, independent_qf=True)),
        ('shared_85_again', dict(quality_a=85, quality_b=30, independent_qf=False)),
    ]
    for name, config in phases:
        c.rpc(dict(action='configure',**config))
        time.sleep(3)
        samples=[]
        for _ in range(9):
            s=c.rpc(dict(action='status'))
            if s['runtime']!='managed': raise RuntimeError('Receiver is not running')
            samples.append(s)
            time.sleep(1)
        a,b=samples[0]['live'],samples[-1]['live']
        dt=b['sample_s']-a['sample_s']
        delta=lambda key:[y-x for x,y in zip(a['counters'][key],b['counters'][key])]
        display_a=a.get('display') or {};display_b=b.get('display') or {}
        rendered=((display_b['rendered']-display_a['rendered'])/dt
                  if 'rendered' in display_a and 'rendered' in display_b else None)
        report=dict(phase=name,requested=config,seconds=dt,
            register=b['board']['configuration'].get('dual_qf'),
            quality=b.get('decoded_quality'),
            observed_quality=sorted({tuple(s['live'].get('decoded_quality') or []) for s in samples}),
            decode_fps=[x/dt for x in delta('decoded_frames')],
            submitted_fps=[x/dt for x in delta('submitted_hdmi')],rendered_fps=rendered,
            decode_queue_drops=delta('decode_queue_drops'),display_queue_drops=delta('display_queue_drops'),
            decode_rejected=delta('decode_rejected_frames'),
            fpga_stats_delta=[(y-x)&0xffffffff for x,y in zip(a['board']['statistics'][:7],b['board']['statistics'][:7])],
            dma_mbps=b['rates']['dma_mbps'], yolo_fps=(b.get('yolo') or {}).get('fps'),
            errors=dict(jpeg=b['board'].get('jpeg_errors'),dma=b['counters']['dma_errors'],decode=b['counters']['decode_errors']))
        records.append(dict(report=report,samples=[redact(s) for s in samples]))
        print(json.dumps(report,ensure_ascii=False),flush=True)
finally:
    try:
        c.rpc(dict(action='configure',quality_a=initial&127,quality_b=(initial>>8)&127,independent_qf=bool(initial&(1<<16))))
        c.rpc(dict(action='configure',adaptive_enabled=adaptive))
    finally:
        (out/'results.json').write_text(json.dumps(records,indent=2,ensure_ascii=False),encoding='utf-8')
        c.close()
