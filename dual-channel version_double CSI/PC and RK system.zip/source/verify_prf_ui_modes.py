"""Exercise PRF1 mode selection through the real Qt application and RK."""
import json
from pathlib import Path
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication
from app import Window

out = Path('verification/prf1_board_20261027/ui_modes.json')
app = QApplication([])
window = Window()
window.show()
state = {'phase':'connect', 'events':[]}

def fail(action, message):
    out.write_text(json.dumps({'passed':False,'action':action,'error':message,'events':state['events']},indent=2),encoding='utf-8')
    window.close()
    app.exit(1)

def record(phase, live):
    state['events'].append({'phase':phase,'decoded_modes':live.get('decoded_modes'),
        'osd':(live.get('display') or {}).get('osd_text')})
    print(phase, state['events'][-1], flush=True)

def status_changed(status):
    live = status.get('live') or {}
    if not live or window.busy:
        return
    phase = state['phase']
    if phase == 'connect':
        if not all(window.mode_boxes[i].model().item(j).isEnabled() for i in (0,1) for j in (0,1,5)):
            return fail('capabilities','PRF1 modes disabled')
        state['phase']='mixed'
        window.mode_boxes[0].setCurrentIndex(1)
        window.mode_boxes[1].setCurrentIndex(5)
        window.apply_button.click()
    elif phase == 'mixed' and live.get('decoded_modes') == [1,5]:
        record('ui_mixed_applied',live)
        state['phase']='gray'
        window.mode_boxes[0].setCurrentIndex(0)
        window.mode_boxes[1].setCurrentIndex(0)
        window.apply_button.click()
    elif phase == 'gray' and live.get('decoded_modes') == [0,0]:
        record('ui_gray_restored',live)
        state['phase']='done'
        out.write_text(json.dumps({'passed':True,'events':state['events']},indent=2),encoding='utf-8')
        window.close()
        app.quit()

window.worker.status.connect(status_changed)
window.worker.error.connect(fail)
QTimer.singleShot(200,window.toggle_connect)
QTimer.singleShot(45000,lambda:fail('timeout',state['phase']) if state['phase']!='done' else None)
raise SystemExit(app.exec())
