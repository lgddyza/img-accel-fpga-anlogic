"""Restore the previously validated package and retain the active board settings."""
from pathlib import Path
import time
import legacy_transport
from transport import SSHTransport, default_key

root = Path(__file__).resolve().parent
assets = root/'dist_features'/'RKDualVisionHost'/'_internal'
c = SSHTransport(dict(host='169.254.53.76', key=str(default_key())))
try:
    before = c.rpc(dict(action='status'))
    live = before['live']
    quality = before['hardware']['applied_quality']
    selected = live['selected']
    yolo = live['yolo']
    c.rpc(dict(action='configure', adaptive_enabled=False))
    c.rpc(dict(action='stop'))
    legacy_transport.asset = lambda name: assets/name
    c.install()
    c.rpc(dict(action='start',quality=quality,display=selected))
    time.sleep(3)
    after = c.rpc(dict(action='status'))
    assert after['live']['yolo']['enabled'] == yolo['enabled']
    assert after['live']['yolo']['confidence'] == yolo['confidence']
    assert after['hardware']['applied_quality'] == quality
    assert after['live']['selected'] == selected
    assert after['hardware']['requested'] == before['hardware']['requested']
    assert not after['live']['yolo']['error'] and not after['live']['preview']['error']
    print('Restored previous package; QF, modes, display and YOLO settings retained.')
finally:
    c.close()
