"""Measure live shared QF transitions and restore the original setting."""
import json
import sys
import time
from pathlib import Path
from telemetry import redact
from transport import SSHTransport, default_key

c = SSHTransport(dict(host='169.254.53.76', key=str(default_key())))
before = c.rpc(dict(action='status'))
quality = before['hardware']['applied_quality']
low = int(sys.argv[1]) if len(sys.argv) > 1 else 25
assert before['runtime'] == 'managed' and 1 <= low < quality
samples = []
try:
    for phase, target in [('baseline', None), ('lower', low), ('restore', quality)]:
        if target is not None:
            start = time.monotonic()
            c.rpc(dict(action='configure',quality=target))
            print(phase, 'control_seconds', round(time.monotonic()-start,3), flush=True)
        for _ in range(8):
            samples.append(dict(phase=phase,status=redact(c.rpc(dict(action='status')))))
            time.sleep(1)
finally:
    c.rpc(dict(action='configure',quality=quality))
    out=Path(f'verification/adaptive_qf_20261029/qf_transition_{low}.json')
    out.write_text(json.dumps(samples,indent=2,ensure_ascii=False),encoding='utf-8')
    c.close()
for phase in ('baseline','lower','restore'):
    subset=[s['status'] for s in samples if s['phase']==phase]
    if len(subset)<2: continue
    a,b=subset[0]['live'],subset[-1]['live']
    dt=b['sample_s']-a['sample_s']
    print(phase, 'seconds',round(dt,2),'qf',subset[-1]['hardware']['applied_quality'],
          'hdmi_fps',round((b['display']['rendered']-a['display']['rendered'])/dt,3),
          'decode_drops',[y-x for x,y in zip(a['counters']['decode_queue_drops'],b['counters']['decode_queue_drops'])],flush=True)
