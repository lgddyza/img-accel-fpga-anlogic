"""Temporarily run the candidate and restore the board's original release."""
import json
import time
from pathlib import Path
from transport import SSHTransport, default_key
from telemetry import redact

out = Path('verification/adaptive_qf_20261029')
out.mkdir(parents=True, exist_ok=True)
c = SSHTransport(dict(host='169.254.53.76', key=str(default_key())))
root = '/root/dual_vision_host/'
files = ['board_agent.py', 'bundle.path', 'run/yolo.json']
saved = {}
samples = []
before = c.rpc(dict(action='status'))
assert before['runtime'] == 'managed' and before['hardware']['stream_diagnostics']['build'] == '0x434c4136'
quality = before['hardware']['applied_quality']
selected = before['live']['selected']
with c.client.open_sftp() as sftp:
    for name in files:
        with sftp.open(root+name, 'rb') as f:
            saved[name] = f.read()
        (out/('backup_'+name.replace('/', '_'))).write_bytes(saved[name])
try:
    c.rpc(dict(action='stop'))
    c.install()
    c.rpc(dict(action='configure', adaptive_enabled=True))
    c.rpc(dict(action='start', quality=quality, display=selected))
    time.sleep(5)
    for _ in range(26):
        samples.append(redact(c.rpc(dict(action='status'))))
        time.sleep(1)
    a, b = samples[0]['live'], samples[-1]['live']
    dt = b['sample_s']-a['sample_s']
    rate = lambda key: [(y-x)/dt for x,y in zip(a['counters'][key],b['counters'][key])]
    print(json.dumps(dict(seconds=dt, hdmi=(b['display']['rendered']-a['display']['rendered'])/dt,
        decoded=rate('decoded_frames'), yolo=b['yolo']['fps'], adaptive=b.get('adaptive'),
        decode_drops=[y-x for x,y in zip(a['counters']['decode_queue_drops'],b['counters']['decode_queue_drops'])],
        errors=b['yolo']['error']), ensure_ascii=False), flush=True)
finally:
    try:
        c.rpc(dict(action='stop'))
    finally:
        with c.client.open_sftp() as sftp:
            for name in files:
                with sftp.open(root+name+'.restore', 'wb') as f:
                    f.write(saved[name])
                sftp.posix_rename(root+name+'.restore', root+name)
        c.rpc(dict(action='start', quality=quality, display=selected))
        time.sleep(3)
        after = c.rpc(dict(action='status'))
        assert after['runtime'] == 'managed' and after['hardware']['applied_quality'] == quality
        assert after['live']['yolo']['enabled'] == before['live']['yolo']['enabled']
        assert after['live']['selected'] == selected
        print('RESTORED', flush=True)
        (out/'candidate_samples.json').write_text(json.dumps(samples,indent=2,ensure_ascii=False),encoding='utf-8')
        c.close()
