"""Collect real sink throughput/cadence without opening a second DMA reader."""
import argparse
import json
from pathlib import Path
import time
from transport import SSHTransport, default_key
from telemetry import redact

p = argparse.ArgumentParser()
p.add_argument('--install', action='store_true')
p.add_argument('--restart', action='store_true')
p.add_argument('--seconds', type=int, default=20)
p.add_argument('--camera', type=int, default=1)
p.add_argument('--osd', choices=('on','off'))
p.add_argument('--out', default='verification/hdmi_baseline.json')
a = p.parse_args()
c = SSHTransport(dict(host='169.254.53.76', key=str(default_key())))
records = []
try:
    if a.install:
        c.install()
    if a.restart:
        c.rpc(dict(action='stop'))
    c.rpc(dict(action='start', display=a.camera, quality=85, connector=188))
    if a.osd:
        c.rpc(dict(action='configure',osd=a.osd=='on'))
    for _ in range(a.seconds):
        s = redact(c.rpc(dict(action='status')))
        records.append(s)
        live = s.get('live') or {}
        print(json.dumps(dict(t=live.get('elapsed'),rates=live.get('rates'),display=live.get('display'))),flush=True)
        time.sleep(1)
finally:
    c.close()
    dest = Path(a.out)
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(records,indent=2),encoding='utf-8')
