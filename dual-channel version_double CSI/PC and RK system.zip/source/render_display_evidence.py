"""Render the Y plane of the actual NV12 sink sample for the report."""
from pathlib import Path
from PIL import Image

base=Path('verification/hdmi_osd')
data=(base/'hdmi_snapshot.nv12').read_bytes()
assert len(data)==1920*1080*3//2
image=Image.frombytes('L',(1920,1080),data[:1920*1080])
image=image.point([max(0,min(255,round((v-16)*255/219))) for v in range(256)])
image.save(base/'hdmi_osd.png')
image.crop((0,0,720,200)).save(base/'hdmi_osd_detail.png')
print(base.resolve()/'hdmi_osd.png')
