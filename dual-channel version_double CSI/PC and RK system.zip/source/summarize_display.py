"""Summarize preserved measurements and hashes for this HDMI revision."""
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent
records=json.loads((root/'verification/hdmi_baseline.json').read_text())
first,last=records[2]['live'],records[-1]['live']
elapsed=last['display']['sample_s']-first['display']['sample_s']
baseline=dict(seconds=elapsed,rendered_fps=(last['display']['rendered']-first['display']['rendered'])/elapsed,
    submitted_fps=sum(b-a for a,b in zip(first['counters']['submitted_hdmi'],last['counters']['submitted_hdmi']))/(last['sample_s']-first['sample_s']),
    gap_p50_ms=last['display']['sink_gap_ms_p50'])
records=json.loads((root/'verification/hdmi_exe_final/runtime_samples.json').read_text())
# Exclude the first three seconds of preview subscriber startup.
running=[s for s in records if s.get('live')]
start=running[0]['sample_s']+3
running=[s for s in running if s['sample_s']>=start]
first,last=running[0],running[-1]
l0,l1=first['live'],last['live']
d0,d1=l0['display'],l1['display']
dt=d1['sample_s']-d0['sample_s']
cpu0,cpu1=first['resources'],last['resources']
cpu=100*(1-(cpu1['cpu_idle']-cpu0['cpu_idle'])/(cpu1['cpu_total']-cpu0['cpu_total']))
final=dict(seconds=dt,rendered_fps=(d1['rendered']-d0['rendered'])/dt,
    decoded_fps=[(b-a)/(l1['sample_s']-l0['sample_s']) for a,b in zip(l0['counters']['decoded_frames'],l1['counters']['decoded_frames'])],
    sink_dropped=d1['sink_dropped']-d0['sink_dropped'],
    queue_overrun_events=d1['queue_overrun_events']-d0['queue_overrun_events'],
    present_queue_overrun_events=d1['present_queue_overrun_events']-d0['present_queue_overrun_events'],
    sink_gap_ms_p50=d1['sink_gap_ms_p50'],sink_gap_ms_p95=d1['sink_gap_ms_p95'],
    sink_gap_ms_max=d1['sink_gap_ms_max'],cpu_percent=cpu,
    jpeg_rejected=[b-a for a,b in zip(l0['counters']['decode_rejected_frames'],l1['counters']['decode_rejected_frames'])],
    c2h_discarded_bytes=[b['discarded_bytes']-a['discarded_bytes'] for a,b in zip(l0['packet_streams'],l1['packet_streams'])],
    last_repeated_source_ids_5s=d1['sink_repeated_source_ids_5s'],last_source_gaps_5s=d1['sink_source_gaps_5s'])
files=['dist/RKDualVisionHost/RKDualVisionHost.exe','rk_payload.zip','board_agent.py',
    'rk/dual_hdmi_bringup.py','rk/rk_dual_display.c','rk/libgstrkdualdisplay.so','rk/display_push.py']
summary=dict(baseline=baseline,final_packaged_exe_both_previews=final,
    hashes={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in files},
    osd_comparison=json.loads((root/'verification/hdmi_osd_final/summary.json').read_text()))
(root/'verification/hdmi_osd_final/build_and_results.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
