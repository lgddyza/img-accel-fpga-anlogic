"""Dual IMX415 workstation using the original host's Qt/SSH/MJPEG components."""
import argparse
import base64
import csv
from datetime import datetime
from collections import deque
import json
import math
import os
from pathlib import Path
import queue
import threading
import tempfile
import time
import zipfile

from PySide6.QtCore import Qt, QThread, QTimer, QSettings, Signal, QSignalBlocker
from PySide6.QtGui import QFont,QFontDatabase,QImage,QPixmap
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,
    QFormLayout,QLabel,QPushButton,QComboBox,QLineEdit,QSpinBox,
    QButtonGroup,QProgressBar,QPlainTextEdit,QTabWidget,QTableWidget,QTableWidgetItem,
    QHeaderView,QFileDialog,QScrollArea,QStyle,QCheckBox,QGridLayout)
from serial.tools import list_ports
from transport import SSHTransport,SerialTransport,default_key,provision_key
from telemetry import Rates,redact,pcie_capacity_mbps
from video_preview import VideoPreview,Canvas,tool_icon

MODES = {0:'灰度',1:'3×3 高斯',2:'CLAHE',3:'高斯 + CLAHE',4:'Sobel 边缘增强',5:'方向筛选黑帽'}


class Worker(QThread):
    status = Signal(dict)
    completed = Signal(str,dict)
    error = Signal(str,str)
    linked = Signal(bool)
    busy = Signal(bool)

    def __init__(self):
        super().__init__()
        self.tasks = queue.Queue(maxsize=8)
        self.stopping = threading.Event()
        self.connection = None

    def submit(self,action,payload=None):
        try:
            self.tasks.put_nowait((action,payload or {}))
        except queue.Full:
            self.error.emit(action,'操作队列已满')

    def disconnect(self):
        if self.connection:
            self.connection.close()
            self.connection = None
        self.linked.emit(False)

    def run(self):
        next_poll,failures = 0,0
        try:
            while not self.stopping.is_set():
                try:
                    action,options = self.tasks.get(timeout=.1)
                except queue.Empty:
                    action,options = None,{}
                if action:
                    self.busy.emit(True)
                    try:
                        if action=='connect':
                            self.disconnect()
                            self.connection = SSHTransport(options) if options['kind']=='ssh' else SerialTransport(options)
                            self.connection.install()
                            self.status.emit(self.connection.rpc(dict(action='status')))
                            self.linked.emit(True)
                        elif action=='disconnect':
                            self.disconnect()
                        elif action=='provision':
                            self.disconnect()
                            provision_key(options['port'],options['baud'])
                            self.completed.emit(action,{})
                        elif action=='detection_export' and self.connection:
                            missing=[];written=0
                            with zipfile.ZipFile(options['path'],'w',zipfile.ZIP_DEFLATED) as archive:
                                for ident in options['ids']:
                                    data=self.connection.rpc(dict(action='detection_detail',id=ident))
                                    if data.get('missing'):missing.append(ident);continue
                                    archive.writestr(f'{ident}.jpg',base64.b64decode(data['jpeg']))
                                    archive.writestr(f'{ident}.json',json.dumps(data['event'],ensure_ascii=False,indent=2))
                                    written+=1
                                archive.writestr('manifest.json',json.dumps(dict(written=written,missing=missing),indent=2))
                            self.completed.emit(action,dict(written=written,missing=missing))
                        elif action in ('sd_preview','sd_download') and self.connection:
                            offset=0;contents=bytearray();tmp=None
                            try:
                                if action=='sd_download':
                                    fd,tmp=tempfile.mkstemp(prefix='.sd_download_',dir=str(Path(options['destination']).parent))
                                    output=os.fdopen(fd,'wb')
                                else:output=None
                                try:
                                    while True:
                                        part=self.connection.rpc(dict(action='sd_chunk',path=options['path'],offset=offset,length=49152))
                                        size=part['size']
                                        if action=='sd_preview' and size>4*1024*1024:raise ValueError('文件超过 4 MB，请下载后查看')
                                        block=base64.b64decode(part['data']);offset+=len(block)
                                        if output:output.write(block)
                                        else:contents.extend(block)
                                        if offset>=size:break
                                        if not block:raise RuntimeError('文件读取中断')
                                finally:
                                    if output:output.close()
                                if tmp:os.replace(tmp,options['destination']);tmp=None
                                self.completed.emit(action,dict(path=options['path'],data=base64.b64encode(contents).decode('ascii'),size=size,destination=options.get('destination')))
                            finally:
                                if tmp and os.path.exists(tmp):os.unlink(tmp)
                        elif self.connection:
                            result = self.connection.rpc(dict(options,action=action))
                            self.completed.emit(action,result)
                            if action not in ('logs','detection_list','detection_detail','sd_list','sd_chunk'):
                                self.status.emit(result)
                        else:
                            raise RuntimeError('请先连接RK')
                        failures = 0
                    except Exception as exc:
                        self.error.emit(action,str(exc))
                        if action=='connect':
                            self.disconnect()
                    finally:
                        self.busy.emit(False)
                        next_poll = time.monotonic()+1
                if self.connection and time.monotonic()>=next_poll:
                    try:
                        self.status.emit(self.connection.rpc(dict(action='status')))
                        failures = 0
                    except Exception as exc:
                        failures += 1
                        self.error.emit('poll',str(exc))
                        if failures>=3:
                            self.disconnect()
                    next_poll = time.monotonic()+1
        finally:
            self.disconnect()


class Window(QMainWindow):
    def __init__(self,demo=False):
        super().__init__()
        self.setWindowTitle('RK Dual Vision · 双路视觉控制台')
        self.resize(1360,850)
        self.setMinimumSize(960,680)
        self.demo = demo
        self.linked = self.busy = self.rendering = self.dirty = False
        self.current = None
        self.last_received = 0
        self.preview_pending = False
        self.feature_last = [None, None]
        self.yolo_synced_pid = None
        self.settings = QSettings('RKVision','DualPCStation')
        self.rates = Rates()
        self.history = deque(maxlen=20)
        self.worker = Worker()
        self.worker.status.connect(self.update_status)
        self.worker.linked.connect(self.on_link)
        self.worker.busy.connect(self.on_busy)
        self.worker.completed.connect(self.on_complete)
        self.worker.error.connect(self.on_error)
        central = QWidget()
        self.setCentralWidget(central)
        outer = QVBoxLayout(central)
        outer.setContentsMargins(20,16,20,14)
        outer.setSpacing(12)
        heading = QHBoxLayout()
        title = QLabel('双路视觉')
        title.setObjectName('brand')
        heading.addWidget(title)
        subtitle = QLabel('IMX415 × 2   /   RK3576')
        subtitle.setObjectName('muted')
        heading.addWidget(subtitle)
        heading.addStretch()
        self.link_label = QLabel('离线演示' if demo else '未连接')
        self.link_label.setObjectName('connection')
        heading.addWidget(self.link_label)
        outer.addLayout(heading)

        connection = QHBoxLayout()
        self.kind = QComboBox()
        self.kind.addItems(['网口 SSH','串口'])
        self.host = QLineEdit(self.settings.value('host','169.254.53.76'))
        self.host.setMaximumWidth(210)
        self.serial_port = QComboBox()
        self.serial_port.setEditable(True)
        ports = sorted({p.device for p in list_ports.comports()}|{'COM12'})
        self.serial_port.addItems(ports)
        self.serial_port.setCurrentText('COM12')
        self.serial_port.setMaximumWidth(150)
        self.serial_port.hide()
        self.kind.currentIndexChanged.connect(lambda n:(self.host.setVisible(n==0),self.serial_port.setVisible(n==1)))
        self.connect_button = self.button('连接',QStyle.StandardPixmap.SP_DialogApplyButton,self.toggle_connect)
        connection.addWidget(self.kind)
        connection.addWidget(self.host)
        connection.addWidget(self.serial_port)
        connection.addWidget(self.connect_button)
        connection.addStretch()
        self.version = QLabel('FPGA —')
        self.version.setObjectName('muted')
        connection.addWidget(self.version)
        self.export_button = self.button('',QStyle.StandardPixmap.SP_DialogSaveButton,self.export,'导出最近20条状态及操作记录')
        outer.addLayout(connection)

        self.notice = QLabel('等待连接')
        self.notice.setObjectName('notice')
        self.notice.setWordWrap(True)
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.tabBar().setDrawBase(False)
        outer.addWidget(self.tabs,1)
        self.monitor_page = QWidget()
        content = QVBoxLayout(self.monitor_page)
        content.setContentsMargins(14,16,14,10)
        content.setSpacing(16)
        self.tabs.addTab(self.monitor_page,'实时监控')
        tools = QHBoxLayout()
        tools.setSpacing(10)
        content.addLayout(tools)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setMinimumWidth(280)
        scroll.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        sidebar = QWidget()
        sidebar.setMaximumWidth(720)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(24,20,24,20)
        side.setSpacing(18)
        row = QHBoxLayout()
        self.start_button = self.button('启动视频',QStyle.StandardPixmap.SP_MediaPlay,self.start_video)
        self.start_button.setObjectName('primary')
        self.stop_button = self.button('停止',QStyle.StandardPixmap.SP_MediaStop,lambda:self.worker.submit('stop'))
        self.recover_main_button = self.button('恢复 PCIe',QStyle.StandardPixmap.SP_BrowserReload,
            lambda:self.worker.submit('recover'),'视频停止后重新连接 FPGA PCIe')
        self.recover_main_button.hide()
        row.addWidget(self.start_button)
        row.addWidget(self.stop_button)
        row.addWidget(self.recover_main_button)
        tools.addLayout(row)
        self.runtime = QLabel('未启动')
        self.runtime.setObjectName('muted')
        self.monitor_fps = QLabel('HDMI — FPS')
        self.monitor_fps.setObjectName('inlineMetric')
        tools.addWidget(self.monitor_fps)
        route = QHBoxLayout()
        route.setSpacing(10)
        route.addWidget(QLabel('HDMI 输出'))
        segment = QHBoxLayout()
        self.display_buttons = []
        group = QButtonGroup(self)
        group.setExclusive(True)
        for i,name in enumerate(('相机 A','相机 B')):
            button = self.button(name,QStyle.StandardPixmap.SP_ComputerIcon,lambda _=False,c=i:self.select_camera(c))
            button.setCheckable(True)
            group.addButton(button)
            self.display_buttons.append(button)
            segment.addWidget(button)
        route.addLayout(segment)
        self.osd = QCheckBox('HDMI 状态文字')
        self.osd.setChecked(True)
        self.osd.toggled.connect(lambda value: None if self.rendering else
            self.worker.submit('configure',dict(osd=value)))
        route.addStretch()
        route.addWidget(self.osd)
        tools.insertLayout(1,route,1)
        side.addWidget(self.section('JPEG 编码'))
        form = QFormLayout()
        self.quality = QSpinBox()
        self.quality.setRange(1,100)
        self.quality.setValue(85)
        self.quality.setSingleStep(5)
        self.quality.setMaximumWidth(160)
        self.quality.valueChanged.connect(self.mark_dirty)
        form.addRow('相机 A / 共享 QF',self.quality)
        self.independent_qf = QCheckBox('两路独立 QF')
        self.independent_qf.toggled.connect(self.mark_dirty)
        form.addRow(self.independent_qf)
        self.quality_b = QSpinBox()
        self.quality_b.setRange(1,100)
        self.quality_b.setValue(85)
        self.quality_b.setSingleStep(5)
        self.quality_b.setMaximumWidth(160)
        self.quality_b.valueChanged.connect(self.mark_dirty)
        form.addRow('相机 B QF',self.quality_b)
        side.addLayout(form)
        self.applied = QLabel('实际 QF —')
        self.applied.setObjectName('muted')
        side.addWidget(self.applied)
        self.apply_button = self.button('应用参数',QStyle.StandardPixmap.SP_DialogApplyButton,self.apply_config)
        actions = QHBoxLayout()
        actions.addWidget(self.apply_button)
        actions.addStretch()
        side.addLayout(actions)
        side.addWidget(self.section('YOLO 裂缝检测'))
        airow=QHBoxLayout()
        self.yolo_a=QCheckBox('相机 A');self.yolo_b=QCheckBox('相机 B')
        self.yolo_conf=QSpinBox();self.yolo_conf.setRange(1,100);self.yolo_conf.setValue(10);self.yolo_conf.setSuffix('%')
        airow.addWidget(self.yolo_a);airow.addWidget(self.yolo_b);airow.addWidget(QLabel('置信度'));airow.addWidget(self.yolo_conf)
        side.addLayout(airow)
        self.adaptive_enabled=QCheckBox('自适应预处理、QF 和 YOLO')
        self.adaptive_enabled.setToolTip('决策树选择预处理；暗部超过90%的通道限频，QF按暗部比例分档。手动修改预处理后该路暂停自动选择，关闭再开启可恢复。')
        side.addWidget(self.adaptive_enabled)
        self.ai=self.button('应用检测设置',QStyle.StandardPixmap.SP_DialogApplyButton,
            lambda:self.worker.submit('configure',dict(yolo_a=self.yolo_a.isChecked(),yolo_b=self.yolo_b.isChecked(),yolo_confidence=self.yolo_conf.value()/100,adaptive_enabled=self.adaptive_enabled.isChecked())))
        side.addWidget(self.ai)
        self.yolo_state=QLabel('YOLO 尚未启动');self.yolo_state.setWordWrap(True);side.addWidget(self.yolo_state)
        self.adaptive_state=QLabel('自适应：关闭');self.adaptive_state.setWordWrap(True);side.addWidget(self.adaptive_state)
        performance = QWidget()
        performance_content = QVBoxLayout(performance)
        performance_content.setContentsMargins(24,20,24,20)
        performance_content.setSpacing(12)
        performance_content.addWidget(self.runtime)
        performance_content.addWidget(self.section('视频与传输'))
        resource_layout = QVBoxLayout()
        resource_layout.setSpacing(12)
        resource_layout.addWidget(self.section('RK 资源'))
        resource_grid = QGridLayout()
        resource_grid.setHorizontalSpacing(12)
        resource_grid.setVerticalSpacing(8)
        resource_grid.setColumnMinimumWidth(0,110)
        resource_grid.setColumnStretch(1,1)
        self.cpu,self.memory = QProgressBar(),QProgressBar()
        for row,(label,bar) in enumerate((('CPU',self.cpu),('内存',self.memory))):
            bar.setRange(0,1000)
            bar.setFormat('—')
            resource_grid.addWidget(QLabel(label),row,0)
            resource_grid.addWidget(bar,row,1)
        self.npu_grid=resource_grid
        self.npu_bars={}
        self.ensure_npu_core('0')
        self.ensure_npu_core('1')
        resource_layout.addLayout(resource_grid)
        self.temperature = QLabel('温度 —')
        self.temperature.setObjectName('muted')
        resource_layout.addWidget(self.temperature)
        pcie_layout = QVBoxLayout()
        pcie_layout.setSpacing(8)
        pcie_layout.addWidget(self.section('PCIe 接收数据量'))
        self.pcie_link = QLabel('链路状态：—')
        self.pcie_link.setWordWrap(True)
        pcie_layout.addWidget(self.pcie_link)
        pcie_grid = QGridLayout()
        pcie_grid.setHorizontalSpacing(12)
        pcie_grid.setVerticalSpacing(8)
        pcie_grid.setColumnMinimumWidth(0,110)
        pcie_grid.setColumnStretch(1,1)
        self.pcie_bars = []
        for row,title in enumerate(('C2H 1','C2H 2','C2H 3','合计')):
            bar=QProgressBar();bar.setRange(0,1000);bar.setFormat('—')
            pcie_grid.addWidget(QLabel(title),row,0);pcie_grid.addWidget(bar,row,1)
            self.pcie_bars.append(bar)
        pcie_layout.addLayout(pcie_grid)
        side.addStretch()
        self.recover_button = self.button('重新连接 PCIe',QStyle.StandardPixmap.SP_BrowserReload,
            lambda:self.worker.submit('recover'),'仅在视频停止后重新枚举PCIe')
        scroll.setWidget(sidebar)
        self.tabs.addTab(scroll,'运行参数')
        metrics = QHBoxLayout()
        self.metric_values = []
        for label in ('A 路解码 FPS','B 路解码 FPS','HDMI 渲染 FPS','PCIe 接收 Mbps'):
            band = QVBoxLayout()
            title = QLabel(label)
            title.setObjectName('muted')
            value = QLabel('—')
            value.setObjectName('metric')
            self.metric_values.append(value)
            band.addWidget(title)
            band.addWidget(value)
            metrics.addLayout(band,1)
        performance_content.addLayout(metrics)
        performance_content.addLayout(pcie_layout)
        performance_content.addLayout(resource_layout)
        performance_content.addStretch()
        performance_scroll=QScrollArea()
        performance_scroll.setWidgetResizable(True)
        performance_scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        performance_scroll.setWidget(performance)
        self.tabs.addTab(performance_scroll,'性能状态')
        previews = QHBoxLayout()
        previews.setSpacing(14)
        self.previews = []
        self.preview_sizes = []
        self.feature_values = []
        self.feature_states = []
        self.allocation_labels = []
        self.mode_boxes = []
        self.gauss_boxes = []
        self.mode_mask = None
        for camera in (0,1):
            preview = VideoPreview(camera=camera)
            preview.setMinimumHeight(240)
            preview.requested.connect(lambda c=camera:self.request_preview(c))
            controls = QHBoxLayout()
            controls.addWidget(QLabel('预处理'))
            combo=QComboBox();combo.addItem('等待连接',None)
            combo.activated.connect(lambda _index,c=camera:self.select_mode(c))
            controls.addWidget(combo,1);self.mode_boxes.append(combo)
            controls.addWidget(QLabel('高斯强度'))
            strength=QComboBox()
            for index,name in enumerate(('0','0.25','0.50','0.75','1.00')):
                strength.addItem(name,index)
            strength.setToolTip('原灰度与 3×3 高斯的混合强度；高斯及高斯 + CLAHE 模式生效')
            strength.activated.connect(lambda _index,c=camera:self.select_gaussian(c))
            controls.addWidget(strength);self.gauss_boxes.append(strength)
            preview.layout().insertLayout(1,controls)
            resolution = QHBoxLayout()
            resolution.addWidget(QLabel('预览分辨率'))
            size = QComboBox()
            for label, key in (('640 × 360', '360'), ('960 × 540', '540'), ('1280 × 720', '720')):
                size.addItem(label, key)
            size.setToolTip('每路独立选择；更高分辨率会增加 RK 负载，可能影响 HDMI 帧率')
            size.activated.connect(lambda _index,c=camera:self.change_preview_size(c))
            resolution.addWidget(size)
            resolution.addStretch()
            feature_state = QLabel('特征等待数据')
            feature_state.setObjectName('muted')
            feature_state.setToolTip('FPGA 灰度化之后、增强和 JPEG 之前的稀疏采样统计，约每秒更新；并非识别评分。')
            resolution.addWidget(feature_state)
            self.feature_states.append(feature_state)
            preview.layout().insertLayout(2,resolution)
            features = QGridLayout()
            features.setHorizontalSpacing(6)
            features.setVerticalSpacing(1)
            values = []
            descriptions = (
                ('平均亮度', '采样灰度平均值，范围 0–255。'),
                ('暗部比例', '灰度小于 32 的采样像素比例。'),
                ('亮部比例', '灰度大于 224 的采样像素比例。'),
                ('灰度对比', '16 桶直方图中第 90 百分位与第 10 百分位桶号之差乘以 16，是粗略估计。'),
                ('水平梯度', '采样点与其右侧相邻像素的灰度差绝对值均值，反映空间纹理与边缘，并非运动或噪声评分。'),
            )
            for col, (title, tooltip) in enumerate(descriptions):
                label = QLabel(title)
                label.setObjectName('muted')
                label.setToolTip(tooltip)
                value = QLabel('—')
                value.setToolTip(tooltip)
                features.addWidget(label, 0, col)
                features.addWidget(value, 1, col)
                features.setColumnStretch(col, 1)
                values.append(value)
            self.feature_values.append(values)
            preview.layout().insertLayout(3,features)
            allocation = QLabel('QF --  |  YOLO -- FPS')
            allocation.setWordWrap(True)
            allocation.setToolTip('QF 来自最近解码帧；YOLO 帧率为最近五秒实测；自动预处理为决策树建议，实际模式以预处理选择框及视频帧为准。')
            preview.layout().insertWidget(4,allocation)
            self.allocation_labels.append(allocation)
            self.preview_sizes.append(size)
            self.previews.append(preview)
            previews.addWidget(preview,1)
        content.addLayout(previews,1)
        self.diagnostics = QTableWidget(0,3)
        self.diagnostics.setHorizontalHeaderLabels(['链路指标','相机 A','相机 B'])
        self.diagnostics.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.diagnostics.verticalHeader().hide()
        self.diagnostics.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.diagnostics.setAlternatingRowColors(True)
        self.tabs.addTab(self.diagnostics,'链路诊断')
        detection_page=QWidget(); detection_layout=QVBoxLayout(detection_page)
        filters=QHBoxLayout()
        self.det_camera=QComboBox();self.det_camera.addItems(['全部相机','相机 A','相机 B'])
        self.det_class=QLineEdit();self.det_class.setPlaceholderText('类别名称（可留空）')
        self.det_from=QLineEdit();self.det_from.setPlaceholderText('开始 YYYY-MM-DD HH:MM')
        self.det_to=QLineEdit();self.det_to.setPlaceholderText('结束 YYYY-MM-DD HH:MM')
        self.det_min=QSpinBox();self.det_min.setRange(0,100);self.det_min.setSuffix('%')
        for w in (self.det_camera,self.det_class,self.det_from,self.det_to,QLabel('最低置信度'),self.det_min):filters.addWidget(w)
        filters.addWidget(self.button('筛选',QStyle.StandardPixmap.SP_DialogApplyButton,self.filter_detections))
        filters.addWidget(self.button('刷新',QStyle.StandardPixmap.SP_BrowserReload,lambda:self.worker.submit('detection_list')))
        filters.addWidget(self.button('导出 CSV',QStyle.StandardPixmap.SP_DialogSaveButton,self.export_detections))
        filters.addWidget(self.button('打包图片',QStyle.StandardPixmap.SP_DialogSaveButton,self.export_detection_images))
        detection_layout.addLayout(filters)
        self.det_info=QLabel('最近 40 条检测事件；图片为对应推理帧的缩略图')
        detection_layout.addWidget(self.det_info)
        self.det_runtime=QLabel('日志状态：等待连接')
        detection_layout.addWidget(self.det_runtime)
        det_body=QHBoxLayout();detection_layout.addLayout(det_body,1)
        self.det_table=QTableWidget(0,6)
        self.det_table.setHorizontalHeaderLabels(['时间','相机','类别','最高置信度','模式','帧号'])
        self.det_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.det_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.det_table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.det_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.det_table.itemSelectionChanged.connect(self.select_detection)
        det_body.addWidget(self.det_table,1)
        det_right=QVBoxLayout();det_body.addLayout(det_right,1)
        self.det_canvas=Canvas();self.det_canvas.message='选择记录查看对应检测图';det_right.addWidget(self.det_canvas,1)
        self.det_details=QLabel('');self.det_details.setWordWrap(True);det_right.addWidget(self.det_details)
        self.det_events=[];self.det_filtered=[];self.det_selected=None
        self.tabs.addTab(detection_page,'检测日志')
        self.tabs.currentChanged.connect(lambda index:self.worker.submit('detection_list') if self.tabs.widget(index) is detection_page and self.linked else None)
        sd_page=QWidget();sd_layout=QVBoxLayout(sd_page);sd_tools=QHBoxLayout()
        self.sd_path='';self.sd_entries=[]
        self.sd_label=QLabel('SD 卡：未读取');sd_tools.addWidget(self.sd_label,1)
        sd_tools.addWidget(self.button('上一级',QStyle.StandardPixmap.SP_ArrowUp,self.sd_up))
        sd_tools.addWidget(self.button('刷新',QStyle.StandardPixmap.SP_BrowserReload,self.sd_refresh))
        sd_tools.addWidget(self.button('查看文件',QStyle.StandardPixmap.SP_FileDialogContentsView,self.sd_open))
        sd_tools.addWidget(self.button('下载文件',QStyle.StandardPixmap.SP_DialogSaveButton,self.sd_download))
        sd_tools.addWidget(self.button('检测日志',QStyle.StandardPixmap.SP_FileDialogDetailedView,lambda:self.tabs.setCurrentWidget(detection_page)))
        sd_layout.addLayout(sd_tools);sd_body=QHBoxLayout();sd_layout.addLayout(sd_body,1)
        self.sd_table=QTableWidget(0,3);self.sd_table.setHorizontalHeaderLabels(['名称','类型','大小'])
        self.sd_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.sd_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows);self.sd_table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.sd_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers);self.sd_table.cellDoubleClicked.connect(lambda *_:self.sd_open())
        sd_body.addWidget(self.sd_table,1)
        sd_right=QVBoxLayout();sd_body.addLayout(sd_right,1)
        self.sd_image=QLabel();self.sd_image.setAlignment(Qt.AlignmentFlag.AlignCenter);self.sd_image.setMaximumHeight(350);sd_right.addWidget(self.sd_image)
        self.sd_text=QPlainTextEdit();self.sd_text.setReadOnly(True);self.sd_text.setPlaceholderText('双击文件或选择后点击查看，较大文件可下载');sd_right.addWidget(self.sd_text,1)
        self.tabs.addTab(sd_page,'SD 卡')
        self.tabs.currentChanged.connect(lambda index:self.sd_refresh() if self.tabs.widget(index) is sd_page and self.linked else None)
        logs = QWidget()
        log_layout = QVBoxLayout(logs)
        tools = QHBoxLayout()
        tools.addWidget(self.export_button)
        tools.addStretch()
        tools.addWidget(self.button('',QStyle.StandardPixmap.SP_BrowserReload,lambda:self.worker.submit('logs'),'读取RK运行日志'))
        log_layout.addLayout(tools)
        self.events = QPlainTextEdit()
        self.events.setReadOnly(True)
        self.events.setMaximumBlockCount(1000)
        log_layout.addWidget(self.events)
        self.tabs.addTab(logs,'运行日志')
        settings = QWidget()
        settings_form = QFormLayout(settings)
        settings_form.setContentsMargins(24,20,24,20)
        settings_form.setVerticalSpacing(16)
        self.username = QLineEdit(self.settings.value('username','root'))
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        self.password.setPlaceholderText('留空使用密钥')
        self.key = QLineEdit(str(default_key()))
        self.ssh_port = QSpinBox()
        self.ssh_port.setRange(1,65535)
        self.ssh_port.setValue(22)
        self.baud = QSpinBox()
        self.baud.setRange(9600,3000000)
        self.baud.setValue(1500000)
        self.connector = QSpinBox()
        self.connector.setRange(1,4096)
        self.connector.setValue(188)
        for label,widget in (('SSH 用户',self.username),('SSH 端口',self.ssh_port),('密码',self.password),
                ('SSH 密钥',self.key),('串口波特率',self.baud),('HDMI 连接器',self.connector)):
            settings_form.addRow(label,widget)
        self.provision_button = self.button('配置 SSH 密钥',QStyle.StandardPixmap.SP_DialogApplyButton,
            lambda:self.worker.submit('provision',dict(port=self.serial_port.currentText(),baud=self.baud.value())),
            '通过已登录root的串口追加本机SSH公钥')
        settings_form.addRow(self.provision_button)
        settings_form.addRow('PCIe 维护',self.recover_button)
        self.tabs.addTab(settings,'连接设置')
        outer.addWidget(self.notice)
        self.setStyleSheet(STYLE)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.check_stale)
        self.timer.start(1000)
        self.update_enabled()
        self.worker.start()

    def section(self,text):
        label = QLabel(text)
        label.setObjectName('sectionTitle')
        return label

    def ensure_npu_core(self,core):
        if core not in self.npu_bars:
            row=2+len(self.npu_bars)
            bar=QProgressBar();bar.setRange(0,1000);bar.setFormat('—')
            self.npu_grid.addWidget(QLabel('NPU Core '+core),row,0)
            self.npu_grid.addWidget(bar,row,1)
            self.npu_bars[core]=bar
        return self.npu_bars[core]

    def button(self,text,icon,callback,tooltip=None):
        button = QPushButton(text)
        button.setIcon(tool_icon(self,icon))
        button.setMinimumHeight(32)
        button.clicked.connect(callback)
        if tooltip:
            button.setToolTip(tooltip)
        return button

    def mark_dirty(self,*_):
        if not self.rendering:
            self.dirty = True

    def toggle_connect(self):
        if self.demo:
            return
        if self.linked:
            self.worker.submit('disconnect')
            return
        self.settings.setValue('host',self.host.text().strip())
        self.settings.setValue('username',self.username.text().strip())
        self.worker.submit('connect',dict(kind='ssh' if self.kind.currentIndex()==0 else 'serial',
            host=self.host.text().strip(),ssh_port=self.ssh_port.value(),username=self.username.text().strip(),
            password=self.password.text(),key=self.key.text().strip(),port=self.serial_port.currentText(),baud=self.baud.value()))

    def on_link(self,value):
        self.linked = value
        self.connect_button.setText('断开' if value else '连接')
        self.connect_button.setIcon(tool_icon(self,QStyle.StandardPixmap.SP_DialogCloseButton
            if value else QStyle.StandardPixmap.SP_DialogApplyButton))
        self.link_label.setText('已连接 · '+self.host.text() if value else '未连接')
        if not value:
            for preview in self.previews:
                preview.stop()
            self.rates = Rates()
            self.clear_rates()
        self.update_enabled()

    def on_busy(self,value):
        self.busy = value
        self.update_enabled()

    def update_enabled(self):
        enabled = self.linked and not self.busy and not self.demo and time.monotonic()-self.last_received<5
        self.connect_button.setEnabled(not self.busy and not self.demo)
        self.provision_button.setEnabled(not self.busy and not self.demo)
        for widget in (self.host,self.kind,self.serial_port,self.username,self.password,self.key,self.ssh_port,self.baud):
            widget.setEnabled(not self.linked and not self.busy)
        for widget in (self.start_button,self.stop_button,self.apply_button,self.recover_button,self.osd,self.ai,*self.display_buttons):
            widget.setEnabled(enabled)
        for preview in self.previews:
            preview.start_button.setEnabled(enabled and preview.receiver is None and
                bool(self.current and self.current.get('live',{})))
        hardware=(self.current or {}).get('hardware') or {}
        for camera,combo in enumerate(self.mode_boxes):
            combo.setEnabled(enabled and bool(hardware.get('supported_modes')))
            self.gauss_boxes[camera].setEnabled(enabled and combo.currentData() in (1,3) and
                hardware.get('gaussian_strength') is not None)
        if self.current:
            self.start_button.setEnabled(enabled and bool(hardware) and not self.current.get('processes'))
            self.stop_button.setEnabled(enabled and bool(self.current.get('processes')))
            self.recover_button.setEnabled(enabled and not self.current.get('processes'))
        self.recover_main_button.setVisible(bool(self.linked and self.current and
            self.current.get('hardware_error') and not self.current.get('processes')))
        self.recover_main_button.setEnabled(enabled and bool(self.current) and not self.current.get('processes'))

    def selected(self):
        return 0 if self.display_buttons[0].isChecked() else 1

    def start_video(self):
        self.worker.submit('start',dict(quality=self.quality.value(),display=self.selected(),connector=self.connector.value()))

    def select_camera(self,camera):
        self.worker.submit('configure',dict(display=camera))

    def apply_config(self):
        if self.independent_qf.isEnabled():
            request=dict(quality_a=self.quality.value(),quality_b=self.quality_b.value(),independent_qf=self.independent_qf.isChecked())
        else:
            request=dict(quality=self.quality.value())
        self.worker.submit('configure',request)

    def select_mode(self,camera):
        mode=self.mode_boxes[camera].currentData()
        if mode is not None:
            self.worker.submit('configure',{'mode_'+('a','b')[camera]:mode})

    def select_gaussian(self,camera):
        self.worker.submit('configure',{'gauss_'+('a','b')[camera]:self.gauss_boxes[camera].currentData()})

    def request_preview(self,camera):
        live = (self.current or {}).get('live') or {}
        info = live.get('preview') or {}
        if not info.get('token'):
            self.log('预览尚未就绪，请先启动双路显示')
            return
        size = self.preview_sizes[camera].currentData()
        self.previews[camera].start(self.host.text().strip(),dict(info,path=f'/stream/{camera}?size={size}',pid=live['pid']))

    def change_preview_size(self,camera):
        if self.previews[camera].receiver:
            self.request_preview(camera)

    def update_features(self, observations):
        now = time.monotonic()
        for camera, name in enumerate(('camera_a', 'camera_b')):
            obs = (observations or {}).get(name) or {}
            features = obs.get('features') or {}
            keys = ('mean', 'dark_fraction', 'bright_fraction', 'hist_contrast', 'gradient_mean')
            valid = (obs.get('valid') is True and obs.get('camera') == camera and
                     all(isinstance(features.get(k), (int, float)) and math.isfinite(features[k]) for k in keys))
            if valid:
                identity = (obs.get('epoch'), obs.get('sequence'), obs.get('frame_id'))
                previous = self.feature_last[camera]
                if previous is None or identity != previous[0]:
                    self.feature_last[camera] = (identity, now)
                valid = now - self.feature_last[camera][1] <= 5
            if valid:
                text = (f"{features['mean']:.1f}", f"{features['dark_fraction']*100:.1f}%",
                        f"{features['bright_fraction']*100:.1f}%", f"{features['hist_contrast']:.0f}",
                        f"{features['gradient_mean']:.2f}")
                errors = obs.get('errors', 0)
                self.feature_states[camera].setText('特征实时' if not errors else f'特征实时 · 错误 {errors}')
            else:
                text = ('—',) * len(keys)
                self.feature_states[camera].setText('特征未更新' if obs.get('valid') is True else '特征等待数据')
            for label, value in zip(self.feature_values[camera], text):
                label.setText(value)

    def update_status(self,status):
        self.last_received = time.monotonic()
        previous_pid = ((self.current or {}).get('live') or {}).get('pid')
        next_pid = (status.get('live') or {}).get('pid')
        if previous_pid != next_pid:
            for preview in self.previews:
                if preview.receiver:
                    preview.stop()
        self.current = status
        log_state=(status.get('live') or {}).get('detection_log') or {}
        self.det_runtime.setText('日志状态：'+(f"已保存 {log_state.get('saved',0)}，队列丢弃 {log_state.get('dropped',0)}" +
            (f"，错误：{log_state['error']}" if log_state.get('error') else '') if log_state else '等待视频启动'))
        self.history.append(redact(status))
        rates = self.rates.update(status)
        hw,live = status.get('hardware') or {},status.get('live') or {}
        self.update_features(hw.get('feature_observations'))
        software = live.get('rates') or {}
        decoded = software.get('decoded',[None,None])
        hdmi = software.get('hdmi_submitted',[None,None])
        dma = software.get('dma_mbps',[None]*3)
        display = live.get('display') or {}
        ai = live.get('yolo') or {}
        adaptive = live.get('adaptive') or {}
        ai_fps=ai.get('fps',[0,0]);ai_results=ai.get('results',[None,None])
        modes=live.get('decoded_modes') or [None,None]
        enabled=ai.get('enabled',[False,False])
        if ai and next_pid != self.yolo_synced_pid:
            self.yolo_a.setChecked(enabled[0]);self.yolo_b.setChecked(enabled[1])
            self.yolo_conf.setValue(round(ai.get('confidence',.1)*100))
            self.adaptive_enabled.setChecked(bool(adaptive.get('enabled')))
            self.yolo_synced_pid=next_pid
        state_names={'off':'关闭','waiting':'观测不可用','normal':'正常','dark':'暗部超90% · 限频 5 FPS'}
        cameras=adaptive.get('cameras') or []
        shared=adaptive.get('shared_qf') or {}
        qf_state=('共享 QF 自动调整' if shared.get('target') else '共享 QF 保持手动值')
        if shared.get('manual_override'):qf_state='共享 QF 已手动调整'
        if adaptive.get('qf_control')=='independent':
            controllers=adaptive.get('independent_qf') or []
            qf_state='独立 QF：'+'，'.join(f"{'AB'[i]} " + ('手动' if c.get('manual_override') else str(c.get('target') or '保持')) for i,c in enumerate(controllers[:2]))
        self.adaptive_state.setText('自适应：' + ('  |  '.join(f"{'AB'[i]}: {state_names.get(v.get('state'),'未知')}" for i,v in enumerate(cameras[:2])) if cameras else '关闭') + '；' + qf_state + (f"；错误: {adaptive['error']}" if adaptive.get('error') else ''))
        for camera,preview in enumerate(self.previews):
            actual_qf=(live.get('decoded_quality') or [None,None])[camera]
            state=cameras[camera] if camera < len(cameras) else {}
            limit=state.get('yolo_limit_fps')
            target=f'上限 {limit} FPS' if limit else ('自动全速' if adaptive.get('enabled') else '手动')
            rate=f'{ai_fps[camera]:.1f}' if ai and enabled[camera] else '--'
            names={0:'灰度',1:'高斯',2:'CLAHE',3:'高斯+CLAHE',4:'Sobel',5:'黑帽'}
            recommendation=state.get('preprocess_prediction') or {}
            control=state.get('preprocess_control') or {}
            mode_status='手动' if control.get('manual_override') else names.get(recommendation.get('mode'),'--')
            self.allocation_labels[camera].setText(f"QF {actual_qf if actual_qf is not None else '--'}  |  YOLO {rate} FPS ({target})  |  自动预处理 {mode_status}")
            preview.set_detections(ai_results[camera],modes[camera],enabled[camera])
        if ai:
            descriptions=[]
            for index,result in enumerate(ai_results):
                boxes=(result or {}).get('boxes',[])
                age=(result or {}).get('age_ms')
                detail=', '.join(f"{box['label']} {box['confidence']:.2f}" for box in boxes[:3]) or '无目标'
                descriptions.append(f"{'AB'[index]}: {ai_fps[index]:.1f} FPS · {len(boxes)}框 · {detail}" if age is not None and age<=750 else f"{'AB'[index]}: {ai_fps[index]:.1f} FPS · 无新结果")
            self.yolo_state.setText('  |  '.join(descriptions)+(f"\n错误: {ai['error']}" if ai.get('error') else ''))
        else:self.yolo_state.setText('YOLO 尚未启动')
        values = [*decoded,display.get('rendered_fps_avg'),
            sum(dma) if all(v is not None for v in dma) else None]
        for label,value in zip(self.metric_values,values):
            label.setText('—' if value is None else f'{value:.2f}')
        fps = display.get('rendered_fps_avg')
        self.monitor_fps.setText('HDMI — FPS' if fps is None else f'HDMI {fps:.1f} FPS')
        resource = status['resources']
        for bar,value in ((self.cpu,rates['cpu']),(self.memory,
                100*(1-resource['memory_available_mb']/resource['memory_total_mb']))):
            bar.setValue(round((value or 0)*10))
            bar.setFormat('—' if value is None else f'{value:.1f}%')
        self.temperature.setText('温度 —' if resource['temperature'] is None else f"温度 {resource['temperature']:.1f} °C")
        npu=resource.get('npu_load') or {}
        for core in sorted(npu,key=int): self.ensure_npu_core(core)
        for core,bar in self.npu_bars.items():
            value=npu.get(core)
            bar.setValue(round(value*10) if value is not None else 0)
            bar.setFormat(f'{value:.1f}%' if value is not None else '—')
        link=resource.get('pcie_link')
        capacity=pcie_capacity_mbps(link)
        self.pcie_link.setText((f"PCIe {link['speed_gtps']:g} GT/s ×{link['width']} · 单方向编码后理论带宽 {capacity:.0f} Mbps · 接收负载估算" if capacity else 'PCIe 链路带宽不可用') +
            '（不含协议开销及其他流量）')
        totals=list(dma)+[sum(dma) if len(dma)==3 and all(v is not None for v in dma) else None]
        for bar,value in zip(self.pcie_bars,totals):
            percent=100*value/capacity if value is not None and capacity else None
            bar.setValue(round(min(percent,100)*10) if percent is not None else 0)
            bar.setFormat('—' if value is None else f'{value:.2f} Mbps'+
                (f'  ·  {percent:.2f}%' if percent is not None else '  ·  占比不可用'))
        self.runtime.setText({'managed':'双路接收运行中','external':'外部视频进程运行中','stopped':'未启动'}.get(status['runtime'],'未知'))
        build = hw.get('stream_diagnostics',{}).get('build','—')
        self.version.setText('FPGA '+({'0x434c4139':'CLA9','0x434c4138':'CLA8','0x434c4137':'CLA7','0x434c4136':'CLA6','0x434c4135':'CLA5','0x434c4134':'CLA4','0x434c4133':'CLA3','0x434c4132':'CLA2','0x434c4131':'CLA1','0x50524631':'PRF1','0x4f425331':'OBS1','0x53545235':'STR5','0x53545234':'STR4','0x53545233':'STR3'}.get(build,build)))
        self.applied.setText('实际 QF '+str(hw.get('applied_quality') or '—'))
        self.rendering = True
        self.independent_qf.setEnabled(bool(hw.get('dual_qf_supported')))
        self.quality_b.setEnabled(bool(hw.get('dual_qf_supported')))
        if 'osd' in display:
            self.osd.setChecked(display['osd'])
        selected = live.get('selected',(hw.get('requested',0)>>14)&1)
        self.display_buttons[selected].setChecked(True)
        for camera,preview in enumerate(self.previews):
            preview.set_output_state(bool(live) and camera==selected, decoded[camera])
        if not self.dirty:
            self.quality.setValue((hw.get('requested',85<<7)>>7)&127 or 85)
            dqf=hw.get('dual_qf')
            self.independent_qf.setChecked(bool(dqf is not None and dqf & (1<<16)))
            if dqf is not None:
                self.quality.setValue((dqf & 127) or 85)
                self.quality_b.setValue(((dqf >> 8) & 127) or 85)
        mask = hw.get('supported_modes') or 0
        if mask != self.mode_mask:
            for combo in self.mode_boxes:
                combo.clear()
                for mode,name in MODES.items():
                    if mask&(1<<mode): combo.addItem(name,mode)
                if not combo.count(): combo.addItem('等待能力信息',None)
            self.mode_mask=mask
        strength=hw.get('gaussian_strength')
        for camera,combo in enumerate(self.mode_boxes):
            mode=(hw.get('requested',0)>>(1+camera*3))&7
            index=combo.findData(mode)
            combo.setCurrentIndex(index if index>=0 else -1)
            if strength is not None:
                value=(strength>>(4*camera))&7
                self.gauss_boxes[camera].setCurrentIndex(self.gauss_boxes[camera].findData(value))
        self.rendering = False
        counters = live.get('counters') or {}
        store = hw.get('store_diagnostics') or {}
        stats = hw.get('statistics',[0]*16)
        def selected_value(value):
            return [value if camera==selected else None for camera in (0,1)]
        rows = [('完整帧捕获 FPS',rates['capture']),('FPGA 交付 FPS',rates['delivery']),
            ('送入显示管线 FPS',hdmi),
            ('HDMI 渲染 FPS',selected_value(display.get('rendered_fps_avg'))),
            ('HDMI 帧间隔 P95 / ms',selected_value(display.get('sink_gap_ms_p95'))),
            ('转换前队列拥塞事件',selected_value(display.get('queue_overrun_events'))),
            ('送显前队列拥塞事件',selected_value(display.get('present_queue_overrun_events'))),
            ('送显队列当前帧数 / 容量',selected_value(
                f"{display.get('present_queue',0)} / {display['present_queue_capacity']}"
                if display.get('present_queue_capacity') is not None else None)),
            ('显示提交至 HDMI 入口 P50 / ms',selected_value(display.get('submit_to_sink_ms_p50'))),
            ('显示提交至 HDMI 入口 P95 / ms',selected_value(display.get('submit_to_sink_ms_p95'))),
            ('送显源帧号跳帧 / 最近5秒',display.get('sink_source_gaps_5s',[None,None])),
            ('已解码帧',counters.get('decoded_frames',['—','—'])),
            ('解码队列丢帧',counters.get('decode_queue_drops',['—','—'])),
            ('显示队列丢帧',counters.get('display_queue_drops',['—','—'])),
            ('相机源帧号',counters.get('last_frame_ids',['—','—'])),
            ('严格 JPEG 拒绝',counters.get('decode_rejected_frames',['—','—'])),
            ('捕获丢帧累计',stats[2:4])]
        decoder = live.get('decoder') or {}
        timing = decoder.get('timing') or [{},{}]
        if len(timing)==2:
            rows.extend([
                ('解码耗时 P95 / ms',[(t.get('decode') or {}).get('p95_ms') for t in timing]),
                ('排队等待 P95 / ms',[(t.get('queue_wait') or {}).get('p95_ms') for t in timing]),
                ('解码队列深度',[t.get('queued') for t in timing])])
        rows.append(('PC 预览 Mbps',[p.stats.get('mbps') for p in self.previews]))
        for name,values in store.get('drops',{}).items():
            caption = dict(no_free='无空闲帧槽',input_timeout='输入超时',frame_id='帧号错误',
                ordinal='字序号错误',bad_flag='坏帧标志',new_sof_interrupt='SOF中断',axi_write='AXI写错误').get(name,name)
            rows.append((caption,values))
        streams = live.get('packet_streams') or []
        if len(streams)==3:
            rows.append(('C2H1 / 2 / 3 丢弃字节',[' / '.join(str(p['discarded_bytes']) for p in streams),'—']))
        self.diagnostics.setRowCount(len(rows))
        for i,(caption,values) in enumerate(rows):
            for j,value in enumerate([caption,*values]):
                text = '—' if value is None else f'{value:.2f}' if isinstance(value,float) else str(value)
                item = QTableWidgetItem(text)
                if caption.startswith('显示提交至 HDMI'):
                    item.setToolTip('RK 内部从提交显示帧到 HDMI 显示入口的等待时间，不含摄像头采集和屏幕扫描时间。')
                self.diagnostics.setItem(i,j,item)
        faults = hw.get('stream_diagnostics') or {}
        discarded = sum(p['discarded_bytes'] for p in streams)
        rejected = sum(counters.get('decode_rejected_frames',[0,0]))
        if status.get('hardware_error'):
            self.notice.setText(status['hardware_error'])
        elif faults.get('first_fault') or faults.get('bridge_fault_lanes') or faults.get('packer_fault_lanes'):
            self.notice.setText('FPGA报告链路故障，请查看诊断记录')
        elif discarded or rejected:
            self.notice.setText(f'链路有数据完整性异常 · 重同步丢弃 {discarded} 字节 · JPEG 拒绝 {rejected} 帧')
        elif status['runtime']=='external':
            self.notice.setText('检测到外部视频接收进程')
        else:
            self.notice.setText('双路视频运行中' if live else '已连接 · 视频未启动')
        self.update_enabled()

    def on_complete(self,action,result):
        if action=='sd_list':
            self.sd_path='' if result['path']=='.' else result['path'];self.sd_entries=result['entries']
            self.sd_label.setText(f"SD 卡 /{self.sd_path}  ·  可用 {result['free']/1024**3:.1f} / {result['total']/1024**3:.1f} GB（最多显示 500 项）")
            self.sd_table.setRowCount(0)
            for row,entry in enumerate(self.sd_entries):
                self.sd_table.insertRow(row)
                for col,value in enumerate((entry['name'],'文件夹' if entry['is_dir'] else '文件','—' if entry['is_dir'] else f"{entry['size']:,} B")):
                    self.sd_table.setItem(row,col,QTableWidgetItem(value))
        elif action=='sd_preview':
            data=base64.b64decode(result['data']);image=QImage.fromData(data);self.sd_image.clear();self.sd_text.clear()
            if not image.isNull():self.sd_image.setPixmap(QPixmap.fromImage(image).scaled(600,340,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
            elif b'\x00' in data:self.sd_text.setPlainText('此文件为二进制格式，请下载后使用对应软件查看。')
            else:self.sd_text.setPlainText(data.decode('utf-8',errors='replace'))
        elif action=='sd_download':self.sd_text.setPlainText('已下载到：'+result['destination'])
        elif action=='detection_list':
            self.det_events=result.get('events',[]);self.filter_detections()
        elif action=='detection_detail':
            if result.get('missing'):
                self.det_details.setText('记录已被新事件替换，请刷新');return
            event=result['event']
            if self.det_selected != result.get('id'):return
            image=QImage.fromData(base64.b64decode(result['jpeg']),'JPEG')
            self.det_canvas.image=image;self.det_canvas.detections=event['boxes']
            self.det_canvas.detections_until=float('inf');self.det_canvas.update()
            self.det_details.setText(f"帧 {event['frame_id']} · QF {event.get('quality')} · 推理 {event['inference_ms']:.1f} ms · 阈值 {event['threshold']:.2f}\n模型 SHA256: {event['model_sha256']}\n"+'\n'.join(f"{b['label']} {b['confidence']:.2f}" for b in event['boxes']))
        elif action=='detection_export':
            self.det_info.setText(f"已打包 {result['written']} 条；过期未找到 {len(result['missing'])} 条")
        elif action=='logs':
            self.log(result.get('text',''))
        else:
            self.log(dict(start='显示已启动',stop='显示已停止',configure='参数已发送',recover='PCIe已重新连接',
                provision='本机SSH公钥已配置').get(action,action))

    def filter_detections(self):
        try:
            start=datetime.fromisoformat(self.det_from.text().strip()).timestamp() if self.det_from.text().strip() else float('-inf')
            end=datetime.fromisoformat(self.det_to.text().strip()).timestamp() if self.det_to.text().strip() else float('inf')
            if start>end:raise ValueError('开始时间晚于结束时间')
        except ValueError:
            self.det_info.setText('时间格式示例：2026-10-29 14:30，且开始时间应早于结束时间');return
        cam=self.det_camera.currentIndex()-1;name=self.det_class.text().strip().casefold();threshold=self.det_min.value()/100
        self.det_filtered=[x for x in self.det_events if (cam<0 or x['camera']==cam) and start<=x['wall_time']<=end
            and any((not name or name in label.casefold()) and score>=threshold for label,score in x['label_scores'].items())]
        blocker=QSignalBlocker(self.det_table)
        self.det_table.setRowCount(0);self.det_selected=None;self.det_canvas.image=None;self.det_canvas.update()
        for row,event in enumerate(self.det_filtered):
            self.det_table.insertRow(row)
            values=[datetime.fromtimestamp(event['wall_time']).strftime('%Y-%m-%d %H:%M:%S'),
                'AB'[event['camera']],', '.join(event['labels']),f"{event['max_confidence']:.2f}",
                MODES.get(event['mode'],str(event['mode'])),str(event['frame_id'])]
            for col,value in enumerate(values):
                item=QTableWidgetItem(value);item.setData(Qt.ItemDataRole.UserRole,event['id']);self.det_table.setItem(row,col,item)
        info=f'显示 {len(self.det_filtered)} 条 / RK 最近 {len(self.det_events)} 条（合计最多 40 条）'
        if self.det_events and abs(time.time()-self.det_events[0]['wall_time'])>300:
            info+=' · 最新记录时间与电脑相差超过 5 分钟，请核对 RK 时间或确认是否仍有新检测'
        self.det_info.setText(info)
        del blocker

    def sd_refresh(self):
        self.worker.submit('sd_list',dict(path=self.sd_path))

    def sd_up(self):
        self.sd_path=self.sd_path.rpartition('/')[0];self.sd_refresh()

    def sd_selected(self):
        row=self.sd_table.currentRow()
        return self.sd_entries[row] if 0<=row<len(self.sd_entries) else None

    def sd_open(self):
        entry=self.sd_selected()
        if not entry:return
        path='/'.join(filter(None,(self.sd_path,entry['name'])))
        if entry['is_dir']:self.sd_path=path;self.sd_refresh()
        elif path=='dual_vision/detection_history.sqlite3':
            self.tabs.setCurrentIndex(next(i for i in range(self.tabs.count()) if self.tabs.tabText(i)=='检测日志'))
        else:self.worker.submit('sd_preview',dict(path=path))

    def sd_download(self):
        entry=self.sd_selected()
        if not entry or entry['is_dir']:return
        path='/'.join(filter(None,(self.sd_path,entry['name'])))
        if path=='dual_vision/detection_history.sqlite3':
            self.sd_text.setPlainText('日志数据库正在写入，请在检测日志页导出 CSV 和图片。');return
        destination,_=QFileDialog.getSaveFileName(self,'下载 SD 卡文件',entry['name'])
        if destination:self.worker.submit('sd_download',dict(path=path,destination=destination))

    def select_detection(self):
        row=self.det_table.currentRow()
        if row<0 or row>=len(self.det_filtered):return
        self.det_selected=self.det_filtered[row]['id']
        self.det_canvas.image=None;self.det_canvas.update();self.det_details.setText('正在读取记录…')
        self.worker.submit('detection_detail',dict(id=self.det_selected))

    def export_detections(self):
        path,_=QFileDialog.getSaveFileName(self,'导出检测日志','detection_log.csv','CSV (*.csv)')
        if not path:return
        with open(path,'w',encoding='utf-8-sig',newline='') as handle:
            writer=csv.writer(handle);writer.writerow(['时间','相机','帧号','处理模式','QF','类别','最高置信度','框数'])
            for event in self.det_filtered:
                writer.writerow([datetime.fromtimestamp(event['wall_time']).isoformat(sep=' ',timespec='seconds'),
                    'AB'[event['camera']],event['frame_id'],MODES.get(event['mode'],event['mode']),event.get('quality'),
                    ';'.join(event['labels']),event['max_confidence'],event['count']])

    def export_detection_images(self):
        path,_=QFileDialog.getSaveFileName(self,'打包筛选结果图片','detection_images.zip','ZIP (*.zip)')
        if path:self.worker.submit('detection_export',dict(path=path,ids=[x['id'] for x in self.det_filtered]))

    def on_error(self,action,message):
        self.notice.setText(message)
        if action.startswith('sd_'):self.sd_text.setPlainText(message)
        self.log(action+'：'+message)

    def log(self,message):
        self.events.appendPlainText(time.strftime('%H:%M:%S')+'  '+message)

    def clear_rates(self):
        self.feature_last = [None, None]
        self.update_features(None)
        for label in self.allocation_labels:
            label.setText('QF --  |  YOLO -- FPS')
        for label in self.metric_values:
            label.setText('—')
        self.cpu.setFormat('—')
        self.memory.setFormat('—')
        for bar in self.npu_bars.values():
            bar.setValue(0);bar.setFormat('—')
        self.pcie_link.setText('链路状态：—')
        for bar in self.pcie_bars:
            bar.setValue(0);bar.setFormat('—')
        self.monitor_fps.setText('HDMI — FPS')
        for preview in self.previews:
            preview.set_output_state(False,None)

    def check_stale(self):
        if self.linked and time.monotonic()-self.last_received>5:
            self.clear_rates()
            for row in (0,1):
                for column in (1,2):
                    item = self.diagnostics.item(row,column)
                    if item:
                        item.setText('—')
            self.notice.setText('RK状态已过期')
            self.update_enabled()

    def export(self):
        path,_ = QFileDialog.getSaveFileName(self,'导出运行记录',
            'dual_vision_'+time.strftime('%Y%m%d_%H%M%S')+'.json','JSON (*.json)')
        if path:
            Path(path).write_text(json.dumps(dict(samples=list(self.history),events=self.events.toPlainText()),
                indent=2,ensure_ascii=False),encoding='utf-8')
            self.log('记录已导出')

    def closeEvent(self,event):
        for preview in self.previews:
            preview.stop()
        self.worker.stopping.set()
        if self.worker.isRunning() and not self.worker.wait(30000):
            self.notice.setText('正在等待当前RK操作结束')
            event.ignore()
            return
        event.accept()


STYLE = '''
QWidget { background:#17191d; color:#edf0f4; font-family:"Microsoft YaHei UI"; font-size:13px; }
QLabel { background:transparent; }
QLabel#brand { font-size:21px; font-weight:600; }
QLabel#muted { color:#969fae; font-size:12px; }
QLabel#connection { color:#72d5bc; font-size:12px; }
QLabel#notice { color:#b4c0d1; padding:8px 2px 0; border-top:1px solid #2d333b; font-size:12px; }
QLabel#sectionTitle { font-size:15px; font-weight:600; color:#edf0f4; padding:4px 0; }
QLabel#inlineMetric { color:#99c9ec; font-size:14px; font-weight:600; }
QLabel#metric { font-size:27px; font-weight:600; color:#72d5bc; padding:3px 0 16px; }
QPushButton,QToolButton { background:#272c34; border:1px solid #3a424d; border-radius:5px; padding:5px 12px; }
QPushButton:hover,QToolButton:hover { background:#343b45; border-color:#697686; }
QPushButton:pressed,QToolButton:pressed { background:#1d252d; }
QPushButton:checked { background:#203f38; border-color:#58b69e; color:#9ce4d1; }
QPushButton#primary { background:#286c59; border-color:#368d73; color:#f2fff9; }
QPushButton#primary:hover { background:#31816a; }
QPushButton:disabled,QToolButton:disabled { color:#646d7a; background:#20242a; border-color:#2c323b; }
QPushButton#primary:disabled { background:#24332e; border-color:#34483e; color:#768980; }
QPushButton#iconButton { padding:0; background:transparent; border:1px solid transparent; }
QPushButton#iconButton:hover { background:#343b45; border-color:#485363; }
QWidget#previewPanel { background:#1c2026; border:1px solid #343c47; border-radius:6px; }
QWidget#previewPanel[hdmi="true"] { border-color:#528b79; }
QLabel#outputBadge { color:#83d6bd; font-size:11px; }
QLineEdit,QComboBox,QSpinBox { background:#20242b; border:1px solid #3a424e; border-radius:4px; min-height:29px; padding:1px 8px; }
QComboBox:disabled,QSpinBox:disabled { color:#68717d; background:#1b1e23; border-color:#2b3037; }
QLineEdit:focus,QComboBox:focus,QSpinBox:focus { border-color:#68b69f; }
QComboBox QAbstractItemView { background:#242a32; selection-background-color:#2c584c; }
QTabWidget::pane { border:0; border-top:1px solid #303741; }
QTabBar::tab { padding:11px 20px; background:transparent; color:#9ca7b6; border-bottom:2px solid transparent; }
QTabBar::tab:selected { color:#8be0c6; border-bottom-color:#71c7ac; }
QTabBar::tab:hover { color:#edf0f4; background:#23282f; }
QTableWidget { background:#1c2026; alternate-background-color:#232932; gridline-color:#303741; border:0; selection-background-color:#315b50; }
QHeaderView::section { background:#282e37; color:#aeb8c7; border:0; border-bottom:1px solid #3b4654; padding:10px; }
QPlainTextEdit { background:#1c2026; border:0; padding:10px; font-family:Consolas; }
QProgressBar { background:#272e38; border:0; border-radius:4px; height:20px; text-align:center; }
QProgressBar::chunk { background:#387f6c; border-radius:4px; }
QScrollArea,QScrollArea > QWidget > QWidget { background:transparent; }
QCheckBox { spacing:8px; }
QCheckBox::indicator { width:16px; height:16px; border:1px solid #617184; border-radius:3px; background:#222832; }
QCheckBox::indicator:checked { background:#408e75; border-color:#84d9b8; image:none; }
QScrollBar:vertical { width:9px; background:#20252c; }
QScrollBar::handle:vertical { background:#465361; min-height:24px; border-radius:4px; }
QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical { height:0; }
QToolTip { background:#343e4b; color:#fff; border:1px solid #58677a; padding:5px; }
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--demo',action='store_true')
    parser.add_argument('--connect',action='store_true')
    parser.add_argument('--preview',action='store_true')
    parser.add_argument('--verify-output',type=Path)
    parser.add_argument('--verify-seconds',type=int,default=12)
    args = parser.parse_args()
    if args.verify_output:
        args.verify_output.mkdir(parents=True,exist_ok=True)
        (args.verify_output/'failure.txt').unlink(missing_ok=True)
    application = QApplication([])
    if not QFontDatabase.families():
        fonts = Path(os.environ.get('WINDIR','C:/Windows'))/'Fonts'
        for name in ('msyh.ttc','msyhbd.ttc','segoeui.ttf'):
            QFontDatabase.addApplicationFont(str(fonts/name))
    application.setStyle('Fusion')
    application.setFont(QFont('Microsoft YaHei UI',10))
    window = Window(args.demo)
    window.show()
    if args.connect:
        QTimer.singleShot(200,window.toggle_connect)
    requested = [False]
    verification_records = []
    verify_started = time.monotonic()
    def ready(status):
        if args.verify_output:
            verification_records.append(redact(status))
        if args.preview and not requested[0] and status.get('live'):
            requested[0] = True
            for camera in (0,1):
                window.request_preview(camera)
        if args.verify_output and len(window.history)>=12 and time.monotonic()-verify_started>=args.verify_seconds and (not args.preview or all(p.seen>=15 for p in window.previews)):
            args.verify_output.mkdir(parents=True,exist_ok=True)
            window.grab().save(str(args.verify_output/'ui_live.png'))
            for i,preview in enumerate(window.previews):
                if preview.canvas.image:
                    preview.canvas.image.save(str(args.verify_output/f'camera_{i}.png'))
            (args.verify_output/'status.json').write_text(json.dumps(list(window.history),indent=2),encoding='utf-8')
            (args.verify_output/'runtime_samples.json').write_text(json.dumps(verification_records,indent=2),encoding='utf-8')
            window.resize(1000,700)
            application.processEvents()
            window.grab().save(str(args.verify_output/'ui_1000.png'))
            window.close()
            application.quit()
    window.worker.status.connect(ready)
    if args.verify_output:
        def timeout():
            args.verify_output.mkdir(parents=True,exist_ok=True)
            (args.verify_output/'failure.txt').write_text(window.notice.text()+'\n'+window.events.toPlainText(),encoding='utf-8')
            window.close()
            application.exit(1)
        QTimer.singleShot(max(65,args.verify_seconds+30)*1000,timeout)
    return application.exec()


if __name__=='__main__':
    raise SystemExit(main())
