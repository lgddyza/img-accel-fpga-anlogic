"""Exercise independent live resolution changes through the real Qt controls."""
import json
from pathlib import Path
import time

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication
from app import Window

out = Path('verification/preview_select_20261029')
out.mkdir(parents=True, exist_ok=True)
app = QApplication([])
window = Window()
window.show()
started = time.monotonic()
steps = [((640, 360), (640, 360)), ((960, 540), (640, 360)),
         ((1280, 720), (640, 360)), ((640, 360), (640, 360)),
         ((640, 360), (1280, 720)), ((640, 360), (640, 360))]
seen = []
phase = 0
settled = None

def tick():
    global phase, settled
    live = (window.current or {}).get('live') or {}
    if live.get('preview', {}).get('token') and not window.busy:
        for camera, preview in enumerate(window.previews):
            if not preview.receiver and phase == 0:
                window.request_preview(camera)
    sizes = tuple((p.width, p.height) if p.receiver and p.seen else None for p in window.previews)
    if sizes == steps[phase]:
        settled = settled or time.monotonic()
        if time.monotonic()-settled > 1:
            seen.append(sizes)
            phase += 1
            settled = None
            if phase == len(steps):
                window.grab().save(str(out/'switch_ui.png'))
                (out/'switch.json').write_text(json.dumps({'passed': True, 'sizes': seen}, indent=2))
                window.close()
                app.exit(0)
                return
            for camera, (width, height) in enumerate(steps[phase]):
                if sizes[camera] != (width, height):
                    box = window.preview_sizes[camera]
                    box.setCurrentIndex(box.findData(str(height)))
                    window.change_preview_size(camera)
    else:
        settled = None
    if time.monotonic()-started > 60:
        (out/'switch.json').write_text(json.dumps({'passed': False, 'sizes': seen, 'last': sizes,
            'notice': window.notice.text()}, indent=2))
        window.close()
        app.exit(1)

timer = QTimer()
timer.timeout.connect(tick)
timer.start(200)
QTimer.singleShot(200, window.toggle_connect)
raise SystemExit(app.exec())
