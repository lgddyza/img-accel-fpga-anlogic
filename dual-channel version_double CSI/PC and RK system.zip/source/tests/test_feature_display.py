"""Exercise live feature formatting and stale/invalid observations."""
import copy
import os
import unittest
from unittest.mock import patch

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
from PySide6.QtWidgets import QApplication
from app import Window


class FeatureDisplayTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.window = Window(demo=True)
        self.obs = dict(valid=True, camera=0, epoch=1, sequence=5, frame_id=10, errors=0,
            features=dict(mean=107.77, dark_fraction=.02895, bright_fraction=.0127,
                          hist_contrast=96, gradient_mean=2.141))

    def tearDown(self):
        self.window.close()

    def values(self, camera):
        return [label.text() for label in self.window.feature_values[camera]]

    def test_independent_qf_submission_and_legacy_fallback(self):
        with patch.object(self.window.worker,'submit') as submit:
            self.window.independent_qf.setEnabled(True)
            self.window.independent_qf.setChecked(True)
            self.window.quality.setValue(95)
            self.window.quality_b.setValue(30)
            self.window.apply_config()
            submit.assert_called_with('configure',dict(quality_a=95,quality_b=30,independent_qf=True))
            self.window.independent_qf.setEnabled(False)
            self.window.apply_config()
            submit.assert_called_with('configure',dict(quality=95))

    def test_format_is_per_camera_and_missing_data_is_not_zero(self):
        other = copy.deepcopy(self.obs)
        other.update(camera=1, sequence=6)
        other['features']['mean'] = 114.5
        self.window.update_features(dict(camera_a=self.obs, camera_b=other))
        self.assertEqual(self.values(0), ['107.8', '2.9%', '1.3%', '96', '2.14'])
        self.assertEqual(self.values(1)[0], '114.5')
        self.window.update_features(dict(camera_a=dict(valid=False), camera_b=other))
        self.assertEqual(self.values(0), ['—']*5)
        self.assertEqual(self.values(1)[0], '114.5')

    def test_frozen_snapshot_expires_and_new_sequence_recovers(self):
        with patch('app.time.monotonic') as clock:
            clock.return_value = 10
            self.window.update_features(dict(camera_a=self.obs))
            clock.return_value = 16
            self.window.update_features(dict(camera_a=self.obs))
            self.assertEqual(self.window.feature_states[0].text(), '特征未更新')
            self.assertEqual(self.values(0), ['—']*5)
            self.obs['sequence'] += 1
            self.window.update_features(dict(camera_a=self.obs))
            self.assertEqual(self.window.feature_states[0].text(), '特征实时')
            self.assertEqual(self.values(0)[0], '107.8')
        self.window.clear_rates()
        self.assertEqual(self.values(0), ['—']*5)

    def test_nonfinite_or_wrong_camera_is_rejected(self):
        self.obs['features']['mean'] = float('nan')
        self.window.update_features(dict(camera_a=self.obs))
        self.assertEqual(self.values(0), ['—']*5)
        self.obs['features']['mean'] = 5
        self.obs['camera'] = 1
        self.window.update_features(dict(camera_a=self.obs))
        self.assertEqual(self.values(0), ['—']*5)


if __name__ == '__main__':
    unittest.main()
