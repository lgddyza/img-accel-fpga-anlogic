"""Regression checks for stale data, capability guards and frame accounting."""
import copy
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
import hashlib
import subprocess
import zipfile
from unittest.mock import MagicMock,patch

root = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
sys.path.insert(0,str(root/'rk'))
from telemetry import Rates,redact,pcie_capacity_mbps
from live_status import LiveStatus
import transport
if sys.platform=='win32':
    sys.modules.setdefault('fcntl',types.SimpleNamespace(LOCK_EX=2,flock=lambda *_:None))
import board_agent as agent


def sample(t=1,pid=10,frames=10):
    return dict(sample_s=t,resources=dict(boot_id='one',cpu_total=100*t,cpu_idle=50*t),
        live=dict(pid=pid,sample_s=t,board=dict(statistics=[frames,frames,0,0,frames,frames])))


class RatesTests(unittest.TestCase):
    def test_pcie_capacity_uses_negotiated_encoding_and_width(self):
        self.assertEqual(pcie_capacity_mbps(dict(speed_gtps=5.0,width=1)),4000)
        self.assertAlmostEqual(pcie_capacity_mbps(dict(speed_gtps=8.0,width=2)),16000*128/130)
        self.assertIsNone(pcie_capacity_mbps(dict(speed_gtps=0,width=1)))
        self.assertIsNone(pcie_capacity_mbps(None))
    def test_process_restart_does_not_create_a_huge_fps(self):
        rates = Rates()
        rates.update(sample())
        result = rates.update(sample(2,11,1))
        self.assertEqual(result['capture'],[None,None])
        self.assertEqual(result['cpu'],50)

    def test_wrap_and_duplicate_snapshot(self):
        rates = Rates()
        rates.update(sample(1,10,0xfffffff0))
        self.assertEqual(rates.update(sample(2,10,44))['delivery'],[60,60])
        self.assertEqual(rates.update(sample(2,10,44))['delivery'],[None,None])

    def test_reboot_invalidates_cpu_and_export_removes_credentials(self):
        rates = Rates()
        rates.update(sample())
        after = sample(2)
        after['resources']['boot_id']='two'
        self.assertIsNone(rates.update(after)['cpu'])
        data = dict(live=dict(preview=dict(token='secret',port=8767)),password='secret')
        self.assertNotIn('secret',json.dumps(redact(data)))
        self.assertEqual(data['password'],'secret')


class ControlTests(unittest.TestCase):
    def test_qf_register_access_is_capability_gated(self):
        import dual_control
        with tempfile.TemporaryDirectory() as directory:
            bar=Path(directory)/'bar'
            data=bytearray(4096)
            def put(offset,value): data[offset:offset+4]=value.to_bytes(4,'little')
            put(0x200,dual_control.CONTROL_MAGIC)
            put(0x204,2)
            put(0x2a0,(85<<8)|85)
            bar.write_bytes(data)
            cmd=[sys.executable,str(root/'rk'/'dual_control.py'),'--bar',str(bar),'--quality-a','95','--quality-b','30','--independent-qf','1']
            result=subprocess.run(cmd,capture_output=True,text=True)
            self.assertNotEqual(result.returncode,0)
            self.assertEqual(bar.read_bytes()[0x2a0:0x2a4],data[0x2a0:0x2a4])
            put(0x2a4,0x32465144)
            bar.write_bytes(data)
            result=subprocess.run(cmd,capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertEqual(int.from_bytes(bar.read_bytes()[0x2a0:0x2a4],'little'),(1<<16)|(30<<8)|95)
            self.assertTrue(json.loads(result.stdout)['dual_qf_supported'])

    def test_independent_qf_requires_capability_and_sends_atomic_options(self):
        request=dict(quality_a=95,quality_b=30,independent_qf=True)
        with patch.object(agent,'status',return_value=dict(hardware=dict(dual_qf_supported=False))), patch.object(agent,'control') as writer:
            with self.assertRaises(ValueError): agent.apply(request)
            writer.assert_not_called()
        with patch.object(agent,'status',return_value=dict(hardware=dict(dual_qf_supported=True))), patch.object(agent,'control') as writer:
            agent.apply(request)
            writer.assert_called_once_with(['--independent-qf','1','--quality-a','95','--quality-b','30'])

    def test_cla1_modes_use_reported_capability(self):
        self.assertIn('0x434c4131', agent.BUILDS)
        self.assertIn('0x434c4132', agent.BUILDS)
        self.assertIn('0x434c4133', agent.BUILDS)
        self.assertIn('0x434c4134', agent.BUILDS)
        self.assertIn('0x434c4135', agent.BUILDS)
        self.assertIn('0x434c4136', agent.BUILDS)
        self.assertIn('0x434c4138', agent.BUILDS)
        self.assertIn('0x434c4139', agent.BUILDS)
        import dual_control
        self.assertIn(0x434c4132, dual_control.STREAM_BUILDS)
        self.assertIn(0x434c4133, dual_control.STREAM_BUILDS)
        self.assertIn(0x434c4134, dual_control.STREAM_BUILDS)
        self.assertIn(0x434c4135, dual_control.STREAM_BUILDS)
        self.assertIn(0x434c4136, dual_control.STREAM_BUILDS)
        self.assertIn(0x434c4138, dual_control.STREAM_BUILDS)
        self.assertIn(0x434c4139, dual_control.STREAM_BUILDS)
        with patch.object(agent,'status',return_value=dict(hardware=dict(supported_modes=0x2f))), patch.object(agent,'control') as writer:
            agent.apply(dict(mode_a=2,mode_b=3,gauss_b=2))
            writer.assert_called_once_with(['--mode-a','2','--mode-b','3','--gauss-b','2'])

    def test_prf_blackhat_uses_reported_capability(self):
        with patch.object(agent,'status',return_value=dict(hardware=dict(supported_modes=0x23))), patch.object(agent,'control') as writer:
            agent.apply(dict(mode_a=5,mode_b=1))
            writer.assert_called_once_with(['--mode-a','5','--mode-b','1'])

    def test_sobel_requires_reported_capability(self):
        with patch.object(agent,'status',return_value=dict(hardware=dict(supported_modes=0x3f))), patch.object(agent,'control') as writer:
            agent.apply(dict(mode_a=4,mode_b=4))
            writer.assert_called_once_with(['--mode-a','4','--mode-b','4'])
        with patch.object(agent,'status',return_value=dict(hardware=dict(supported_modes=0x2f))), patch.object(agent,'control') as writer:
            with self.assertRaises(ValueError):
                agent.apply(dict(mode_a=4))
            writer.assert_not_called()

    def test_unsupported_mode_never_writes(self):
        with patch.object(agent,'status',return_value=dict(hardware=dict(supported_modes=1))), patch.object(agent,'control') as writer:
            with self.assertRaises(ValueError):
                agent.apply(dict(mode_a=2))
            writer.assert_not_called()

    def test_invalid_values_never_write(self):
        for request in (dict(display=2),dict(quality=0),dict(quality=True),dict(mode_b=-1),dict(osd=1)):
            with self.subTest(request=request),patch.object(agent,'status',return_value=dict(hardware=dict(supported_modes=1))),patch.object(agent,'control') as writer:
                with self.assertRaises(ValueError):
                    agent.apply(request)
                writer.assert_not_called()

    def test_unknown_bitstream_is_checked_before_a_write(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)
            (path/'config').write_bytes(b'\x00'*4+b'\x06\x00')
            result = types.SimpleNamespace(returncode=0,stdout=json.dumps(dict(stream_diagnostics=dict(build='0xbad'))))
            with patch.object(agent,'BAR',path/'resource0'),patch.object(agent,'RUN',path),patch.object(agent,'bundle',return_value=path),patch.object(agent.subprocess,'run',return_value=result) as invoke:
                with self.assertRaises(RuntimeError):
                    agent.control(['--enable','1'])
                self.assertEqual(invoke.call_count,1)
                self.assertNotIn('--enable',invoke.call_args.args[0])


class RecoveryTests(unittest.TestCase):
    def simulate(self, bound, ready=True):
        driver,device,bar = MagicMock(),MagicMock(),MagicMock()
        device.name='2a210000.pcie'
        driver.resolve.return_value=driver
        link=device.__truediv__.return_value
        link.resolve.return_value=driver
        link.is_symlink.side_effect=[bound,True] if ready else [bound]
        nodes={name:MagicMock() for name in ('bind','unbind')}
        driver.__truediv__.side_effect=nodes.__getitem__
        with patch.multiple(agent,PCIE_DRIVER=driver,PCIE_DEVICE=device,BAR=bar,
                DMA_DEVICES=(MagicMock(),)*3),patch.object(agent,'processes',return_value=[]), \
                patch.object(agent,'control') as control, \
                patch.object(agent.time,'sleep'), \
                patch.object(agent.time,'monotonic',side_effect=[0,1 if ready else 16]):
            if ready:
                agent.recover_pcie()
                control.assert_called_once_with()
            else:
                with self.assertRaisesRegex(RuntimeError,'DMA'):
                    agent.recover_pcie()
                control.assert_not_called()
        nodes['bind'].write_text.assert_called_once_with('2a210000.pcie')
        if bound:
            nodes['unbind'].write_text.assert_called_once_with('2a210000.pcie')
        else:
            nodes['unbind'].write_text.assert_not_called()

    def test_failed_boot_probe_binds_without_unbind(self):
        self.simulate(False)

    def test_existing_binding_is_reinitialized(self):
        self.simulate(True)

    def test_missing_endpoint_is_not_reported_as_recovered(self):
        self.simulate(False,ready=False)

    def test_running_receiver_blocks_recovery(self):
        with patch.object(agent,'processes',return_value=[dict(pid=1)]), \
                patch.object(agent,'PCIE_DRIVER') as driver:
            with self.assertRaisesRegex(RuntimeError,'停止视频'):
                agent.recover_pcie()
            driver.is_dir.assert_not_called()

    def test_missing_endpoint_has_actionable_message(self):
        with tempfile.TemporaryDirectory() as directory, \
                patch.object(agent,'BAR',Path(directory)/'resource0'):
            with self.assertRaisesRegex(RuntimeError,'重新连接 PCIe'):
                agent.control()


class LiveTests(unittest.TestCase):
    def test_atomic_status_uses_decode_counts_and_separates_hdmi(self):
        stats = dict(decoded_frames=[0,0],complete_frames=[0,0],submitted_hdmi=[0,0],
            decode_rejected_frames=[0,0],dma_bytes=[0,0,0],queue_drops=0,decode_queue_drops=[0,0],
            display_queue_drops=[0,0],dma_errors=[],decode_errors=[],last_frame_ids=[None,None])
        with tempfile.TemporaryDirectory() as directory:
            live = LiveStatus(Path(directory)/'live.json')
            with patch('live_status.time.monotonic',return_value=10):
                live.write(stats,dict(t=0),1,None)
            stats.update(decoded_frames=[60,60],submitted_hdmi=[0,59],dma_bytes=[1000000]*3,
                display=dict(rendered=20,rendered_fps_avg=20))
            with patch('live_status.time.monotonic',return_value=11):
                output = live.write(stats,dict(t=1),1,None)
            self.assertEqual(output['rates']['decoded'],[60,60])
            self.assertEqual(output['rates']['hdmi_submitted'],[0,59])
            self.assertEqual(output['display']['rendered_fps_avg'],20)
            self.assertEqual(output['rates']['dma_mbps'],[8,8,8])
            self.assertEqual(json.loads(live.path.read_text())['selected'],1)
            self.assertFalse(live.path.with_suffix('.tmp').exists())


class DeploymentTests(unittest.TestCase):
    def test_reconnect_does_not_truncate_a_loaded_shared_library(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)
            with zipfile.ZipFile(path/'payload.zip','w') as archive:
                archive.writestr('decoder.so',b'loaded library')
            digest = hashlib.sha256((path/'payload.zip').read_bytes()).hexdigest()
            with patch.object(transport,'REMOTE_ROOT',str(path)):
                code = transport.install_code(digest)
                exec(code,{})
                library = path/'releases'/digest[:16]/'decoder.so'
                original = library.stat().st_mtime_ns
                exec(code,{})
                self.assertEqual(library.stat().st_mtime_ns,original)
                self.assertEqual(library.read_bytes(),b'loaded library')


if __name__=='__main__':
    unittest.main()
