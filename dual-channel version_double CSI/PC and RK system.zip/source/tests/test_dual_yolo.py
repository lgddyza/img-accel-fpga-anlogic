import sys
import time
import threading
import unittest
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'rk'))
from dual_yolo import DualYolo

class FakeDetector:
    def run(self, frame, confidence):
        time.sleep(.01)
        return [dict(cls=0,label='Alligator crack',confidence=confidence,x1=1,y1=2,x2=3,y2=4)]
    def close(self): pass

class DualYoloTest(unittest.TestCase):
    def test_restricted_worker_can_help_and_results_do_not_go_backwards(self):
        entered=threading.Event(); release=threading.Event()
        class Detector:
            def __init__(self, index): self.index=index
            def run(self,frame,confidence):
                if frame==b'old':
                    entered.set();release.wait(2)
                return []
            def close(self): pass
        worker=DualYolo(Detector)
        try:
            worker.configure([True,True],.1)
            worker.set_intervals([0,.2])
            worker.offer(0,1,b'old',0)
            self.assertTrue(entered.wait(1))
            worker.offer(0,2,b'new',0)
            deadline=time.monotonic()+1
            while time.monotonic()<deadline and not worker.snapshot()['results'][0]: time.sleep(.005)
            self.assertEqual(worker.snapshot()['results'][0]['frame_id'],2)
            release.set()
            deadline=time.monotonic()+1
            while time.monotonic()<deadline and worker.snapshot()['completed'][0]<2: time.sleep(.005)
            self.assertEqual(worker.snapshot()['results'][0]['frame_id'],2)
        finally:
            release.set();worker.close()
    def test_workers_run_concurrently(self):
        barrier=threading.Barrier(2, timeout=2)
        class ConcurrentDetector:
            def run(self, frame, confidence):
                barrier.wait(); return []
            def close(self): pass
        worker=DualYolo(lambda camera: ConcurrentDetector())
        try:
            worker.configure([True,True],.1)
            worker.offer(0,1,b'a',0); worker.offer(1,1,b'b',0)
            deadline=time.monotonic()+3
            while time.monotonic()<deadline and not all(worker.snapshot()['completed']):time.sleep(.01)
            self.assertEqual(worker.snapshot()['completed'],[1,1])
            self.assertIsNone(worker.snapshot()['error'])
        finally: worker.close()
    def test_inflight_result_is_discarded_after_reenable(self):
        started=threading.Event();release=threading.Event()
        class SlowDetector:
            def run(self,frame,confidence):
                started.set();release.wait(2);return []
            def close(self): pass
        worker=DualYolo(lambda camera: SlowDetector())
        try:
            worker.configure([True,False],.1);worker.offer(0,1,b'a',0)
            self.assertTrue(started.wait(1))
            worker.configure([False,False],.1);worker.configure([True,False],.1)
            release.set()
            deadline=time.monotonic()+1
            while time.monotonic()<deadline and not worker.snapshot()['completed'][0]:time.sleep(.01)
            self.assertIsNone(worker.snapshot()['results'][0])
        finally:
            release.set();worker.close()
    def test_two_cameras_and_disable(self):
        worker=DualYolo(lambda camera: FakeDetector())
        try:
            worker.configure([True,True],.2)
            for i in range(20):
                worker.offer(0,i,b'a',1);worker.offer(1,i,b'b',5)
            deadline=time.monotonic()+2
            while time.monotonic()<deadline and not all(worker.snapshot()['completed']):time.sleep(.01)
            result=worker.snapshot()
            self.assertTrue(all(result['completed']))
            self.assertEqual([r['mode'] for r in result['results']],[1,5])
            self.assertTrue(all(result['replaced']))
            worker.configure([False,False],.2)
            self.assertEqual(worker.snapshot()['results'],[None,None])
        finally:worker.close()

if __name__=='__main__':unittest.main()
