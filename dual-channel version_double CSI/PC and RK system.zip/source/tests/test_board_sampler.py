import sys
from pathlib import Path
import threading
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'rk'))
from board_sampler import BoardSampler


class BoardSamplerTests(unittest.TestCase):
    def test_blocked_control_keeps_last_snapshot_available(self):
        stop, entered, release = threading.Event(), threading.Event(), threading.Event()
        def read():
            entered.set()
            release.wait(2)
            return {'sequence': 2}
        sampler = BoardSampler(read, stop, interval=.01)
        sampler.latest = {'sequence': 1}
        sampler.thread.start()
        try:
            self.assertTrue(entered.wait(1))
            self.assertEqual(sampler.latest, {'sequence': 1})
            release.set()
        finally:
            stop.set()
            release.set()
            sampler.thread.join(2)
        self.assertFalse(sampler.thread.is_alive())
        self.assertEqual(sampler.latest, {'sequence': 2})

    def test_read_failure_stops_runtime(self):
        stop = threading.Event()
        def read():
            raise OSError('MMIO unavailable')
        sampler = BoardSampler(read, stop)
        sampler.thread.start()
        sampler.thread.join(1)
        self.assertTrue(stop.is_set())
        self.assertEqual(sampler.error, 'MMIO unavailable')
