import sys
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'rk'))
from adaptive_policy import AdaptivePolicy, SharedQfController, PreprocessController, predict_preprocess
from dual_yolo import DualYolo


def observation(camera, seq, dark):
    return dict(valid=True, camera=camera, epoch=1, sequence=seq, frame_id=seq,
                samples=129600, features=dict(mean=20, dark_fraction=dark, bright_fraction=0))


def states(a, b, seq):
    return [dict(dark_fraction=x, identity=(1,seq,seq)) for x in (a,b)]


class AdaptiveTest(unittest.TestCase):
    def test_tree_uses_all_five_outputs_and_rejects_bad_features(self):
        features=dict(mean=80,dark_fraction=.01,bright_fraction=0,hist_contrast=48,gradient_mean=3)
        self.assertEqual(predict_preprocess(features)['mode'],3)
        features.update(dark_fraction=.1)
        self.assertEqual(predict_preprocess(features)['mode'],2)
        features.update(mean=150,bright_fraction=.2)
        self.assertEqual(predict_preprocess(features)['mode'],0)
        features['gradient_mean']=float('nan')
        self.assertIsNone(predict_preprocess(features))

    def test_preprocess_debounce_manual_override_and_restore(self):
        c=PreprocessController();s1=dict(identity=(1,1,1));s2=dict(identity=(1,2,2));p=dict(mode=3)
        self.assertIsNone(c.update(5,s1,p,63,True,0))
        self.assertIsNone(c.update(5,s1,p,63,True,1))
        self.assertEqual(c.update(5,s2,p,63,True,1),3)
        self.assertEqual(c.update(3,{},None,63,True,1.1),5)
        c=PreprocessController()
        c.update(5,s1,p,63,True,0)
        self.assertEqual(c.update(5,s2,p,63,True,.5),3)
        c.manual_change()
        self.assertIsNone(c.update(1,s1,p,63,True,1))
        self.assertIsNone(c.update(1,s2,p,63,True,2))
        self.assertIsNone(c.update(1,{},None,63,False,3))
        self.assertFalse(c.manual_override)

    def test_preprocess_unsupported_mode_never_written(self):
        c=PreprocessController();p=dict(mode=3)
        self.assertIsNone(c.update(0,dict(identity=(1,1,1)),p,1,True,0))
        self.assertIsNone(c.update(0,dict(identity=(1,2,2)),p,1,True,1))

    def test_independent_quality_tracks_each_camera(self):
        a,b=SharedQfController(),SharedQfController()
        first=states(.95,.2,1); second=states(.95,.2,2)
        self.assertIsNone(a.update(85,[first[0]],True,0))
        self.assertIsNone(b.update(85,[first[1]],True,0))
        self.assertEqual(a.update(85,[second[0]],True,.5),30)
        self.assertIsNone(b.update(85,[second[1]],True,.5))
        self.assertEqual(a.update(30,[],False,1),85)

    def test_dark_threshold_and_stale_recovery(self):
        p=AdaptivePolicy()
        data=dict(camera_a=observation(0,1,.90), camera_b=observation(1,1,.901))
        r=p.update(data,0,True)
        self.assertIsNone(r['cameras'][0]['yolo_limit_fps'])
        self.assertEqual(r['cameras'][1]['yolo_limit_fps'],5)
        self.assertIsNone(p.update(data,4,True)['cameras'][1]['yolo_limit_fps'])
        self.assertEqual(p.update(None,5,False)['cameras'][0]['state'],'off')

    def test_shared_grades_and_bright_camera_protection(self):
        for dark, target in [(.50,None),(.5001,65),(.69,65),(.70,50),(.80,40),(.90,30)]:
            q=SharedQfController()
            self.assertIsNone(q.update(60,states(dark,1,1),True,0))
            self.assertEqual(q.update(60,states(dark,1,2),True,.5),target)
        q=SharedQfController()
        self.assertIsNone(q.update(60,states(1,.1,1),True,0))
        self.assertIsNone(q.update(60,states(1,.1,2),True,5))

    def test_fast_recovery_and_switch_interval(self):
        q=SharedQfController()
        q.update(60,states(.51,.6,1),True,0)
        self.assertEqual(q.update(60,states(.51,.6,2),True,.5),65)
        q.update(65,states(.8,.9,3),True,.6)
        self.assertEqual(q.update(65,states(.8,.9,4),True,1.1),40)
        self.assertEqual(q.update(40,states(.5,.9,5),True,1.2),60)

    def test_full_dark_needs_one_second_and_new_observations(self):
        q=SharedQfController()
        self.assertIsNone(q.update(60,states(1,1,1),True,0))
        self.assertIsNone(q.update(60,states(1,1,1),True,2))
        self.assertEqual(q.update(60,states(1,1,2),True,2),1)
        self.assertEqual(q.update(1,[],False,3),60)

    def test_manual_override_and_observation_failure(self):
        q=SharedQfController()
        q.update(60,states(1,1,1),True,0)
        self.assertEqual(q.update(60,states(1,1,2),True,1),1)
        q.manual_change()
        self.assertIsNone(q.update(1,states(1,1,3),True,2))
        self.assertIsNone(q.update(1,[],False,3))
        q=SharedQfController()
        q.update(60,states(1,1,1),True,0)
        self.assertEqual(q.update(60,states(1,1,2),True,1),1)
        self.assertEqual(q.update(1,[],True,2),60)

    def test_limit_does_not_change_enable_and_restores(self):
        class Detector:
            def run(self, frame, confidence): return []
            def close(self): pass
        y=DualYolo(lambda camera:Detector())
        try:
            y.configure([True,True],.1)
            y.set_intervals([.2,0])
            for i in range(10): y.offer(0,i,b'x',0)
            time.sleep(.05)
            self.assertEqual(y.snapshot()['completed'][0],1)
            self.assertEqual(y.snapshot()['enabled'],[True,True])
            y.set_intervals([0,0]); y.offer(0,20,b'x',0)
            time.sleep(.05)
            self.assertEqual(y.snapshot()['completed'][0],2)
        finally: y.close()


if __name__ == '__main__': unittest.main()
