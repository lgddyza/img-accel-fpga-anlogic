import json
from contextlib import closing
import sqlite3
import tempfile
import time
import unittest
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'rk'))
from detection_log import DetectionLog

class DetectionHistoryTests(unittest.TestCase):
    def test_missing_sd_mount_does_not_create_database(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder);(p/'model').write_bytes(b'model')
            logger=DetectionLog(None,p/'not_mounted'/'events.db',p/'model',encoder=lambda a,b:a,require_mount=p/'not_mounted')
            logger.thread.join(timeout=3)
            self.assertIn('SD',logger.snapshot()['error'])
            self.assertFalse((p/'not_mounted').exists())

    def test_retains_40_images_matched_to_result_and_survives_restart(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder);model=p/'model';model.write_bytes(b'model')
            logger=DetectionLog(None,p/'events.sqlite3',model,interval=0,encoder=lambda pixels,event:pixels,image_encoder=lambda pixels,event:pixels)
            boxes=[dict(label='crack',confidence=.8)]
            for i in range(45):
                logger.offer(i%2,i,f'image-{i}'.encode(),0,85,7,boxes,.1,12.5)
                deadline=time.monotonic()+3
                while logger.snapshot()['saved']<i+1 and time.monotonic()<deadline:time.sleep(.005)
                self.assertEqual(logger.snapshot()['saved'],i+1,logger.snapshot())
            logger.close()
            with closing(sqlite3.connect(p/'events.sqlite3')) as db:
                rows=db.execute('SELECT data,jpeg FROM events ORDER BY id').fetchall()
            self.assertEqual(len(rows),40)
            self.assertEqual([json.loads(data)['frame_id'] for data,_ in rows],list(range(5,45)))
            for data,jpeg in rows:
                event=json.loads(data)
                self.assertEqual(jpeg,f"image-{event['frame_id']}".encode())
                self.assertEqual(event['quality'],85)
                self.assertEqual((p/'detection_images'/event['image_file']).read_bytes(),jpeg)
            self.assertEqual(len(list((p/'detection_images').glob('*.png'))),40)
            again=DetectionLog(None,p/'events.sqlite3',model,interval=0,encoder=lambda pixels,event:pixels,image_encoder=lambda pixels,event:pixels)
            again.close()
            with closing(sqlite3.connect(p/'events.sqlite3')) as db:self.assertEqual(db.execute('SELECT count(*) FROM events').fetchone()[0],40)

    def test_empty_detections_are_not_saved(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder);(p/'model').write_bytes(b'model')
            logger=DetectionLog(None,p/'history.db',p/'model',interval=0,encoder=lambda a,b:a)
            logger.offer(0,1,b'pixels',0,85,0,[],.1,1)
            logger.close()
            with closing(sqlite3.connect(p/'history.db')) as db:self.assertEqual(db.execute('SELECT count(*) FROM events').fetchone()[0],0)

if __name__=='__main__':unittest.main()
