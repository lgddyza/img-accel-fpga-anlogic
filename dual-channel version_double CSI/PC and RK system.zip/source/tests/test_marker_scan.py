import random
import sys
import unittest
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'rk'))
import dual_csi_protocol as protocol


class ModeEnvelope(unittest.TestCase):
    def test_sobel_packet_is_accepted(self):
        header=protocol.HEADER.pack(b'DJP2',2,32,15,0,0,4,95,1920,1080,360,8,1,1,2)
        packet=header+b'\xff\xd8\xff\xd9'
        self.assertEqual(protocol.parse_packet(packet,1).mode,4)


@unittest.skipUnless(protocol._marker_scan, 'Native marker scanner is not available on this machine')
class NativeMarkerParity(unittest.TestCase):
    def test_incremental_framing_matches_python_reference(self):
        rng=random.Random(67123)
        jpeg=(b'\xff\xd8\xff\xe1\x00\x08A\xff\xd9BCD'
              b'\xff\xda\x00\x02' + b'A\xff\x00B\xff\xd0'*300 + b'\xff\xd9')
        header=protocol.HEADER.pack(b'DJP2',2,32,15,0,0,5,95,1920,1080,360,8,1,1,2)
        valid=header+jpeg
        broken=header+b'\xff\xd8\xff\xe1\x00\x01garbage'
        data=b'garbage'+valid+broken+valid+valid
        native=protocol._marker_scan
        fast=protocol.PacketStream(1);reference=protocol.PacketStream(1)
        cursor=0
        while cursor<len(data):
            size=rng.randrange(1,180)
            chunk=data[cursor:cursor+size];cursor+=len(chunk)
            protocol._marker_scan=native
            a=fast.feed(chunk)
            protocol._marker_scan=None
            b=reference.feed(chunk)
            protocol._marker_scan=native
            self.assertEqual(a,b)
            self.assertEqual(fast.diagnostics(),reference.diagnostics())
            self.assertEqual((fast.position,fast.entropy),(reference.position,reference.entropy))
        self.assertEqual(fast.complete_packets,3)
        self.assertGreater(fast.invalid_packets,0)

    def test_mutated_jpeg_streams_match_reference(self):
        rng=random.Random(81227)
        header=protocol.HEADER.pack(b'DJP2',2,32,15,0,0,5,95,1920,1080,360,8,1,1,2)
        source=header+b'\xff\xd8\xff\xe2\x00\x06abcd\xff\xda\x00\x02'+b'A\xff\x00B'*100+b'\xff\xd9'
        native=protocol._marker_scan
        try:
            for _ in range(150):
                corrupted=bytearray(source)
                for _ in range(rng.randrange(1,8)):
                    corrupted[rng.randrange(len(corrupted))]=rng.randrange(256)
                data=source+corrupted+source
                fast=protocol.PacketStream(1);reference=protocol.PacketStream(1)
                cursor=0
                while cursor<len(data):
                    chunk=data[cursor:cursor+rng.randrange(1,100)];cursor+=len(chunk)
                    protocol._marker_scan=native;a=fast.feed(chunk)
                    protocol._marker_scan=None;b=reference.feed(chunk)
                    self.assertEqual(a,b)
                    self.assertEqual(fast.diagnostics(),reference.diagnostics())
                    self.assertEqual((fast.position,fast.entropy),(reference.position,reference.entropy))
        finally:
            protocol._marker_scan=native


if __name__=='__main__':unittest.main()
