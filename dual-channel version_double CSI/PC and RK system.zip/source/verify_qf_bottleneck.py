"""Short, reversible QF comparison using the managed receiver's counters."""
import json
from pathlib import Path
import time
from transport import SSHTransport,default_key
from telemetry import redact

out=Path('verification/qf95_investigation_20261027')
out.mkdir(parents=True,exist_ok=True)
c=SSHTransport({'host':'169.254.53.76','key':str(default_key())})
original=None
records=[]
try:
    initial=c.rpc({'action':'status'})
    if initial.get('runtime')!='managed': raise RuntimeError('Managed video is not running')
    original=initial['hardware']['applied_quality']
    for quality in (95,85):
        c.rpc({'action':'configure','quality':quality})
        deadline=time.monotonic()+6
        while True:
            status=c.rpc({'action':'status'})
            if status['hardware']['applied_quality']==quality:break
            if time.monotonic()>deadline:raise RuntimeError('QF did not apply')
            time.sleep(.3)
        time.sleep(3)
        samples=[]
        for _ in range(11):
            samples.append(redact(c.rpc({'action':'status'})))
            time.sleep(1)
        a,b=samples[0]['live'],samples[-1]['live']
        dt=b['sample_s']-a['sample_s']
        def rates(key):
            return [(y-x)/dt for x,y in zip(a['counters'][key],b['counters'][key])]
        def delta32(x,y):return (y-x)&0xffffffff
        x,y=a['board']['statistics'],b['board']['statistics']
        before,after=a['counters'],b['counters']
        records.append(dict(qf=quality,seconds=dt,
            capture_fps=[delta32(x[i],y[i])/dt for i in (0,1)],
            fpga_delivery_fps=[delta32(x[i],y[i])/dt for i in (4,5)],
            complete_fps=rates('complete_frames'),decoded_fps=rates('decoded_frames'),
            display_fps=(b['display']['rendered']-a['display']['rendered'])/dt,
            dma_mbps=[8*(v-u)/dt/1e6 for u,v in zip(before['dma_bytes'],after['dma_bytes'])],
            dma_event_drops=after['queue_drops']-before['queue_drops'],
            decode_drops=[v-u for u,v in zip(before['decode_queue_drops'],after['decode_queue_drops'])],
            decode_timing=b['decoder']['timing'],display=b['display'],
            yolo=b['yolo'],fpga_drop_delta=[delta32(x[i],y[i]) for i in (2,3)],
            packet_streams=b['packet_streams'],resources=samples[-1]['resources'],
            raw_samples=samples))
        print('QF',quality,'capture',records[-1]['capture_fps'],'delivery',records[-1]['fpga_delivery_fps'],
            'decode',records[-1]['decoded_fps'],'HDMI',records[-1]['display_fps'],
            'queue drops',records[-1]['dma_event_drops'],flush=True)
finally:
    if original is not None:
        c.rpc({'action':'configure','quality':original})
        print('restored QF',original,flush=True)
    c.close()
    (out/'measurements.json').write_text(json.dumps(records,indent=2,ensure_ascii=False),encoding='utf-8')
