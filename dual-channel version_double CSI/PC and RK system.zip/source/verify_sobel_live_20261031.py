"""Measure the Sobel bitstream on the running board and restore its settings."""
import http.client
import json
import time
from email.parser import BytesHeaderParser
from pathlib import Path
from telemetry import redact
from transport import SSHTransport, default_key

OUT=Path('verification/sobel_board_20261031')
OUT.mkdir(parents=True,exist_ok=True)
c=SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
records=[]
original=None

def capture(live,camera,name):
    preview=live['preview']
    h=http.client.HTTPConnection('169.254.53.76',preview['port'],timeout=8)
    try:
        h.request('GET',f'/stream/{camera}',headers={'Authorization':'Bearer '+preview['token']})
        response=h.getresponse()
        if response.status!=200: raise RuntimeError(f'preview HTTP {response.status}')
        for _ in range(3):
            line=response.readline()
            while line.strip()!=b'--rkframe':
                if not line: raise RuntimeError('preview closed')
                line=response.readline()
            header=bytearray()
            while True:
                line=response.readline(32768);header.extend(line)
                if line==b'\r\n': break
            fields=BytesHeaderParser().parsebytes(bytes(header))
            image=response.read(int(fields['Content-Length']))
        (OUT/f'{name}_cam{camera}.jpg').write_bytes(image)
        return fields.get('X-Source-Frame')
    finally:
        h.close()

try:
    initial=c.rpc(dict(action='status'))
    if initial['runtime']!='managed' or initial['hardware']['supported_modes']!=0x3f:
        raise RuntimeError('Sobel-capable managed receiver required')
    word=initial['hardware']['requested']
    dqf=initial['hardware']['dual_qf']
    original=dict(mode_a=(word>>1)&7,mode_b=(word>>4)&7,
        quality_a=dqf&127,quality_b=(dqf>>8)&127,independent_qf=bool(dqf&(1<<16)),
        adaptive_enabled=bool((initial['live'].get('adaptive') or {}).get('enabled')))
    c.rpc(dict(action='configure',adaptive_enabled=False))
    cases=[('gray',0,0),('sobel_a',4,0),('sobel_b',0,4),('sobel_both',4,4)]
    for name,ma,mb in cases:
        c.rpc(dict(action='configure',mode_a=ma,mode_b=mb))
        time.sleep(4)
        a=c.rpc(dict(action='status'))
        time.sleep(10)
        b=c.rpc(dict(action='status'))
        if a['runtime']!='managed' or b['runtime']!='managed':
            raise RuntimeError(f'{name}: receiver stopped')
        x,y=a['live'],b['live']
        if x['pid']!=y['pid']: raise RuntimeError(f'{name}: receiver restarted')
        dt=y['sample_s']-x['sample_s']
        delta=lambda key:[v-u for u,v in zip(x['counters'][key],y['counters'][key])]
        row=dict(case=name,seconds=dt,requested_modes=[ma,mb],decoded_modes=y['decoded_modes'],
            decoded_fps=[v/dt for v in delta('decoded_frames')],
            hdmi_fps=(y['display']['rendered']-x['display']['rendered'])/dt,
            decode_queue_drops=delta('decode_queue_drops'),display_queue_drops=delta('display_queue_drops'),
            rejected=delta('decode_rejected_frames'),dma_errors=y['counters']['dma_errors'],
            decode_errors=y['counters']['decode_errors'],yolo_fps=(y.get('yolo') or {}).get('fps'),
            yolo_error=(y.get('yolo') or {}).get('error'),quality=y.get('decoded_quality'),
            dma_mbps=y['rates']['dma_mbps'])
        if row['decoded_modes']!=[ma,mb]: raise RuntimeError(f'{name}: modes did not apply: {row}')
        row['captured_frames']=[capture(y,i,name) for i in (0,1)]
        records.append(redact(row))
        (OUT/'results.json').write_text(json.dumps(records,indent=2,ensure_ascii=False),encoding='utf-8')
        print(json.dumps(row,ensure_ascii=True),flush=True)
finally:
    try:
        if original:
            c.rpc(dict(action='configure',**original))
            print('Restored original modes, QF and adaptive policy',flush=True)
    finally:
        c.close()
