"""Render the new diagnostic fields from recorded board data, without network I/O."""
import copy
import json
from pathlib import Path
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QFontDatabase
from PySide6.QtWidgets import QApplication
from app import Window
from telemetry import Rates

root = Path(__file__).resolve().parent
folder = root/'verification'/'hdmi_native_20261029'
samples = json.loads((folder/'buffer4_B'/'runtime_samples.json').read_text())
application = QApplication([])
if not QFontDatabase.families():
    for name in ('msyh.ttc','msyhbd.ttc','segoeui.ttf'):
        QFontDatabase.addApplicationFont('C:/Windows/Fonts/'+name)
application.setStyle('Fusion')
application.setFont(QFont('Microsoft YaHei UI',10))
window = Window(demo=True)
window.demo = False
window.linked = True
window.worker.submit = lambda *args, **kwargs: None
try:
    window.rates = Rates()
    window.rates.update(copy.deepcopy(samples[-2]['status']))
    window.update_status(copy.deepcopy(samples[-1]['status']))
    index = next(i for i in range(window.tabs.count()) if window.tabs.tabText(i)=='链路诊断')
    window.tabs.setCurrentIndex(index)
    window.show()
    labels = {window.diagnostics.item(row,0).text():row for row in range(window.diagnostics.rowCount())}
    for label in ('送显队列当前帧数 / 容量','显示提交至 HDMI 入口 P50 / ms','显示提交至 HDMI 入口 P95 / ms'):
        item = window.diagnostics.item(labels[label],2)
        assert item.text() not in ('—','None'), (label,item.text())
    for width,height in ((1360,850),(1000,700)):
        window.resize(width,height)
        application.processEvents()
        assert window.diagnostics.isVisible()
        window.grab().save(str(folder/f'diagnostics_{width}.png'))
    print('Live-status diagnostic fields rendered at both window sizes')
finally:
    window.close()
