"""Create a verified, credential-free archive of the fast adaptive release."""
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

from transport import SSHTransport, default_key
from telemetry import redact

root = Path(__file__).resolve().parent
name = 'RK_PC_DUAL_FAST_ADAPTIVE_20261030'
target = Path('D:/RK_PROJECT_ARCHIVE') / name
archive_path = target.with_suffix('.zip')
if target.exists() or archive_path.exists():
    raise SystemExit('Archive path already exists; select a new name.')
target.mkdir(parents=True)
shutil.copy2(root/'归档说明_20261030.md', target/'README.md')
shutil.copy2(root/'验证记录.md', target/'验证记录.md')
shutil.copytree(root/'dist_fast_adaptive'/'RKDualVisionHost', target/'pc'/'RKDualVisionHost')
source = target/'source'
source.mkdir()
for p in root.iterdir():
    if p.is_file() and p.suffix in ('.py', '.txt'):
        shutil.copy2(p, source/p.name)
for folder in ('rk', 'tests'):
    shutil.copytree(root/folder, source/folder, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
for p in ('rk_payload.zip', 'rk_payload_manifest.json'):
    shutil.copy2(root/p, source/p)
ui_fixture = source/'adaptive_policy_20261029'/'default_off'/'runtime_samples.json'
ui_fixture.parent.mkdir(parents=True)
ui_fixture.write_text(json.dumps(redact(json.loads((root/'adaptive_policy_20261029'/'default_off'/'runtime_samples.json').read_text())),
                                 ensure_ascii=False), encoding='utf-8')
original = Path('E:/FPGA/workspace/RK_DUAL_YOLO_PRF1_20261027/verification/road_parallel.cpp')
native = source/'rk'/'native_source'
native.mkdir()
shutil.copy2(original, native/original.name)
evidence = target/'verification'
evidence.mkdir()
for p in ('baseline.json', 'candidate_samples.json', 'qf_transition_1.json'):
    shutil.copy2(root/'verification'/'adaptive_qf_20261029'/p, evidence/p)
shutil.copytree(root/'verification'/'adaptive_qf_20261029'/'ui', evidence/'ui')
assert (source/'rk_payload.zip').read_bytes() == (target/'pc'/'RKDualVisionHost'/'_internal'/'rk_payload.zip').read_bytes()
assert (source/'board_agent.py').read_bytes() == (target/'pc'/'RKDualVisionHost'/'_internal'/'board_agent.py').read_bytes()

remote_files = [
    '/root/road_damage_yolov8n/road_damage_yolov8n_gray640_int8_rk3576.rknn',
    '/root/road_damage_yolov8n/area_resize_20261027/rk3576_benchmark.cpp',
    '/root/road_damage_yolov8n/area_resize_20261027/rknn_api.h',
    '/root/jpeg_rk/capture_jpeg_tiles.py', '/root/jpeg_rk/libjpeg_native.so',
    '/root/jpeg_rk/libjpeg_weave.so', '/root/jpeg_rk/jpeg_native.c', '/root/jpeg_rk/jpeg_weave.c',
    '/lib/modules/6.1.99/extra/anlogic_pci.ko',
]
connection = SSHTransport(dict(host='169.254.53.76', key=str(default_key())))
try:
    with connection.client.open_sftp() as sftp:
        for path in remote_files:
            local = target/'rk_board_dependencies'/path.lstrip('/')
            local.parent.mkdir(parents=True, exist_ok=True)
            sftp.get(path, str(local))
            _, stdout, stderr = connection.client.exec_command('sha256sum '+path, timeout=20)
            output = stdout.read().decode().split()
            if stdout.channel.recv_exit_status() or not output or hashlib.sha256(local.read_bytes()).hexdigest() != output[0]:
                raise RuntimeError('Remote file verification failed: '+path+' '+stderr.read().decode(errors='replace'))
    command = ('uname -a; cat /etc/os-release; python3 --version; modinfo anlogic_pci; '
               'ldd /root/dual_vision_host/releases/996d9dfcf768ff52/libroad_parallel0.so; '
               'gst-launch-1.0 --version; pkg-config --modversion opencv4')
    _, stdout, stderr = connection.client.exec_command(command, timeout=30)
    env = stdout.read()+stderr.read()
    (target/'board_environment.txt').write_bytes(env)
finally:
    connection.close()

manifest = {p.relative_to(target).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(target.rglob('*')) if p.is_file()}
(target/'MANIFEST.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding='utf-8')
with zipfile.ZipFile(archive_path, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in sorted(target.rglob('*')):
        if path.is_file():
            archive.write(path, path.relative_to(target).as_posix())
with zipfile.ZipFile(archive_path) as archive:
    if archive.testzip() is not None:
        raise RuntimeError('ZIP CRC verification failed')
    for name, digest in manifest.items():
        if hashlib.sha256(archive.read(name)).hexdigest() != digest:
            raise RuntimeError('ZIP file verification failed: '+name)
digest = hashlib.sha256(archive_path.read_bytes()).hexdigest()
archive_path.with_suffix('.zip.sha256').write_text(digest+'  '+archive_path.name+'\n', encoding='ascii')
print(json.dumps(dict(directory=str(target), archive=str(archive_path), files=len(manifest),
                      size_bytes=archive_path.stat().st_size, sha256=digest), ensure_ascii=False, indent=2))
