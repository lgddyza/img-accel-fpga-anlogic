"""Read-only board inspection; never print preview credentials."""
import json
from transport import SSHTransport, default_key
from telemetry import redact

c = SSHTransport(dict(host='169.254.53.76', key=str(default_key())))
try:
    print(json.dumps(redact(c.rpc(dict(action='status'))), indent=2))
    commands = [
        'cat /sys/kernel/debug/dri/0/state',
        'cat /sys/kernel/debug/dri/0/summary',
        'gst-inspect-1.0 kmssink',
        'gst-inspect-1.0 textoverlay | head -45',
        'ls /sys/kernel/debug/tracing/events/drm; which gcc; pkg-config --modversion gstreamer-video-1.0 libdrm',
        'tail -8 /root/dual_vision_host/run/receiver.log',
    ]
    for cmd in commands:
        _, out, err = c.client.exec_command(cmd, timeout=12)
        print(cmd, out.read().decode(errors='replace'), err.read().decode(errors='replace'))
finally:
    c.close()
