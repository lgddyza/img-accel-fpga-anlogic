"""Deploy the display probe fix while preserving the user's current settings."""
import argparse
import json
from pathlib import Path
import shlex
import time
from telemetry import redact
from transport import SSHTransport, default_key

root = Path(__file__).resolve().parent
dest = root/'verification'/'hdmi_native_20261029'
parser = argparse.ArgumentParser()
parser.add_argument('--rollback', action='store_true')
args = parser.parse_args()
old = json.loads((dest/'before'/'rk_payload_manifest.json').read_text())
new = json.loads((root/'rk_payload_manifest.json').read_text())
changed = sorted(k for k in set(old)|set(new) if old.get(k) != new.get(k))
expected = sorted(['display_metrics.py','dual_hdmi_bringup.py','display_probe.c',
                   'native_display_probe.py','verify_display_probe.py','libdisplay_probe.so'])
assert args.rollback or changed == expected, changed
c = SSHTransport(dict(host='169.254.53.76', key=str(default_key())))

def remote(command):
    _, out, err = c.client.exec_command(command, timeout=30)
    text = out.read().decode()
    error = err.read().decode()
    if out.channel.recv_exit_status():
        raise RuntimeError(error)
    return text

try:
    before = c.rpc(dict(action='status'))
    quality, display = before['hardware']['applied_quality'], before['live']['selected']
    previous_file = dest/'board_before.json'
    if not previous_file.exists():
        previous_file.write_text(json.dumps(dict(
            release=remote('cat /root/dual_vision_host/bundle.path').strip(),
            status=redact(before)), indent=2))
    previous = json.loads(previous_file.read_text())['release']
    assert previous.startswith('/root/dual_vision_host/releases/')
    def rollback():
        c.rpc(dict(action='stop'))
        code='from pathlib import Path;Path("/root/dual_vision_host/bundle.path").write_text('+repr(previous)+')'
        remote('python3 -c '+shlex.quote(code))
        c.rpc(dict(action='start', quality=quality, display=display))
    if args.rollback:
        rollback()
        print('Restored '+previous)
    else:
        try:
            c.install()
            c.rpc(dict(action='stop'))
            c.rpc(dict(action='start', quality=quality, display=display))
            time.sleep(4)
            after=c.rpc(dict(action='status'))
            live=after['live']
            assert live['display']['probe_backend']=='native'
            assert live['yolo']['enabled']==before['live']['yolo']['enabled']
            assert live['yolo']['confidence']==before['live']['yolo']['confidence']
            assert not live['yolo']['error'] and not live['preview']['error']
            assert not live['detection_log']['error']
            assert after['hardware']['requested']==before['hardware']['requested']
            result=dict(release=remote('cat /root/dual_vision_host/bundle.path').strip(),
                        changed_files=changed, quality=quality, display=display,
                        probe_backend=live['display']['probe_backend'])
            (dest/'deployed.json').write_text(json.dumps(result,indent=2))
            print(json.dumps(result,indent=2))
        except BaseException:
            rollback()
            raise
finally:
    c.close()
