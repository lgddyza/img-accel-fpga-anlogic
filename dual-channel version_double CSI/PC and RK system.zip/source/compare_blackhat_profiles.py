"""Software parameter ablation using one captured luminance image."""
from pathlib import Path
import json
import numpy as np
from PIL import Image, ImageDraw

out=Path('verification/live_fixed_20261029/hdmi_1080')
raw=np.asarray(Image.open(out/'mode_0.pgm').convert('L'),dtype=np.uint8)

def extreme(image, offsets, maximum):
    radius=max(max(abs(y),abs(x)) for y,x in offsets)
    padded=np.pad(image,((radius,radius),(radius,radius)),mode='edge')
    h,w=image.shape
    stacks=[padded[radius+y:radius+y+h,radius+x:radius+x+w] for y,x in offsets]
    return (np.maximum.reduce if maximum else np.minimum.reduce)(stacks)

def profile(kernel,gain):
    r=kernel//2
    rect=[(y,x) for y in range(-r,r+1) for x in range(-r,r+1)]
    close=extreme(extreme(raw,rect,True),rect,False)
    response=np.maximum(close.astype(np.int16)-raw.astype(np.int16),0).astype(np.uint8)
    directions=[[(0,i) for i in range(-2,3)],[(i,0) for i in range(-2,3)],
                [(i,i) for i in range(-2,3)],[(i,-i) for i in range(-2,3)]]
    filtered=np.maximum.reduce([extreme(extreme(response,d,False),d,True) for d in directions])
    output=np.clip(np.rint(raw.astype(np.float32)-gain*filtered),0,255).astype(np.uint8)
    return output,filtered

images={'gray':raw}; report={}
for name,k,gain in [('current_k3_gain1',3,1),('old_k7_gain05',7,.5)]:
    result,response=profile(k,gain)
    images[name]=result
    Image.fromarray(result).save(out/(name+'_software.png'))
    report[name]={'mean_response':float(response.mean()),'response_nonzero_percent':float((response>0).mean()*100),
                  'mean_absolute_change':float(np.abs(result.astype(np.int16)-raw).mean())}
    print(name,report[name],flush=True)
(out/'blackhat_profile_comparison.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
panel=Image.new('RGB',(1575,480),'white'); draw=ImageDraw.Draw(panel)
for i,(name,label) in enumerate([('gray','Captured gray'),('current_k3_gain1','Software K3 gain1'),('old_k7_gain05','Software K7 gain0.5')]):
    crop=Image.fromarray(images[name]).crop((150,0,1200,900)).resize((525,450))
    panel.paste(crop.convert('RGB'),(i*525,25));draw.text((i*525+8,5),label,fill='black')
panel.save(out/'blackhat_profile_comparison.png')
