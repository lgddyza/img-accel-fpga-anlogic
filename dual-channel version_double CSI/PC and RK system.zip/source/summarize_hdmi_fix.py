"""Summarize preserved experiment windows using the display's own clock."""
import json
from pathlib import Path

root = Path(__file__).resolve().parent/'verification'/'hdmi_native_20261029'
summary = []
for name in ('baseline_A','native_A','submit_A','buffer4_A','buffer3_A',
             'baseline_gauss_A','final_B','final_A120','buffer4_A120','buffer4_B'):
    folder = root/name
    if not (folder/'result.json').exists():
        continue
    result = json.loads((folder/'result.json').read_text())
    if 'seconds' not in result:
        continue
    records = json.loads((folder/'runtime_samples.json').read_text())
    last = records[-1]
    first = min(records,key=lambda r:abs(last['pc_time']-r['pc_time']-result['seconds']))
    a,b = first['status']['live'],last['status']['live']
    da,db = a['display'],b['display']
    dt = db['sample_s']-da['sample_s']
    converted = db['convert_frames']-da['convert_frames']
    rendered = db['rendered']-da['rendered']
    overrun = db.get('present_queue_overrun_events',0)-da.get('present_queue_overrun_events',0)
    window = [r['status']['live'] for r in records if r['pc_time']>=first['pc_time']]
    age50 = [r['display'].get('submit_to_sink_ms_p50') for r in window]
    age50 = [x for x in age50 if x is not None]
    summary.append(dict(run=name,display_seconds=dt,camera=b['selected'],
        quality=last['status']['hardware']['applied_quality'],
        modes_seen=sorted({tuple(r['decoded_modes']) for r in window}),
        preview_clients_seen=sorted({tuple(r['preview']['clients']) for r in window}),
        decoded_fps=result['decoded_fps'],hdmi_fps=rendered/dt,
        converted=converted,rendered=rendered,converted_minus_rendered=converted-rendered,
        present_overruns=overrun,present_overruns_per_minute=overrun*60/dt,
        pipeline_age_window_p50_mean_ms=sum(age50)/len(age50) if age50 else None,
        decode_queue_drops=result['decode_queue_drops'],
        yolo_fps=result['yolo_fps'],sd_saved=result['sd_saved_delta'],
        original_strict_gate_passed=result['passed']))
(root/'comparison.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
