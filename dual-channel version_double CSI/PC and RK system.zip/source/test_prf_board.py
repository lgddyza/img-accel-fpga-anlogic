"""Measure PRF1 modes through the deployed control agent; retain raw samples."""
import json
import time
from pathlib import Path

from transport import SSHTransport, default_key
from telemetry import redact

OUT = Path('verification/prf1_board_20261027')
OUT.mkdir(parents=True, exist_ok=True)
cases = [
    ('gray', dict(mode_a=0, mode_b=0, display=0)),
    ('gauss_quarter', dict(mode_a=1, mode_b=1, gauss_a=1, gauss_b=1, display=1)),
    ('blackhat', dict(mode_a=5, mode_b=5, display=0)),
    ('gauss_blackhat', dict(mode_a=1, mode_b=5, gauss_a=1, display=1)),
    ('blackhat_gauss', dict(mode_a=5, mode_b=1, gauss_b=1, display=0)),
    ('gray_restored', dict(mode_a=0, mode_b=0, display=1)),
]
client = SSHTransport(dict(host='169.254.53.76', key=str(default_key())))
results = []
try:
    for label, options in cases:
        print('CASE', label, flush=True)
        row = dict(case=label, requested=options, samples=[])
        results.append(row)
        client.rpc(dict(action='configure', **options))
        time.sleep(3)
        for _ in range(11):
            status = redact(client.rpc(dict(action='status')))
            row['samples'].append(status)
            (OUT/'samples.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
            if status['runtime'] != 'managed':
                row['error'] = 'receiver stopped or status stale'
                print('STOPPED', label, flush=True)
                break
            time.sleep(1)
        if row.get('error'):
            break
        start, end = row['samples'][0]['live'], row['samples'][-1]['live']
        dt = end['sample_s'] - start['sample_s']
        a, b = start['counters'], end['counters']
        delta = lambda key: [v-u for u, v in zip(a[key], b[key])]
        row['summary'] = dict(seconds=dt, decoded_fps=[n/dt for n in delta('decoded_frames')],
            hdmi_fps=(end['display']['rendered']-start['display']['rendered'])/dt,
            hdmi_camera=end['selected'], decode_drops=delta('decode_queue_drops'),
            jpeg_rejected=delta('decode_rejected_frames'),
            dma_errors=b['dma_errors'], decode_errors=b['decode_errors'],
            queue_drops=b['queue_drops']-a['queue_drops'],
            packet_invalid=[y['invalid_packets']-x['invalid_packets'] for x,y in zip(start['packet_streams'],end['packet_streams'])],
            displayed_mode=end['display'].get('osd_text'),
            feature_observations=(row['samples'][-1]['hardware'] or {}).get('feature_observations'))
        print(json.dumps(row['summary'], ensure_ascii=False), flush=True)
        (OUT/'samples.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
finally:
    client.close()
