"""Run the native converter regression on RK and retain its output."""
from pathlib import Path
from transport import SSHTransport, default_key

c=SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
try:
    base='/root/dual_vision_host/build_display/'
    with c.client.open_sftp() as ftp:
        ftp.put('rk/verify_display_plugin.py',base+'verify_display_plugin.py')
    _,out,err=c.client.exec_command('python3 '+base+'verify_display_plugin.py '+base+'libgstrkdualdisplay.so',timeout=30)
    output=out.read().decode()+err.read().decode()
    Path('verification/native_display.txt').write_text(output,encoding='utf-8')
    print(output)
    assert out.channel.recv_exit_status()==0,'Pixel verification failed'
finally:
    c.close()
