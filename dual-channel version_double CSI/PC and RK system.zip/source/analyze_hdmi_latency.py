"""Correlate source SOF observations, per-frame Python trace and DRM commits."""
import bisect
import csv
import json
from pathlib import Path
import statistics

root=Path(__file__).resolve().parent/'verification/hdmi_latency_20261026'
trace=json.loads((root/'frame_trace.json').read_text())
windows=json.loads((root/'windows.json').read_text())
status=json.loads((root/'runtime_samples.json').read_text())
events={}
for event,camera,frame,stamp,value in trace:
    events.setdefault((camera,frame),{})[event]=(stamp,value)
source={}
ticks=[]
with (root/'source.csv').open(newline='') as file:
    for row in csv.DictReader(file):
        lo,hi=float(row['lower_s']),float(row['upper_s'])
        value=int(row['value'])
        if row['event']=='S':
            source[(int(row['camera']),value&0x0fffffff)]=(lo,hi)
        else:
            ticks.append(((lo+hi)/2,value,hi-lo))
commits={}
ioctl_failures=0
with (root/'ioctl.csv').open(newline='') as file:
    for camera,frame,began,ended,request,result in csv.reader(file):
        if int(result):
            ioctl_failures+=1
            continue
        commits[(int(camera),int(frame))]=(float(began),float(ended),int(request))


def dist(values):
    values=sorted(values)
    if not values:
        return dict(samples=0)
    return dict(samples=len(values),mean_ms=statistics.mean(values),min_ms=values[0],
        p50_ms=statistics.median(values),p95_ms=values[int(.95*(len(values)-1))],
        p99_ms=values[int(.99*(len(values)-1))],max_ms=values[-1])


valid_ticks=[t for t in ticks if windows[0]['start_s']-1 <= t[0] <= windows[-1]['end_s']+1]
unwrapped=[valid_ticks[0][1]]
for a,b in zip(valid_ticks,valid_ticks[1:]):
    unwrapped.append(unwrapped[-1]+((b[1]-a[1])&0xffffffff))
frequency=(unwrapped[-1]-unwrapped[0])/(valid_ticks[-1][0]-valid_ticks[0][0])
tick_times=[t[0] for t in ticks]


def schedule_time(event):
    stamp,tick=event
    index=bisect.bisect_left(tick_times,stamp)
    candidates=ticks[max(0,index-1):index+1]
    anchor=min(candidates,key=lambda t:abs(t[0]-stamp))
    delta=((tick-anchor[1]+0x80000000)&0xffffffff)-0x80000000
    return anchor[0]+delta/frequency


results=[]
rows=[]
for window in windows:
    camera=window['camera']
    selected=[(key,value) for key,value in events.items()
        if key[0]==camera and 'kms_entry' in value
        and window['start_s'] <= value['kms_entry'][0] <= window['end_s']]
    spans={name:[] for name in ('source_to_kms_entry','source_to_drm_accepted',
        'source_to_packet','source_to_schedule','schedule_to_packet','decode_queue',
        'decode','decode_done_to_appsrc','appsrc_to_kms_entry','kms_entry_to_drm_accepted',
        'drm_ioctl','source_observation_uncertainty')}
    misses=dict(source=0,commit=0,stages=0)
    for key,stages in selected:
        if key not in source:
            misses['source']+=1
            continue
        if key not in commits:
            misses['commit']+=1
            continue
        required=('packet_complete','decode_begin','decode_done','appsrc_begin','appsrc_done','kms_entry')
        if any(stage not in stages for stage in required):
            misses['stages']+=1
            continue
        lo,hi=source[key]
        sof=(lo+hi)/2
        packet=stages['packet_complete'][0]
        schedule=schedule_time(stages['packet_complete'])
        decode_begin=stages['decode_begin'][0]
        decode_done=stages['decode_done'][0]
        appsrc=stages['appsrc_begin'][0]
        kms=stages['kms_entry'][0]
        drm_begin,drm_end,request=commits[key]
        values=dict(source_to_kms_entry=(kms-sof)*1000,
            source_to_drm_accepted=(drm_end-sof)*1000,
            source_to_packet=(packet-sof)*1000,
            source_to_schedule=(schedule-sof)*1000,
            schedule_to_packet=(packet-schedule)*1000,
            decode_queue=(decode_begin-packet)*1000,
            decode=(decode_done-decode_begin)*1000,
            decode_done_to_appsrc=(appsrc-decode_done)*1000,
            appsrc_to_kms_entry=(kms-appsrc)*1000,
            kms_entry_to_drm_accepted=(drm_end-kms)*1000,
            drm_ioctl=(drm_end-drm_begin)*1000,
            source_observation_uncertainty=(hi-lo)*1000)
        if any(value < 0 for value in values.values()):
            raise ValueError(f'Non-monotonic frame trace: {key}: {values}')
        for name,value in values.items():
            spans[name].append(value)
        rows.append(dict(camera=camera,frame_id=key[1],source_lower_s=lo,source_upper_s=hi,
            packet_s=packet,schedule_s=schedule,kms_entry_s=kms,drm_accepted_s=drm_end,
            drm_request=request,**values))
    samples=[s for s in status if s.get('live') and window['start_s']<=s['live']['sample_s']<=window['end_s']]
    a,b=samples[0]['live'],samples[-1]['live']
    dt=b['sample_s']-a['sample_s']
    delta=lambda name:[y-x for x,y in zip(a['counters'][name],b['counters'][name])]
    ordered=sorted(selected,key=lambda item:item[1]['kms_entry'][0])
    steps=[(right[0][1]-left[0][1])&0x0fffffff
        for left,right in zip(ordered,ordered[1:])]
    results.append(dict(camera=camera,seconds=dt,sink_frames=len(selected),unmatched=misses,
        latency={name:dist(values) for name,values in spans.items()},
        decoded_fps=[value/dt for value in delta('decoded_frames')],
        hdmi_fps=(b['display']['rendered']-a['display']['rendered'])/dt,
        preview_fps=[(y-x)/dt for x,y in zip(a['preview']['frames'],b['preview']['frames'])],
        decode_queue_drops=delta('decode_queue_drops'),
        display_queue_drops=delta('display_queue_drops'),
        jpeg_rejected=delta('decode_rejected_frames'),
        source_id_repeats=sum(step==0 for step in steps),
        source_id_gaps=sum(step-1 for step in steps if 0<step<0x08000000),
        present_queue_overrun_events=b['display']['present_queue_overrun_events']-a['display']['present_queue_overrun_events'],
        sink_dropped=b['display']['sink_dropped']-a['display']['sink_dropped'],
        receive_queue_drops=b['counters']['queue_drops']-a['counters']['queue_drops']))

if not rows:
    raise ValueError('No fully correlated HDMI frames; no latency result is available')
if len(rows)!=len({(row['camera'],row['frame_id']) for row in rows}):
    raise ValueError('Duplicate camera/frame IDs in correlated results')
summary=dict(boundary='FPGA cropped active-frame SOF to successful DRM SETPLANE/ATOMIC ioctl return; not glass-to-glass',
    tick_hz_measured=frequency,ioctl_failures=ioctl_failures,
    source_monitor=(root/'monitor.log').read_text(),cameras=results)
(root/'summary.json').write_text(json.dumps(summary,indent=2))
with (root/'per_frame.csv').open('w',newline='') as file:
    writer=csv.DictWriter(file,fieldnames=list(rows[0]))
    writer.writeheader();writer.writerows(rows)
print(json.dumps(summary,indent=2))
