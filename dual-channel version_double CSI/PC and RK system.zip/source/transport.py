"""Reuse the archived SSH/serial transport with a separate dual-camera payload."""
import base64
import hashlib
import shlex
import uuid
import legacy_transport as legacy

REMOTE_ROOT = '/root/dual_vision_host'
legacy.REMOTE = REMOTE_ROOT+'/board_agent.py'
DATA_DIR, default_key, provision_key = legacy.DATA_DIR, legacy.default_key, legacy.provision_key


def install_code(digest):
    return f'''from pathlib import Path
import hashlib,zipfile,os,tempfile
r=Path({REMOTE_ROOT!r})
p=r/'payload.zip'
assert hashlib.sha256(p.read_bytes()).hexdigest()=={digest!r}
d=r/'releases'/{digest[:16]!r}
z=zipfile.ZipFile(p)
assert all(Path(n).name==n for n in z.namelist())
(r/'releases').mkdir(exist_ok=True)
if d.exists():
    assert all((d/n).read_bytes()==z.read(n) for n in z.namelist()),'Existing release differs'
else:
    stage=Path(tempfile.mkdtemp(prefix='stage_',dir=r/'releases'))
    for n in z.namelist():
        (stage/n).write_bytes(z.read(n))
    stage.rename(d)
s=r/'bundle.tmp'
s.write_text(str(d))
os.replace(s,r/'bundle.path')
'''


class SSHTransport(legacy.SSHTransport):
    def install(self):
        payload = legacy.asset('rk_payload.zip').read_bytes()
        digest = hashlib.sha256(payload).hexdigest()
        with self.client.open_sftp() as sftp:
            try:
                sftp.mkdir(REMOTE_ROOT)
            except OSError:
                sftp.stat(REMOTE_ROOT)
            for name, data in [('payload.zip', payload), ('board_agent.py', legacy.asset('board_agent.py').read_bytes())]:
                with sftp.open(REMOTE_ROOT+'/'+name+'.upload', 'wb') as file:
                    file.write(data)
                with sftp.open(REMOTE_ROOT+'/'+name+'.upload', 'rb') as file:
                    if hashlib.sha256(file.read()).digest() != hashlib.sha256(data).digest():
                        raise legacy.RpcError('部署文件校验失败')
                sftp.posix_rename(REMOTE_ROOT+'/'+name+'.upload', REMOTE_ROOT+'/'+name)
        _, stdout, stderr = self.client.exec_command('python3 -c '+shlex.quote(install_code(digest)), timeout=20)
        stdout.read()
        if stdout.channel.recv_exit_status():
            raise legacy.RpcError(stderr.read(4000).decode(errors='replace'))


class SerialTransport(legacy.SerialTransport):
    def install(self):
        self.checked(f"from pathlib import Path;Path({REMOTE_ROOT!r}).mkdir(exist_ok=True)")
        payload = legacy.asset('rk_payload.zip').read_bytes()
        for name, data in [('payload.zip', payload), ('board_agent.py', legacy.asset('board_agent.py').read_bytes())]:
            for i in range(0, len(data), 1000):
                encoded = base64.b64encode(data[i:i+1000]).decode()
                self.checked(f"import base64;open({(REMOTE_ROOT+'/'+name+'.upload')!r},"
                    f"{'wb' if i==0 else 'ab'!r}).write(base64.b64decode({encoded!r}))")
            self.checked(f"import hashlib,os;p={(REMOTE_ROOT+'/'+name+'.upload')!r};"
                f"assert hashlib.sha256(open(p,'rb').read()).hexdigest()=={hashlib.sha256(data).hexdigest()!r};"
                f"os.replace(p,{(REMOTE_ROOT+'/'+name)!r})")
        self.checked(install_code(hashlib.sha256(payload).hexdigest()))

    def checked(self, code):
        token = 'UP_'+uuid.uuid4().hex+':'
        command = legacy.encoded_code(code+f"\nprint({token+'OK'!r})")
        self.execute(command, token, 20)
