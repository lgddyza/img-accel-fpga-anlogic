"""Build two separate LINEAR detector libraries on RK and retain AREA copies."""
import hashlib
from pathlib import Path
from transport import SSHTransport, default_key

root=Path(__file__).resolve().parent
source=root.parent/'road_damage_yolov8n'
work=root/'linear_resize_20261029'
work.mkdir(exist_ok=True)
old=work/'area_backup'
old.mkdir(exist_ok=True)
for i in (0,1):
    p=root/'rk'/f'libroad_parallel{i}.so'
    backup=old/p.name
    if not backup.exists(): backup.write_bytes(p.read_bytes())
    elif backup.read_bytes()!=p.read_bytes(): raise RuntimeError('Existing backup differs from current library')
benchmark=(source/'preproc_area_model_20261027/deployment/before/rk3576_benchmark.cpp').read_text(encoding='utf-8')
infer=(source/'rk3576_infer.cpp').read_text(encoding='utf-8')
assert infer.count('int road_init(const char* path)')==1
assert infer.count('rknn_set_core_mask(context, RKNN_NPU_CORE_0_1)')==1
infer=infer.replace('int road_init(const char* path)', 'int road_init_core(const char* path, int core)')
infer=infer.replace('rknn_set_core_mask(context, RKNN_NPU_CORE_0_1)',
                    'rknn_set_core_mask(context, core == 0 ? RKNN_NPU_CORE_0 : RKNN_NPU_CORE_1)')
(work/'rk3576_benchmark.cpp').write_text(benchmark,encoding='utf-8')
(work/'rk3576_infer.cpp').write_text(infer,encoding='utf-8')
verify='''#define ROAD_LIBRARY\n#include "rk3576_benchmark.cpp"\n#include <iostream>\nint main(){cv::Mat img(1080,1920,CV_8UC1);cv::randu(img,0,256);auto a=prepare(img);auto b=prepare_reference(img);if(cv::countNonZero(a.rgb.reshape(1)!=b.rgb.reshape(1))) return 1;std::cout<<"LINEAR prepare matches OpenCV INTER_LINEAR"<<std::endl;return 0;}\n'''
(work/'verify_linear.cpp').write_text(verify,encoding='utf-8')
c=SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
remote='/root/dual_vision_host/linear_build_20261029'
try:
    def cmd(command):
        _,o,e=c.client.exec_command(command,timeout=90)
        stdout=o.read().decode(errors='replace');stderr=e.read().decode(errors='replace')
        if o.channel.recv_exit_status(): raise RuntimeError(stderr+'\n'+stdout)
        print(stdout,flush=True)
    cmd('mkdir -p '+remote)
    with c.client.open_sftp() as ftp:
        for name in ('rk3576_benchmark.cpp','rk3576_infer.cpp','verify_linear.cpp'):
            ftp.put(str(work/name),remote+'/'+name)
        ftp.get('/root/road_damage_yolov8n/rknn_api.h',str(work/'rknn_api.h'))
        ftp.put(str(work/'rknn_api.h'),remote+'/rknn_api.h')
    cmd('cd '+remote+' && g++ -O3 -std=c++17 -fPIC -shared rk3576_infer.cpp -I. -o libroad_parallel.so $(pkg-config --cflags --libs opencv4) -lrknnrt && g++ -O3 -std=c++17 verify_linear.cpp -I. -o verify_linear $(pkg-config --cflags --libs opencv4) -lrknnrt && ./verify_linear && nm -D libroad_parallel.so | grep road_init_core')
    with c.client.open_sftp() as ftp:
        ftp.get(remote+'/libroad_parallel.so',str(work/'libroad_parallel.so'))
    lib=(work/'libroad_parallel.so').read_bytes()
    for i in (0,1): (root/'rk'/f'libroad_parallel{i}.so').write_bytes(lib)
    print('LINEAR library sha256',hashlib.sha256(lib).hexdigest(),flush=True)
finally: c.close()
