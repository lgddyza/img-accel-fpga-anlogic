from pathlib import Path
import json
import shlex
from transport import SSHTransport, default_key

c = SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
try:
    c.rpc(dict(action='stop'))
    with c.client.open_sftp() as ftp:
        ftp.put('rk/benchmark_display.py','/root/dual_vision_host/run/benchmark_display.py')
    _, out, err = c.client.exec_command('python3 /root/dual_vision_host/run/benchmark_display.py',timeout=40)
    data = out.read().decode()
    errors = err.read().decode(errors='replace')
    Path('verification/display_microbenchmark.txt').write_text(data+'\n'+errors,encoding='utf-8')
    print(data, errors)
finally:
    c.rpc(dict(action='start',display=1,quality=85,connector=188))
    c.close()
