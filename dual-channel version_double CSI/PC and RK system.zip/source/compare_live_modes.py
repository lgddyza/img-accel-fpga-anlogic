"""Capture consecutive preview frames for each mode; restore camera A selection."""
import http.client
import argparse
import time
from email.parser import BytesHeaderParser
from pathlib import Path
from transport import SSHTransport, default_key

parser = argparse.ArgumentParser()
parser.add_argument('--out', default='verification/live_mode_compare_20261029')
out = Path(parser.parse_args().out)
out.mkdir(parents=True, exist_ok=True)
c = SSHTransport(dict(host='169.254.53.76', key=str(default_key())))
original = None
try:
    s = c.rpc(dict(action='status'))
    original = (s['hardware']['requested'] >> 1) & 7
    for mode in (0, 1, 5, 0):
        c.rpc(dict(action='configure', mode_a=mode))
        time.sleep(3)
        s = c.rpc(dict(action='status'))
        if s['live']['decoded_modes'][0] != mode:
            raise RuntimeError('Output mode did not change')
        p = s['live']['preview']
        h = http.client.HTTPConnection('169.254.53.76', p['port'], timeout=5)
        try:
            h.request('GET', '/stream/0', headers={'Authorization': 'Bearer '+p['token']})
            r = h.getresponse()
            if r.status != 200: raise RuntimeError('Preview HTTP '+str(r.status))
            for _ in range(5):
                line = r.readline()
                while line.strip() != b'--rkframe':
                    if not line: raise RuntimeError('Stream closed')
                    line = r.readline()
                header = bytearray()
                while True:
                    line = r.readline(32768); header.extend(line)
                    if line == b'\r\n': break
                fields = BytesHeaderParser().parsebytes(bytes(header))
                data = r.read(int(fields['Content-Length']))
            name = 'gray_after' if mode == 0 and (out/'mode_0.jpg').exists() else 'mode_'+str(mode)
            (out/(name+'.jpg')).write_bytes(data)
            print(name, 'frame', fields.get('X-Source-Frame'), flush=True)
        finally:
            h.close()
finally:
    if original is not None: c.rpc(dict(action='configure', mode_a=original))
    c.close()
