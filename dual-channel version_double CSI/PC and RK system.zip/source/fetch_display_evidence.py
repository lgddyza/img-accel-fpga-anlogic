"""Fetch requested sink pixels and timing traces; no live per-frame capture."""
from pathlib import Path
from transport import SSHTransport, default_key

dest=Path('verification/hdmi_osd')
dest.mkdir(parents=True,exist_ok=True)
c=SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
try:
    with c.client.open_sftp() as ftp:
        for name in ('hdmi_snapshot.nv12','hdmi_snapshot.json','kms_baseline.strace','kms_wait.strace','kms_fixed.strace'):
            ftp.get('/root/dual_vision_host/run/'+name,str(dest/name))
    print('Fetched display pixels and timing traces')
finally:
    c.close()
