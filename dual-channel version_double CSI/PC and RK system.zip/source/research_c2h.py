"""Retrieve public references, keeping original responses and retrieval status."""
import argparse
from datetime import datetime, timezone
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import urllib.request

SOURCES={
    'xdma_cdn':'https://cdn.jsdelivr.net/gh/Xilinx/dma_ip_drivers@master/XDMA/linux-kernel/xdma/libxdma.c',
    'xdma_cdev_cdn':'https://cdn.jsdelivr.net/gh/Xilinx/dma_ip_drivers@master/XDMA/linux-kernel/xdma/cdev_sgdma.c',
    'kernel_dma_api':'https://docs.kernel.org/core-api/dma-api-howto.html',
    'kernel_barriers':'https://docs.kernel.org/core-api/wrappers/memory-barriers.html',
    'amd_xdma_c2h':'https://docs.amd.com/r/en-US/pg195-pcie-dma/AXI4-Stream-Interface',
    'xdma_driver':'https://raw.githubusercontent.com/Xilinx/dma_ip_drivers/master/XDMA/linux-kernel/xdma/libxdma.c',
    'xdma_cdev':'https://raw.githubusercontent.com/Xilinx/dma_ip_drivers/master/XDMA/linux-kernel/xdma/cdev_sgdma.c',
    'axis_rules':'https://zipcpu.com/blog/2021/08/28/axi-rules.html',
    'axis_fifo':'https://raw.githubusercontent.com/alexforencich/verilog-axis/master/rtl/axis_async_fifo.v',
    'search_xdma':'https://www.google.com/search?q=XDMA+C2H+streaming+eop_flush+lost+data+descriptor',
}
class Text(HTMLParser):
    def __init__(self):
        super().__init__();self.skip=0;self.parts=[]
    def handle_starttag(self,tag,attrs):
        if tag in ('script','style'):self.skip+=1
        if tag in ('p','div','li','pre','h1','h2','h3','br','tr'):self.parts.append('\n')
    def handle_endtag(self,tag):
        if tag in ('script','style'):self.skip=max(0,self.skip-1)
    def handle_data(self,data):
        if not self.skip:self.parts.append(data)

p=argparse.ArgumentParser();p.add_argument('source',choices=SOURCES);a=p.parse_args()
dest=Path('investigation_c2h_20261025/sources');dest.mkdir(parents=True,exist_ok=True)
url=SOURCES[a.source];record=dict(url=url,accessed_utc=datetime.now(timezone.utc).isoformat())
try:
    request=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
    with urllib.request.urlopen(request,timeout=22) as response:
        data=response.read();record.update(status=response.status,final_url=response.url,bytes=len(data),content_type=response.headers.get('Content-Type'))
    record['sha256']=hashlib.sha256(data).hexdigest()
    (dest/(a.source+'.raw')).write_bytes(data)
    text=data.decode('utf-8',errors='replace')
    if 'html' in (record['content_type'] or ''):
        parsed=Text();parsed.feed(text);text='\n'.join(s.strip() for s in ''.join(parsed.parts).splitlines() if s.strip())
    (dest/(a.source+'.txt')).write_text(text,encoding='utf-8')
    print(text[:600])
except Exception as exc:record['error']=str(exc)
(dest/(a.source+'.json')).write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record))
