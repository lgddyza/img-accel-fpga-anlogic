"""Check independent QF and display selection with Sobel, restoring settings."""
import json,time
from pathlib import Path
from transport import SSHTransport,default_key

out=Path('verification/sobel_board_20261031/qf_display.json')
c=SSHTransport(dict(host='169.254.53.76',key=str(default_key())))
initial=c.rpc(dict(action='status'))
if initial['runtime']!='managed': raise RuntimeError('receiver not running')
h=initial['hardware']; live=initial['live'];word=h['requested'];qf=h['dual_qf']
restore=dict(mode_a=(word>>1)&7,mode_b=(word>>4)&7,display=live['selected'],
    quality_a=qf&127,quality_b=(qf>>8)&127,independent_qf=bool(qf&(1<<16)),
    adaptive_enabled=bool((live.get('adaptive') or {}).get('enabled')))
results=[]
try:
    c.rpc(dict(action='configure',adaptive_enabled=False,mode_a=4,mode_b=4,
        independent_qf=True,quality_a=85,quality_b=65))
    for display in (0,1):
        c.rpc(dict(action='configure',display=display))
        time.sleep(4)
        a=c.rpc(dict(action='status'))
        time.sleep(8)
        b=c.rpc(dict(action='status'))
        if a['runtime']!='managed' or b['runtime']!='managed': raise RuntimeError('receiver stopped')
        x,y=a['live'],b['live'];dt=y['sample_s']-x['sample_s']
        delta=lambda key:[v-u for u,v in zip(x['counters'][key],y['counters'][key])]
        row=dict(display=display,selected=y['selected'],modes=y['decoded_modes'],quality=y['decoded_quality'],
            independent_qf=b['hardware']['dual_qf'],seconds=dt,
            decode_fps=[v/dt for v in delta('decoded_frames')],
            hdmi_fps=(y['display']['rendered']-x['display']['rendered'])/dt,
            submitted_fps=[v/dt for v in delta('submitted_hdmi')],
            queue_drops=delta('decode_queue_drops'),dma_errors=y['counters']['dma_errors'])
        results.append(row);out.write_text(json.dumps(results,indent=2),encoding='utf-8')
        print(json.dumps(row),flush=True)
        if row['selected']!=display or row['modes']!=[4,4] or row['quality']!=[85,65]:
            raise RuntimeError('Unexpected live configuration')
finally:
    try:
        c.rpc(dict(action='configure',**restore))
        print('Original settings restored',flush=True)
    finally:
        c.close()
