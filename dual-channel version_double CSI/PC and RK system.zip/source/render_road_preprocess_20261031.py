"""Render contact sheets from the saved board preview frames and box metadata."""
import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

root=Path('verification/road_preprocess_20261031')
rows=json.loads((root/'results.json').read_text(encoding='utf-8'))
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',14)
heading=ImageFont.truetype('C:/Windows/Fonts/arialbd.ttf',19)
for camera in (0,1):
    sheet=Image.new('RGB',(1280,3*490),'white');draw=ImageDraw.Draw(sheet)
    for i,row in enumerate(rows[:6]):
        ox=(i%2)*640;oy=(i//2)*490
        im=Image.open(root/f"{row['mode']}_cam{camera}_input.jpg").convert('RGB')
        marks=ImageDraw.Draw(im)
        for n,box in enumerate(row['captures'][camera]['boxes']):
            x1,y1,x2,y2=(box['x1']/3,box['y1']/3,box['x2']/3,box['y2']/3)
            marks.rectangle((x1,y1,x2,y2),outline='#ef3030',width=2)
            label=str(n+1)
            bbox=marks.textbbox((0,0),label,font=font)
            tw=bbox[2]-bbox[0]+6;th=bbox[3]-bbox[1]+4
            tx=max(0,min(int(x1),im.width-tw));ty=max(0,min(int(y1)-th,im.height-th))
            marks.rectangle((tx,ty,tx+tw,ty+th),fill='#b00020')
            marks.text((tx+3,ty-1),label,font=font,fill='white')
        sheet.paste(im,(ox,oy+30));draw.text((ox+8,oy+4),f"Camera {'AB'[camera]}  |  {row['mode']}",font=heading,fill='black')
        for n,box in enumerate(row['captures'][camera]['boxes'][:10]):
            label=f"{n+1}. {box['label']}  {box['confidence']:.2f}"
            draw.text((ox+8+(n//5)*315,oy+393+(n%5)*18),label,font=font,fill='black')
    sheet.save(root/f'camera_{camera}_comparison.jpg',quality=92)
    print(root/f'camera_{camera}_comparison.jpg')
