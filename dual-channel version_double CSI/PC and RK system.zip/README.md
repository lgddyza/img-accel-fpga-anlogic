# RK 与上位机双路自适应工程归档

归档日期：2026-11-02（北京时间）。本包保存 2026-10-31 决策树展示版，包含 PC 可执行程序和源码、RK 用户态程序、板端模型和只读提取的依赖。

## 目录与使用

- `pc/RKDualVisionHost/RKDualVisionHost.exe` 是上位机入口；整个 `RKDualVisionHost` 目录必须保留。
- `source/` 保存 PC 和 RK 源码、单元测试、构建脚本、RK payload 和 NPU 并行实现参考源码。上位机内 payload 与 `source/rk_payload.zip` 校验一致，SHA-256：`49f6af7f10c850acc866a64a9021c2f440ef022c17b272c4bdfe218d582e494f`。
- `rk_board_dependencies/` 按 RK 根目录结构存放现场模型、JPEG 依赖、PCIe 模块和参考源码。恢复前先确认目标系统、内核、软硬件版本并备份目标文件；PCIe 模块仅适用于其编译内核。
- `model_training/` 为固定决策树的训练结果、配对样本特征和报告；训练脚本依赖原图及其他实验模块，本包不包含完整训练集，不保证单独运行训练脚本即可重训。
- `verification/` 保存上次短时板测的脱敏记录；`自适应决策树部署说明.md` 描述使用方法和测试边界。
- `board_environment.txt` 与 `board_status_at_archive.json` 为归档时只读获取的系统信息；`MANIFEST.json` 为每个归档文件的 SHA-256。

连接已有兼容环境的 RK 后，启动视频，在“应用检测设置”中打开自适应；如需双路独立 QF，需在运行参数中开启独立 QF。使用旧上位机可能重新部署旧 payload。此包不是完整 RK 系统镜像，不自动安装 RKNN、GStreamer、图形栈或配置 SSH/SD 卡。

本次不包含 FPGA 工程与位流、原始训练集、SSH 密钥、密码和 SD 卡检测图片。预处理决策树是探索性展示模型；暗场 QF、YOLO 配额为规则而非训练模型。历史板测的场景及局限详见部署说明。

未找到的可选板端依赖：[]。现场提取的可用文件均已与板端 SHA-256 比对。
