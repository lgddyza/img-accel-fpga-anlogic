#!/bin/sh
set -eu
stage=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
dest=/root/jpeg_rk
backup=$dest/rollback_k1_preproc_20261010
if [ -e "$backup" ]; then echo "Rollback directory already exists; refusing overwrite" >&2; exit 1; fi
cc -O2 -std=gnu11 -Wall -Wextra -o "$stage/rk_hdmi_status_plane" "$stage/rk_hdmi_status_plane.c" $(pkg-config --cflags --libs libdrm)
python3 -m py_compile "$stage/jpeg_qf_button.py" "$stage/test_k1_preproc.py"
sh -n "$stage/start_jpeg_hdmi_ai.sh"
K1_SCRIPT_DIR="$stage" python3 "$stage/test_k1_preproc.py" --save "$stage/logic_results.json"
mkdir "$backup"
for name in jpeg_qf_button.py rk_hdmi_status_plane.c rk_hdmi_status_plane rk_font5x7.h start_jpeg_hdmi_ai.sh; do
    cp -p "$dest/$name" "$backup/$name"
done
for name in jpeg_qf_button.py rk_hdmi_status_plane.c rk_font5x7.h start_jpeg_hdmi_ai.sh; do
    cp "$stage/$name" "$dest/$name"
done
cp "$stage/rk_hdmi_status_plane" "$dest/rk_hdmi_status_plane.next"
chmod +x "$dest/rk_hdmi_status_plane.next"
mv "$dest/rk_hdmi_status_plane.next" "$dest/rk_hdmi_status_plane"
echo K1_UPDATE_INSTALLED
