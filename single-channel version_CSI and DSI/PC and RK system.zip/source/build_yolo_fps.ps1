$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$agentAsset = (Join-Path $PSScriptRoot 'board_agent.py') + ';.'
& .\.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onedir --windowed --name RKVisionHost --distpath dist_yolo_fps --workpath build_yolo_fps --specpath build_yolo_fps --add-data $agentAsset app.py
if ($LASTEXITCODE -ne 0) { throw 'PyInstaller failed' }
$shadow = Join-Path $PSScriptRoot 'dist_yolo_fps/RKVisionHost/_internal/icuuc.dll'
if (Test-Path -LiteralPath $shadow) { Remove-Item -LiteralPath $shadow }
