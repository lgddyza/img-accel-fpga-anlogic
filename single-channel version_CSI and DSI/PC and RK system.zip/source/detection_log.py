"""Persistent, sampled detection journal and its Qt inspection view."""
import csv
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sqlite3
import uuid

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QDesktopServices, QImage
from PySide6.QtCore import QUrl
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QCheckBox, QComboBox, QDoubleSpinBox, QTableWidget,
    QTableWidgetItem, QHeaderView, QSplitter, QFileDialog, QMessageBox, QStyle, QDialog,
    QScrollArea, QLayout)
from video_preview import tool_icon, Canvas

MODE_NAMES = ('灰度', '高斯', 'CLAHE', '高斯 + CLAHE', 'Sobel', '黑帽',
              'Sobel + CLAHE', '黑帽 + CLAHE')
MAX_RECORDS = 20


class DetectionStore:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.path, timeout=1)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('PRAGMA foreign_keys=ON')
        self.db.execute('PRAGMA journal_size_limit=1048576')
        needs_vacuum = self.db.execute('PRAGMA auto_vacuum').fetchone()[0] != 2
        self.db.executescript('''
            CREATE TABLE IF NOT EXISTS sessions (
                id TEXT PRIMARY KEY, started_at TEXT NOT NULL, source TEXT NOT NULL,
                viewer_pid INTEGER NOT NULL, boot_id TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS samples (
                id INTEGER PRIMARY KEY, session_id TEXT NOT NULL REFERENCES sessions(id),
                sampled_at TEXT NOT NULL, seq INTEGER NOT NULL, updated_us INTEGER NOT NULL,
                age_ms REAL NOT NULL, mode INTEGER, qf INTEGER, threshold REAL,
                interval INTEGER, hdmi_fps REAL, yolo_fps REAL,
                box_count INTEGER NOT NULL, max_confidence REAL,
                UNIQUE(session_id, seq, updated_us));
            CREATE TABLE IF NOT EXISTS boxes (
                sample_id INTEGER NOT NULL REFERENCES samples(id), ordinal INTEGER NOT NULL,
                label TEXT NOT NULL, class_id INTEGER, confidence REAL NOT NULL,
                x1 REAL NOT NULL, y1 REAL NOT NULL, x2 REAL NOT NULL, y2 REAL NOT NULL,
                PRIMARY KEY(sample_id, ordinal));
            CREATE INDEX IF NOT EXISTS samples_session ON samples(session_id, id);
            CREATE INDEX IF NOT EXISTS boxes_label ON boxes(label, sample_id);
            CREATE TABLE IF NOT EXISTS sample_images (
                sample_id INTEGER PRIMARY KEY REFERENCES samples(id),
                jpeg BLOB NOT NULL, metadata_json TEXT NOT NULL);
        ''')
        self.session = None
        self.identity = None
        with self.db:
            self.prune()
        if needs_vacuum:
            self.db.execute('PRAGMA auto_vacuum=INCREMENTAL')
            self.db.execute('VACUUM')
        self.db.execute('PRAGMA incremental_vacuum(64)')

    def prune(self):
        expired = 'SELECT id FROM samples ORDER BY id DESC LIMIT -1 OFFSET ?'
        self.db.execute('DELETE FROM sample_images WHERE sample_id IN (' + expired + ')', (MAX_RECORDS,))
        self.db.execute('DELETE FROM boxes WHERE sample_id IN (' + expired + ')', (MAX_RECORDS,))
        self.db.execute('DELETE FROM samples WHERE id IN (' + expired + ')', (MAX_RECORDS,))
        self.db.execute('DELETE FROM sessions WHERE id NOT IN (SELECT session_id FROM samples)')

    def clear(self):
        with self.db:
            for table in ('sample_images', 'boxes', 'samples', 'sessions'):
                self.db.execute('DELETE FROM ' + table)
        self.reset_session()
        self.db.execute('VACUUM')
        self.db.execute('PRAGMA wal_checkpoint(TRUNCATE)')

    def reset_session(self):
        self.session = self.identity = None

    def record(self, status, source, hdmi_fps=None, yolo_fps=None, snapshot=None):
        ai = status.get('ai')
        if (status.get('runtime') != 'ai' or not status.get('viewer_pid') or not ai
                or not 0 <= ai.get('age_ms', float('inf')) <= 2000
                or ai.get('seq', 1) % 2 or ai.get('updated_us', 0) <= 0):
            return False
        identity = (source, status.get('cpu', {}).get('boot_id', ''), status['viewer_pid'])
        now = datetime.now().astimezone().isoformat(timespec='milliseconds')
        boxes = ai.get('boxes', [])
        fpga = status.get('fpga', {})
        # One transaction makes a snapshot and all of its boxes indivisible.
        new_session = identity != self.identity
        session = uuid.uuid4().hex if new_session else self.session
        with self.db:
            if new_session:
                self.db.execute('INSERT INTO sessions VALUES (?, ?, ?, ?, ?)',
                                (session, now, source, identity[2], identity[1]))
            cursor = self.db.execute('''INSERT OR IGNORE INTO samples
                (session_id, sampled_at, seq, updated_us, age_ms, mode, qf, threshold,
                 interval, hdmi_fps, yolo_fps, box_count, max_confidence)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (session, now, ai['seq'], ai['updated_us'], ai['age_ms'],
                 fpga.get('mode_applied'), fpga.get('qf_applied'), status.get('confidence'),
                 status.get('interval'), hdmi_fps, yolo_fps, len(boxes),
                 max((box['confidence'] for box in boxes), default=None)))
            added = cursor.rowcount == 1
            if added:
                self.db.executemany('INSERT INTO boxes VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    [(cursor.lastrowid, i, box['label'], box.get('class'), box['confidence'],
                      *box['xyxy']) for i, box in enumerate(boxes)])
                if len(boxes) > 6 and snapshot:
                    metadata = dict(snapshot['metadata'], sha256=hashlib.sha256(snapshot['jpeg']).hexdigest())
                    self.db.execute('INSERT INTO sample_images VALUES (?, ?, ?)',
                                    (cursor.lastrowid, snapshot['jpeg'], json.dumps(metadata, allow_nan=False)))
                self.prune()
        if added:
            self.db.execute('PRAGMA incremental_vacuum(64)')
        self.session, self.identity = session, identity
        return added

    def sessions(self):
        return [dict(row) for row in self.db.execute('SELECT * FROM sessions ORDER BY started_at DESC')]

    def labels(self):
        return [row[0] for row in self.db.execute('SELECT DISTINCT label FROM boxes ORDER BY label')]

    @staticmethod
    def where(session=None, label=None, confidence=0, only_targets=True):
        parts, args = [], []
        if session:
            parts.append('s.session_id=?')
            args.append(session)
        if only_targets:
            parts.append('s.box_count>0')
        if label or confidence > 0:
            parts.append('EXISTS (SELECT 1 FROM boxes b WHERE b.sample_id=s.id'
                         + (' AND b.label=?' if label else '') + ' AND b.confidence>=?)')
            if label:
                args.append(label)
            args.append(confidence)
        return (' WHERE ' + ' AND '.join(parts) if parts else ''), args

    def rows(self, filters, limit=MAX_RECORDS):
        where, args = self.where(**filters)
        sql = '''SELECT s.*, t.source, t.viewer_pid,
            EXISTS (SELECT 1 FROM sample_images WHERE sample_id=s.id) AS has_image,
            (SELECT group_concat(label, ' / ') FROM
                (SELECT DISTINCT label FROM boxes WHERE sample_id=s.id ORDER BY label)) AS labels
            FROM samples s JOIN sessions t ON t.id=s.session_id''' + where + ' ORDER BY s.id DESC'
        if limit is not None:
            sql += ' LIMIT ?'
            args.append(limit)
        return [dict(row) for row in self.db.execute(sql, args)]

    def summary(self, filters):
        where, args = self.where(**filters)
        return dict(self.db.execute('''SELECT count(*) AS samples,
            coalesce(sum(box_count>0),0) AS targets, coalesce(sum(box_count),0) AS boxes,
            max(max_confidence) AS peak FROM samples s''' + where, args).fetchone())

    def boxes(self, sample_id):
        return [dict(row) for row in self.db.execute(
            'SELECT * FROM boxes WHERE sample_id=? ORDER BY ordinal', (sample_id,))]

    def export(self, path, filters):
        rows = self.rows(filters, limit=None)
        path = Path(path)
        for row in rows:
            image = self.image(row['id'])
            row['image'] = None
            if image:
                relative = Path(path.stem + '_images') / (row['session_id'] + '_' + str(row['id']) + '.jpg')
                target = path.parent / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(image['jpeg'])
                row['image'] = dict(image['metadata'], path=relative.as_posix())
        if path.suffix.lower() == '.json':
            payload = {'schema_version': 2, 'record_kind': 'polled_detection_snapshot',
                       'retention_samples': MAX_RECORDS,
                       'nominal_poll_seconds': 1, 'coordinates': 'HDMI 1920x1080 xyxy',
                       'filters': filters, 'exported_at': datetime.now().astimezone().isoformat(),
                       'samples': [dict(row, boxes=self.boxes(row['id'])) for row in rows]}
            path.write_text(json.dumps(payload, indent=2, ensure_ascii=False, allow_nan=False), encoding='utf-8')
        else:
            with path.open('w', encoding='utf-8-sig', newline='') as stream:
                writer = csv.writer(stream)
                writer.writerow(['采样时间', '会话', '设备', '结果序号', '板端结果时间_us', '结果年龄_ms',
                                 '预处理', 'QF', '推理阈值', '推理间隔', 'HDMI_FPS', 'YOLO_FPS',
                                 '采样框数', '标签', '类别号', '置信度', 'x1', 'y1', 'x2', 'y2',
                                 '检测预览图', '预览编码时间偏差_ms'])
                for row in rows:
                    mode = row['mode']
                    prefix = [row['sampled_at'], row['session_id'], row['source'], row['seq'],
                              row['updated_us'], row['age_ms'], mode_name(mode), row['qf'],
                              row['threshold'], row['interval'], row['hdmi_fps'], row['yolo_fps'], row['box_count']]
                    for box in self.boxes(row['id']) or [None]:
                        values = prefix + ([box[k] for k in ('label', 'class_id', 'confidence', 'x1', 'y1', 'x2', 'y2')]
                                           if box else [''] * 7)
                        values += [row['image']['path'], row['image'].get('delta_ms', '')] if row['image'] else ['', '']
                        writer.writerow([csv_value(value) for value in values])
        return len(rows)

    def image(self, sample_id):
        row = self.db.execute('SELECT jpeg, metadata_json FROM sample_images WHERE sample_id=?', (sample_id,)).fetchone()
        return {'jpeg': row['jpeg'], 'metadata': json.loads(row['metadata_json'])} if row else None

    def close(self):
        self.db.close()


def csv_value(value):
    if isinstance(value, str) and value.lstrip().startswith(('=', '+', '-', '@')):
        return "'" + value
    return value


def mode_name(value):
    return MODE_NAMES[value] if type(value) is int and 0 <= value < len(MODE_NAMES) else '—'


def fmt(value, digits=1):
    return '—' if value is None else f'{value:.{digits}f}'


class DetectionJournal(QWidget):
    def __init__(self, path, parent=None):
        super().__init__(parent)
        self.store = None
        self.rows_by_id = {}
        self.closed = False
        self.build_ui()
        try:
            self.store = DetectionStore(path)
            self.refresh_options()
            self.refresh()
        except (OSError, sqlite3.Error) as exc:
            self.fail(exc)

    def action(self, text, icon, callback, tooltip=None):
        button = QPushButton(text)
        button.setIcon(tool_icon(self, icon))
        button.setMinimumHeight(34)
        button.clicked.connect(callback)
        if tooltip:
            button.setToolTip(tooltip)
        return button

    def build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 12)
        layout.setSpacing(14)
        heading = QHBoxLayout()
        title = QLabel('检测日志')
        title.setObjectName('sectionTitle')
        heading.addWidget(title)
        self.recording = QCheckBox('自动记录')
        self.recording.setChecked(True)
        self.recording.toggled.connect(self.toggle_recording)
        heading.addWidget(self.recording)
        self.state = QLabel('等待有效推理结果')
        self.state.setObjectName('muted')
        heading.addWidget(self.state)
        heading.addStretch()
        self.folder_button = self.action('', QStyle.StandardPixmap.SP_DirOpenIcon,
                                         self.open_folder, '打开日志存储目录')
        heading.addWidget(self.folder_button)
        self.export_button = self.action('导出', QStyle.StandardPixmap.SP_DialogSaveButton,
                                         self.export, '导出符合当前筛选条件的全部记录')
        heading.addWidget(self.export_button)
        layout.addLayout(heading)
        summary = QGridLayout()
        self.counts = {}
        for index, (key, title) in enumerate((('samples', '有效采样'), ('targets', '有目标采样'),
                                              ('boxes', '框次 · 采样'), ('peak', '最高置信度'))):
            column = QVBoxLayout()
            label = QLabel(title)
            label.setObjectName('muted')
            value = QLabel('—')
            value.setObjectName('metric')
            column.addWidget(label)
            column.addWidget(value)
            summary.addLayout(column, 0, index)
            self.counts[key] = value
        self.counts['boxes'].setToolTip('各采样检测框数之和；包含同一目标重复出现的框，不是独立缺陷数。')
        layout.addLayout(summary)
        filters = QHBoxLayout()
        self.session_filter = QComboBox()
        self.session_filter.setMinimumWidth(280)
        self.session_filter.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.session_filter.setMinimumContentsLength(26)
        self.session_filter.addItem('全部会话', None)
        filters.addWidget(self.session_filter, 2)
        self.label_filter = QComboBox()
        self.label_filter.addItem('全部类别', None)
        filters.addWidget(self.label_filter, 1)
        filters.addWidget(QLabel('最低置信度'))
        self.minimum_confidence = QDoubleSpinBox()
        self.minimum_confidence.setRange(0, 1)
        self.minimum_confidence.setDecimals(2)
        self.minimum_confidence.setSingleStep(.05)
        filters.addWidget(self.minimum_confidence)
        self.only_targets = QCheckBox('仅有目标')
        self.only_targets.setChecked(True)
        filters.addWidget(self.only_targets)
        self.follow = QCheckBox('跟随最新')
        self.follow.setChecked(True)
        filters.addWidget(self.follow)
        layout.addLayout(filters)
        self.session_filter.currentIndexChanged.connect(self.refresh)
        self.label_filter.currentIndexChanged.connect(self.refresh)
        self.minimum_confidence.valueChanged.connect(self.refresh)
        self.only_targets.toggled.connect(self.refresh)
        split = QSplitter(Qt.Orientation.Horizontal)
        self.table = QTableWidget(0, 9)
        self.table.setHorizontalHeaderLabels(['采样时间', '类别', '框数', '最高置信度', '预处理', 'QF', 'HDMI', 'YOLO', '图片'])
        self.configure_table(self.table)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.itemSelectionChanged.connect(self.show_selected)
        split.addWidget(self.table)
        detail = QWidget()
        detail.setMinimumWidth(280)
        dl = QVBoxLayout(detail)
        dl.setSizeConstraint(QLayout.SizeConstraint.SetMinimumSize)
        dl.setContentsMargins(14, 0, 0, 0)
        caption = QLabel('记录详情')
        caption.setObjectName('sectionTitle')
        dl.addWidget(caption)
        self.detail = QLabel('尚未选择记录')
        self.detail.setWordWrap(True)
        self.detail.setTextFormat(Qt.TextFormat.PlainText)
        self.detail.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        dl.addWidget(self.detail)
        self.image_canvas = Canvas()
        self.image_canvas.setFixedHeight(168)
        self.image_canvas.message = '无检测图片'
        dl.addWidget(self.image_canvas)
        image_row = QHBoxLayout()
        self.image_note = QLabel('—')
        self.image_note.setObjectName('muted')
        self.image_note.setWordWrap(True)
        image_row.addWidget(self.image_note, 1)
        self.image_button = self.action('', QStyle.StandardPixmap.SP_TitleBarMaxButton,
                                        self.open_image, '放大检测图片')
        self.image_button.setEnabled(False)
        image_row.addWidget(self.image_button)
        dl.addLayout(image_row)
        self.detail_boxes = QTableWidget(0, 3)
        self.detail_boxes.setMinimumHeight(140)
        self.detail_boxes.setHorizontalHeaderLabels(['标签', '置信度', '坐标 xyxy'])
        self.configure_table(self.detail_boxes)
        self.detail_boxes.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        dl.addWidget(self.detail_boxes, 1)
        detail_scroll = QScrollArea()
        detail_scroll.setWidgetResizable(True)
        detail_scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        detail_scroll.setMinimumWidth(300)
        detail_scroll.setWidget(detail)
        split.addWidget(detail_scroll)
        split.setSizes([960, 340])
        split.setStretchFactor(0, 1)
        layout.addWidget(split, 1)
        self.footer = QLabel('约 1 秒采样 · 本地 SQLite')
        self.footer.setObjectName('muted')
        layout.addWidget(self.footer)

    @staticmethod
    def configure_table(table):
        table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        table.setAlternatingRowColors(True)
        table.verticalHeader().hide()
        table.verticalHeader().setDefaultSectionSize(34)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)

    def filters(self):
        return {'session': self.session_filter.currentData(), 'label': self.label_filter.currentData(),
                'confidence': self.minimum_confidence.value(), 'only_targets': self.only_targets.isChecked()}

    def refresh_options(self):
        if not self.store:
            return
        for combo, items, default in (
                (self.session_filter, [(f"{s['started_at'][:19].replace('T', ' ')} · {s['source']}", s['id'])
                                       for s in self.store.sessions()], '全部会话'),
                (self.label_filter, [(label, label) for label in self.store.labels()], '全部类别')):
            old = combo.currentData()
            combo.blockSignals(True)
            combo.clear()
            combo.addItem(default, None)
            for text, value in items:
                combo.addItem(text, value)
            combo.setCurrentIndex(max(0, combo.findData(old)))
            combo.blockSignals(False)

    def observe(self, status, source, hdmi_fps, yolo_fps, snapshot=None):
        if not self.store or not self.recording.isChecked():
            return
        try:
            if self.store.record(status, source, hdmi_fps, yolo_fps, snapshot):
                self.state.setText('记录中 · ' + datetime.now().strftime('%H:%M:%S'))
                if self.isVisible():
                    self.refresh_options()
                    self.refresh()
        except (OSError, sqlite3.Error, ValueError, KeyError) as exc:
            self.fail(exc)

    def refresh(self, *_):
        if not self.store:
            return
        try:
            selected = self.table.currentItem()
            selected_id = self.table.item(selected.row(), 0).data(Qt.ItemDataRole.UserRole) if selected else None
            scroll = self.table.verticalScrollBar().value()
            filters = self.filters()
            rows = self.store.rows(filters)
            summary = self.store.summary(filters)
            for key, value in summary.items():
                self.counts[key].setText(fmt(value, 3) if key == 'peak' else f'{value:,}')
            self.rows_by_id = {row['id']: row for row in rows}
            self.table.blockSignals(True)
            self.table.setRowCount(len(rows))
            for index, row in enumerate(rows):
                values = [row['sampled_at'][:23].replace('T', ' '), row['labels'] or '无目标',
                          str(row['box_count']), fmt(row['max_confidence'], 3), mode_name(row['mode']),
                          str(row['qf']) if row['qf'] is not None else '—', fmt(row['hdmi_fps']), fmt(row['yolo_fps']),
                          '有图' if row['has_image'] else '—']
                for col, value in enumerate(values):
                    item = QTableWidgetItem(value)
                    item.setData(Qt.ItemDataRole.UserRole, row['id'])
                    if col in (2, 3, 5, 6, 7):
                        item.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
                    if col == 3 and row['max_confidence'] is not None:
                        item.setForeground(QColor('#34d399' if row['max_confidence'] >= .7 else '#fbbf24'))
                    self.table.setItem(index, col, item)
            self.table.blockSignals(False)
            if rows:
                index = next((i for i, row in enumerate(rows) if row['id'] == selected_id), 0)
                self.table.selectRow(0 if self.follow.isChecked() else index)
                if self.follow.isChecked():
                    self.table.scrollToTop()
                else:
                    self.table.verticalScrollBar().setValue(scroll)
                self.show_selected()
            else:
                self.detail.setText('暂无符合筛选条件的记录')
                self.detail_boxes.setRowCount(0)
                self.set_image(None)
            self.footer.setText(f"约 1 秒采样 · 最近 {MAX_RECORDS} 条滚动保留 · 当前筛选 {summary['samples']:,} 条")
            self.export_button.setEnabled(bool(rows))
        except sqlite3.Error as exc:
            self.fail(exc)

    def show_selected(self):
        item = self.table.currentItem()
        if not item or not self.store:
            return
        row = self.rows_by_id.get(self.table.item(item.row(), 0).data(Qt.ItemDataRole.UserRole))
        if not row:
            return
        self.detail.setText(f"{row['sampled_at'][:23].replace('T', ' ')}\n{row['source']} · PID {row['viewer_pid']}\n"
                            f"预处理 {mode_name(row['mode'])} / QF {row['qf']}\n"
                            f"阈值 {fmt(row['threshold'], 2)} / 间隔 {row['interval']}\n"
                            f"结果年龄 {fmt(row['age_ms'])} ms / 序号 {row['seq']}")
        boxes = self.store.boxes(row['id'])
        self.set_image(self.store.image(row['id']))
        self.detail_boxes.setRowCount(len(boxes))
        for index, box in enumerate(boxes):
            values = [box['label'], fmt(box['confidence'], 3),
                      ', '.join(f"{box[key]:.0f}" for key in ('x1', 'y1', 'x2', 'y2'))]
            for col, value in enumerate(values):
                self.detail_boxes.setItem(index, col, QTableWidgetItem(value))

    def set_image(self, attachment):
        image = QImage.fromData(attachment['jpeg'], 'JPEG') if attachment else QImage()
        self.image_canvas.image = None if image.isNull() else image
        self.image_canvas.message = '图片不可读' if attachment else '无检测图片'
        self.image_canvas.update()
        self.image_button.setEnabled(not image.isNull())
        self.image_note.setText(('邻近预览 · 编码时间偏差 ' + fmt(attachment['metadata'].get('delta_ms')) + ' ms')
                                if attachment else '预览开启且框数 > 6 时保存')

    def open_image(self):
        if self.image_canvas.image is None:
            return
        dialog = QDialog(self)
        dialog.setWindowTitle('检测图片 · 邻近 HDMI 预览帧')
        dialog.resize(1040, 650)
        layout = QVBoxLayout(dialog)
        canvas = Canvas()
        canvas.image = self.image_canvas.image
        layout.addWidget(canvas, 1)
        layout.addWidget(QLabel(self.image_note.text()))
        dialog.exec()

    def toggle_recording(self, enabled):
        if self.store:
            self.store.reset_session()
        self.state.setText('等待有效推理结果' if enabled else '已暂停 · 历史保留')

    def connection_changed(self):
        if self.store:
            self.store.reset_session()
        if self.recording.isChecked():
            self.state.setText('等待有效推理结果')

    def fail(self, exc):
        self.recording.setChecked(False)
        self.recording.setEnabled(False)
        self.state.setText('日志存储失败：' + str(exc))
        self.state.setToolTip(str(exc))

    def open_folder(self):
        if self.store:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.store.path.parent)))

    def export(self):
        if not self.store:
            return
        path, selected = QFileDialog.getSaveFileName(self, '导出检测日志',
            'detections_' + datetime.now().strftime('%Y%m%d_%H%M%S') + '.csv',
            'CSV (*.csv);;JSON (*.json)')
        if not path:
            return
        if Path(path).suffix.lower() not in ('.csv', '.json'):
            path += '.json' if selected.startswith('JSON') else '.csv'
        try:
            count = self.store.export(path, self.filters())
            self.state.setText(f'已导出 {count:,} 条采样')
        except (OSError, sqlite3.Error, ValueError) as exc:
            QMessageBox.warning(self, '导出未完成', str(exc))

    def close_store(self):
        if self.store and not self.closed:
            self.store.close()
            self.closed = True

    def showEvent(self, event):
        super().showEvent(event)
        if self.store and not self.closed:
            self.refresh_options()
            self.refresh()
