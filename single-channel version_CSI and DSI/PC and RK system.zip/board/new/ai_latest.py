"""Single inference worker with one replaceable latest-frame slot."""
import threading
import time


class LatestInference:
    def __init__(self, detector, overlay, confidence):
        self.detector = detector
        self.overlay = overlay
        self.confidence = confidence
        self.condition = threading.Condition()
        self.pending = None
        self.stopping = False
        self.error = None
        self.last_frame = -1
        self.stats = dict(submitted=0, completed=0, milliseconds=0.,
                          latest_boxes=0, replaced=0, age_ms=0.)
        self.thread = threading.Thread(target=self._run, name="yolo-latest")
        self.thread.start()

    def offer(self, frame_id, frame):
        with self.condition:
            self._check()
            if self.stopping or frame_id <= self.last_frame:
                return
            self.last_frame = frame_id
            if self.pending is not None:
                self.stats['replaced'] += 1
            self.pending = (frame_id, frame, time.monotonic())
            self.condition.notify()

    def _check(self):
        if self.error is not None:
            raise RuntimeError("YOLO worker failed") from self.error

    def snapshot(self):
        with self.condition:
            self._check()
            return self.stats.copy()

    def _run(self):
        try:
            while True:
                with self.condition:
                    self.condition.wait_for(lambda: self.stopping or self.pending is not None)
                    if self.stopping:
                        return
                    _, frame, offered = self.pending
                    self.pending = None
                    self.stats['submitted'] += 1
                boxes, elapsed = self.detector.run(frame, self.confidence)
                self.overlay.update(boxes)
                with self.condition:
                    self.stats['completed'] += 1
                    self.stats['milliseconds'] += elapsed
                    self.stats['latest_boxes'] = len(boxes)
                    self.stats['age_ms'] = (time.monotonic() - offered) * 1000
        except BaseException as exc:
            with self.condition:
                self.error = exc
                self.pending = None

    def close(self):
        with self.condition:
            self.stopping = True
            self.pending = None
            self.condition.notify()
        self.thread.join()
