import threading
import unittest
from ai_latest import LatestInference


class WorkerTest(unittest.TestCase):
    def test_replaces_pending_and_publishes_without_next_video_frame(self):
        started = threading.Event()
        release = threading.Event()
        published = threading.Event()
        calls = []
        results = []
        class Detector:
            def run(self, frame, confidence):
                calls.append(frame)
                if frame == b'first':
                    started.set()
                    self.assert_release = release.wait(2)
                return [frame], 1.
        class Overlay:
            def update(self, boxes):
                results.append(boxes)
                if boxes == [b'latest']:
                    published.set()
        worker = LatestInference(Detector(), Overlay(), .1)
        try:
            worker.offer(1, b'first')
            self.assertTrue(started.wait(2))
            worker.offer(2, b'stale')
            worker.offer(3, b'latest')
            worker.offer(3, b'duplicate')
            release.set()
            self.assertTrue(published.wait(2))
            self.assertEqual(calls, [b'first', b'latest'])
            self.assertEqual(results, [[b'first'], [b'latest']])
            self.assertEqual(worker.snapshot()['replaced'], 1)
        finally:
            release.set()
            worker.close()

    def test_error_reaches_main_thread(self):
        class Detector:
            def run(self, *_):
                raise ValueError('inference failure')
        worker = LatestInference(Detector(), None, .1)
        worker.offer(1, b'frame')
        worker.thread.join(2)
        with self.assertRaisesRegex(RuntimeError, 'YOLO worker failed'):
            worker.snapshot()
        with self.assertRaises(RuntimeError):
            worker.offer(2, b'frame')
        worker.close()


if __name__ == '__main__':
    unittest.main()
