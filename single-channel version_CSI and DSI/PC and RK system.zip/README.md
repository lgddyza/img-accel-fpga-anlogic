# YOLO接近60 FPS版本

这是基于现有RK部署的增量归档，附可直接运行的PC上位机。不是完整板卡系统镜像。
PC运行 launch.cmd。原有检测日志最多20条的策略保留。没有打包登录凭据和检测日志。

RK已经部署：board/new下4个文件对应 /root/jpeg_rk/。
其中 pc_host_agent_v1.py 对应 source/board_agent.py；新依赖 ai_latest.py 必须同时复制。
原模型、库、MSI驱动、FPGA及网络预览均沿用已有部署。

如需重新部署：先在上位机停止显示，把board/new内4个文件复制到RK的/root/jpeg_rk/，
保持start_jpeg_hdmi_ai.sh可执行；在新版上位机选择每N帧推理=1并启动RK推理。
默认输入640、阈值0.1，仍可按场景调整。

回退本轮：先停止显示，把board/rollback下3个文件复制回/root/jpeg_rk/。
ai_latest.py留在目录也不会被旧程序加载。使用旧的PC版本
dist_detection_images/RKVisionHost/RKVisionHost.exe，或原已归档PC包，避免新版连接时同步新版agent。
将每N帧推理设为2即可恢复本轮开始的运行配置；设为1则为旧调度全速对照。
回退操作不涉及MSI驱动和FPGA。

board/部署前及部署后SHA256、verification测试记录、REPORT.md见包内。
完整基础环境请配合既有RK/PC完整备份和DMA MSI增量包保存。
